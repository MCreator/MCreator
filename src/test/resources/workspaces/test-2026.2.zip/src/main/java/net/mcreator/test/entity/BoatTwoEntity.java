package net.mcreator.test.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.boat.Boat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.test.init.TestModItems;

public class BoatTwoEntity extends Boat {
	public BoatTwoEntity(EntityType<BoatTwoEntity> type, Level world) {
		super(type, world, TestModItems.BOAT_TWO);
	}
}