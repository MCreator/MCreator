package net.mcreator.test.procedures;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.BlockPos;

import net.mcreator.test.network.TestModVariables;

public class Procedures20261Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		Entity _entity4 = (world instanceof Level _level3 ? _level3.getEntity(entity.getId()) : null);
		_entity4.getPersistentData().put("tagName",
				(CompoundTag) ItemStack.OPTIONAL_CODEC
						.encode((ItemStack.OPTIONAL_CODEC.parse(world.registryAccess().createSerializationContext(NbtOps.INSTANCE), itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getCompoundOrEmpty("tagName")).result()
								.orElse(ItemStack.EMPTY)), _entity4.registryAccess().createSerializationContext(NbtOps.INSTANCE), new CompoundTag())
						.result().orElseGet(CompoundTag::new));
		{
			final String _tagName = "tagName";
			final ItemStack _tagValue = new ItemStack(Blocks.BIRCH_LOG);
			CustomData.update(DataComponents.CUSTOM_DATA, (getBlockNBTItemStack(world, BlockPos.containing(x, y, z), "tagName")),
					tag -> tag.put(_tagName, (CompoundTag) ItemStack.OPTIONAL_CODEC.encode(_tagValue, world.registryAccess().createSerializationContext(NbtOps.INSTANCE), new CompoundTag()).result().orElseGet(CompoundTag::new)));
		}
		{
			TestModVariables.PlayerVariables _vars = entity.getData(TestModVariables.PLAYER_VARIABLES);
			_vars.vector = entity.getData(TestModVariables.PLAYER_VARIABLES).vector;
			_vars.markSyncDirty();
		}
	}

	private static ItemStack getBlockNBTItemStack(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return ItemStack.OPTIONAL_CODEC.parse(world.registryAccess().createSerializationContext(NbtOps.INSTANCE), blockEntity.getPersistentData().getCompoundOrEmpty(tag)).result().orElse(ItemStack.EMPTY);
		return ItemStack.EMPTY;
	}
}