/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.test.fluid.TestFluidFluid;
import net.mcreator.test.TestMod;

public class TestModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, TestMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> TEST_FLUID = REGISTRY.register("test_fluid", TestFluidFluid.Source::new);
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_TEST_FLUID = REGISTRY.register("flowing_test_fluid", TestFluidFluid.Flowing::new);
}