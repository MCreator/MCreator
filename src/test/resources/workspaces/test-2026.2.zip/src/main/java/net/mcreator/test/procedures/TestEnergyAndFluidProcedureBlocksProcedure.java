package net.mcreator.test.procedures;

import net.neoforged.neoforge.transfer.transaction.Transaction;
import net.neoforged.neoforge.transfer.fluid.FluidResource;
import net.neoforged.neoforge.transfer.energy.EnergyHandler;
import net.neoforged.neoforge.transfer.ResourceHandlerUtil;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.test.init.TestModFluids;

public class TestEnergyAndFluidProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (getMaxEnergyStored(world, BlockPos.containing(x, y, z), null) > 0 && getEnergyStored(world, BlockPos.containing(x, y, z), null) > 0) {
			if (canReceiveEnergy(world, BlockPos.containing(x, y, z), null) && receiveEnergySimulate(world, BlockPos.containing(x, y, z), 100, null) > 0) {
				if (world instanceof ILevelExtension _ext) {
					if (_ext.getCapability(Capabilities.Energy.BLOCK, BlockPos.containing(x, y, z), null) instanceof EnergyHandler _energyHandler) {
						try (var _tx = Transaction.openRoot()) {
							_energyHandler.insert(100, _tx);
							_tx.commit();
						}
					}
				}
				if (canExtractEnergy(world, BlockPos.containing(x, y, z), null) && extractEnergySimulate(world, BlockPos.containing(x, y, z), 100, null) > 0) {
					if (world instanceof ILevelExtension _ext) {
						if (_ext.getCapability(Capabilities.Energy.BLOCK, BlockPos.containing(x, y, z), null) instanceof EnergyHandler _energyHandler) {
							try (var _tx = Transaction.openRoot()) {
								_energyHandler.extract(100, _tx);
								_tx.commit();
							}
						}
					}
				}
			}
		} else if (getBlockTanks(world, BlockPos.containing(x, y, z), null) >= 1 && getFluidTankCapacity(world, BlockPos.containing(x, y, z), 1, null) > 0 && getFluidTankLevel(world, BlockPos.containing(x, y, z), 1, null) > 0) {
			if (fillTankSimulate(world, BlockPos.containing(x, y, z), 100, null, TestModFluids.TEST_FLUID.get()) > 0) {
				if (world instanceof ILevelExtension _ext) {
					if (_ext.getCapability(Capabilities.Fluid.BLOCK, BlockPos.containing(x, y, z), null) instanceof ResourceHandler<FluidResource> _fluidHandler) {
						int _fillAmount = 100;
						if (_fillAmount > 0) {
							try (var _tx = Transaction.openRoot()) {
								_fluidHandler.insert(FluidResource.of(TestModFluids.FLOWING_TEST_FLUID.get()), _fillAmount, _tx);
								_tx.commit();
							}
						}
					}
				}
				if (drainTankSimulate(world, BlockPos.containing(x, y, z), 100, null) > 0) {
					if (world instanceof ILevelExtension _ext) {
						if (_ext.getCapability(Capabilities.Fluid.BLOCK, BlockPos.containing(x, y, z), null) instanceof ResourceHandler<FluidResource> _fluidHandler) {
							int _drainAmount = 100;
							if (_drainAmount > 0) {
								try (var _tx = Transaction.openRoot()) {
									ResourceHandlerUtil.extractFirst(_fluidHandler, _ -> true, _drainAmount, _tx);
									_tx.commit();
								}
							}
						}
					}
				}
			}
		}
	}

	public static int getMaxEnergyStored(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler)
				return energyHandler.getCapacityAsInt();
		}
		return 0;
	}

	public static int getEnergyStored(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler)
				return energyHandler.getAmountAsInt();
		}
		return 0;
	}

	private static boolean canReceiveEnergy(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler)
				return energyHandler.getCapacityAsLong() > 0;
		}
		return false;
	}

	private static int receiveEnergySimulate(LevelAccessor level, BlockPos pos, int amount, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler) {
				try (var tx = Transaction.openRoot()) {
					return energyHandler.insert(amount, tx);
				}
			}
		}
		return 0;
	}

	private static boolean canExtractEnergy(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler)
				return energyHandler.getCapacityAsLong() > 0;
		}
		return false;
	}

	private static int extractEnergySimulate(LevelAccessor level, BlockPos pos, int amount, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Energy.BLOCK, pos, direction) instanceof EnergyHandler energyHandler) {
				try (var tx = Transaction.openRoot()) {
					return energyHandler.extract(amount, tx);
				}
			}
		}
		return 0;
	}

	private static int getBlockTanks(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Fluid.BLOCK, pos, direction) instanceof ResourceHandler<FluidResource> fluidHandler)
				return fluidHandler.size();
		}
		return 0;
	}

	private static int getFluidTankCapacity(LevelAccessor level, BlockPos pos, int tank, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Fluid.BLOCK, pos, direction) instanceof ResourceHandler<FluidResource> fluidHandler)
				return fluidHandler.getCapacityAsInt(tank, FluidResource.EMPTY);
		}
		return 0;
	}

	private static int getFluidTankLevel(LevelAccessor level, BlockPos pos, int tank, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Fluid.BLOCK, pos, direction) instanceof ResourceHandler<FluidResource> fluidHandler)
				return net.neoforged.neoforge.transfer.fluid.FluidUtil.getStack(fluidHandler, tank).amount();
		}
		return 0;
	}

	private static int fillTankSimulate(LevelAccessor level, BlockPos pos, int amount, Direction direction, Fluid fluid) {
		if (amount > 0 && level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Fluid.BLOCK, pos, direction) instanceof ResourceHandler<FluidResource> fluidHandler) {
				try (var tx = Transaction.openRoot()) {
					return fluidHandler.insert(FluidResource.of(fluid), amount, tx);
				}
			}
		}
		return 0;
	}

	private static int drainTankSimulate(LevelAccessor level, BlockPos pos, int amount, Direction direction) {
		if (amount > 0 && level instanceof ILevelExtension levelExtension) {
			if (levelExtension.getCapability(Capabilities.Fluid.BLOCK, pos, direction) instanceof ResourceHandler<FluidResource> fluidHandler) {
				try (var tx = Transaction.openRoot()) {
					return ResourceHandlerUtil.extractFirst(fluidHandler, _ -> true, amount, tx).amount();
				}
			}
		}
		return 0;
	}
}