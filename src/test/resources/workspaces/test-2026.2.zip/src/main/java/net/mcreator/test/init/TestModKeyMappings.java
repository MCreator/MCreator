/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import org.lwjgl.glfw.GLFW;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.test.network.TestKeyBindingMessage;
import net.mcreator.test.network.MouseKeyBindMessage;
import net.mcreator.test.network.DefaultKeyBindMessage;

import com.mojang.blaze3d.platform.InputConstants;

@EventBusSubscriber(Dist.CLIENT)
public class TestModKeyMappings {
	public static final KeyMapping TEST_KEY_BINDING = new KeyMapping("key.test.test_key_binding", GLFW.GLFW_KEY_O, KeyMapping.Category.MISC) {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ClientPacketDistributor.sendToServer(new TestKeyBindingMessage(0, 0));
				TestKeyBindingMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping DEFAULT_KEY_BIND = new KeyMapping("key.test.default_key_bind", GLFW.GLFW_KEY_UNKNOWN, KeyMapping.Category.MISC) {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				DEFAULT_KEY_BIND_LASTPRESS = System.currentTimeMillis();
			} else if (isDownOld != isDown && !isDown) {
				int dt = (int) (System.currentTimeMillis() - DEFAULT_KEY_BIND_LASTPRESS);
				ClientPacketDistributor.sendToServer(new DefaultKeyBindMessage(1, dt));
				DefaultKeyBindMessage.pressAction(Minecraft.getInstance().player, 1, dt);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping MOUSE_KEY_BIND = new KeyMapping("key.test.mouse_key_bind", InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_RIGHT, KeyMapping.Category.MISC) {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ClientPacketDistributor.sendToServer(new MouseKeyBindMessage(0, 0));
				MouseKeyBindMessage.pressAction(Minecraft.getInstance().player, 0, 0);
				MOUSE_KEY_BIND_LASTPRESS = System.currentTimeMillis();
			} else if (isDownOld != isDown && !isDown) {
				int dt = (int) (System.currentTimeMillis() - MOUSE_KEY_BIND_LASTPRESS);
				ClientPacketDistributor.sendToServer(new MouseKeyBindMessage(1, dt));
				MouseKeyBindMessage.pressAction(Minecraft.getInstance().player, 1, dt);
			}
			isDownOld = isDown;
		}
	};
	private static long DEFAULT_KEY_BIND_LASTPRESS = 0;
	private static long MOUSE_KEY_BIND_LASTPRESS = 0;

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(TEST_KEY_BINDING);
		event.register(DEFAULT_KEY_BIND);
		event.register(MOUSE_KEY_BIND);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(ClientTickEvent.Post event) {
			if (Minecraft.getInstance().screen == null) {
				TEST_KEY_BINDING.consumeClick();
				DEFAULT_KEY_BIND.consumeClick();
				MOUSE_KEY_BIND.consumeClick();
			}
		}
	}
}