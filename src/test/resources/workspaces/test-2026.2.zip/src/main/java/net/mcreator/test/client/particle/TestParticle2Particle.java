package net.mcreator.test.client.particle;

import org.joml.Quaternionf;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraft.util.RandomSource;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.client.renderer.state.level.QuadParticleRenderState;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.SingleQuadParticle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.Camera;

import net.mcreator.test.procedures.VectorProcedureProcedure;
import net.mcreator.test.procedures.NumberProvider2Procedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;

public class TestParticle2Particle extends SingleQuadParticle {
	public static TestParticle2ParticleProvider provider(SpriteSet spriteSet) {
		return new TestParticle2ParticleProvider(spriteSet);
	}

	public static class TestParticle2ParticleProvider implements ParticleProvider<SimpleParticleType> {
		private final SpriteSet spriteSet;

		public TestParticle2ParticleProvider(SpriteSet spriteSet) {
			this.spriteSet = spriteSet;
		}

		public Particle createParticle(SimpleParticleType typeIn, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, RandomSource random) {
			return new TestParticle2Particle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed, this.spriteSet);
		}
	}

	private final SpriteSet spriteSet;
	private float angularVelocity;
	private float angularAcceleration;

	protected TestParticle2Particle(ClientLevel world, double x, double y, double z, double vx, double vy, double vz, SpriteSet spriteSet) {
		super(world, x, y, z, spriteSet.first());
		this.spriteSet = spriteSet;
		this.setSize(0.7f, 0.7f);
		this.lifetime = (int) Math.max(1, 78 + (this.random.nextInt(42) - 21));
		this.gravity = 0.3f;
		this.hasPhysics = true;
		this.xd = vx * 2;
		this.yd = vy * 2;
		this.zd = vz * 2;
		this.angularVelocity = 0.2f;
		this.angularAcceleration = 0.02f;
		this.setSpriteFromAge(spriteSet);
	}

	@Override
	public int getLightCoords(float partialTick) {
		return 15728880;
	}

	@Override
	public SingleQuadParticle.Layer getLayer() {
		return SingleQuadParticle.Layer.TRANSLUCENT;
	}

	@Override
	public float getQuadSize(float scale) {
		Level world = this.level;
		return super.getQuadSize(scale) * (float) NumberProvider2Procedure.execute();
	}

	@Override
	public void extract(QuadParticleRenderState particleTypeRenderState, Camera camera, float partialTicks) {
		Vec3 vec = VectorProcedureProcedure.execute(this.x, this.y, this.z);
		Quaternionf tilt = new Quaternionf().rotationXYZ((float) vec.x(), (float) vec.y(), (float) vec.z());
		this.extractRotatedQuad(particleTypeRenderState, camera, tilt, partialTicks);
		Quaternionf flippedTilt = new Quaternionf(tilt).mul(new Quaternionf().rotateY((float) Math.PI));
		this.extractRotatedQuad(particleTypeRenderState, camera, flippedTilt, partialTicks);
	}

	@Override
	public void tick() {
		super.tick();
		this.oRoll = this.roll;
		this.roll += this.angularVelocity;
		this.angularVelocity += this.angularAcceleration;
		if (!this.removed) {
			this.setSprite(this.spriteSet.get((this.age / 2) % 38 + 1, 38));
		}
		Level world = this.level;
		if (LogicProcedureProcedure.execute())
			this.remove();
	}
}