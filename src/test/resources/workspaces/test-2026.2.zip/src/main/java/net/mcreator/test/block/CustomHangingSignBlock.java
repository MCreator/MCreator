package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.CeilingHangingSignBlock;

import net.mcreator.test.init.TestModWoodTypes;

public class CustomHangingSignBlock extends CeilingHangingSignBlock {
	public CustomHangingSignBlock(BlockBehaviour.Properties properties) {
		super(TestModWoodTypes.CUSTOM_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.GRAVEL).strength(1f, 10f).noCollision().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}