package net.mcreator.test.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.gui.widget.ExtendedSlider;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import net.mcreator.test.world.inventory.TestGUIMenu;
import net.mcreator.test.procedures.TextProcedureProcedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.procedures.EntityProviderProcedure;
import net.mcreator.test.network.TestGUISliderMessage;
import net.mcreator.test.network.TestGUIButtonMessage;
import net.mcreator.test.init.TestModScreens;

import java.util.stream.Collectors;
import java.util.Arrays;

import com.mojang.blaze3d.platform.InputConstants;

public class TestGUIScreen extends AbstractContainerScreen<TestGUIMenu> implements TestModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private EditBox testTextField;
	private Checkbox testCheckBox;
	private Button button_testbutton;
	private ImageButton imagebutton_block;
	private ExtendedSlider slider1;
	private static final Identifier BACKGROUND = Identifier.parse("test:textures/screens/test_gui.png");
	private static final Identifier SPRITE_0 = Identifier.parse("test:textures/screens/block.png");

	public TestGUIScreen(TestGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text, 263, 166);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 0 && elementState instanceof String stringState) {
			if (name.equals("testTextField"))
				testTextField.setValue(stringState);
		}
		if (elementType == 1 && elementState instanceof Boolean logicState) {
			if (name.equals("testCheckBox")) {
				if (testCheckBox.selected() != logicState)
					testCheckBox.onPress(null);
			}
		}
		if (elementType == 2 && elementState instanceof Number n) {
			if (name.equals("slider1"))
				slider1.setValue(n.doubleValue());
		}
		menuStateUpdateActive = false;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		if (LogicProcedureProcedure.execute())
			if (mouseX > leftPos + 206 && mouseX < leftPos + 230 && mouseY > topPos + 69 && mouseY < topPos + 93) {
				guiGraphics.setTooltipForNextFrame(font, Component.translatable("gui.test.test_gui.tooltip_empty"), mouseX, mouseY);
			}
		if (mouseX > leftPos + 207 && mouseX < leftPos + 231 && mouseY > topPos + 98 && mouseY < topPos + 122) {
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				guiGraphics.setComponentTooltipForNextFrame(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
			}
		}
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
		testTextField.extractWidgetRenderState(guiGraphics, mouseX, mouseY, partialTicks);
		if (EntityProviderProcedure.execute(entity) instanceof LivingEntity livingEntity) {
			if (LogicProcedureProcedure.execute())
				InventoryScreen.renderEntityInInventoryFollowsAngle(guiGraphics, this.leftPos + -977, this.topPos + -905, this.leftPos + 1023, this.topPos + 1095, 30, -livingEntity.getBbHeight() / (2.0f * livingEntity.getScale()),
						0.1f + (float) Math.atan((this.leftPos + 23 - mouseX) / 40.0), (float) Math.atan((this.topPos + 46 - mouseY) / 40.0), livingEntity);
		}
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractBackground(guiGraphics, mouseX, mouseY, partialTicks);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, SPRITE_0, this.leftPos + 233, this.topPos + 20, 0, 0, 16, 8, 16, 16);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = InputConstants.getKey(event).getValue();
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (testTextField.isFocused())
			return testTextField.keyPressed(event);
		return super.keyPressed(event);
	}

	@Override
	public void resize(int width, int height) {
		String testTextFieldValue = testTextField.getValue();
		super.resize(width, height);
		testTextField.setValue(testTextFieldValue);
	}

	@Override
	protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
		guiGraphics.text(this.font, Component.translatable("gui.test.test_gui.label_label_text"), 31, 31, -1, true);
	}

	@Override
	public void init() {
		super.init();
		testTextField = new EditBox(this.font, this.leftPos + 31, this.topPos + 45, 120, 20, Component.translatable("gui.test.test_gui.testTextField"));
		testTextField.setMaxLength(8192);
		testTextField.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "testTextField", content, false);
		});
		testTextField.setHint(Component.translatable("gui.test.test_gui.testTextField"));
		this.addWidget(this.testTextField);
		button_testbutton = Button.builder(Component.translatable("gui.test.test_gui.button_testbutton"), e -> {
			int x = TestGUIScreen.this.x;
			int y = TestGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new TestGUIButtonMessage(0, x, y, z));
				TestGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 31, this.topPos + 5, 100, 20).build();
		this.addRenderableWidget(button_testbutton);
		imagebutton_block = new ImageButton(this.leftPos + 12, this.topPos + 117, 16, 16, new WidgetSprites(Identifier.parse("test:textures/screens/block.png"), Identifier.parse("test:textures/screens/block.png")), e -> {
			int x = TestGUIScreen.this.x;
			int y = TestGUIScreen.this.y;
			if (LogicProcedureProcedure.execute()) {
				ClientPacketDistributor.sendToServer(new TestGUIButtonMessage(1, x, y, z));
				TestGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void extractContents(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
				int x = TestGUIScreen.this.x;
				int y = TestGUIScreen.this.y;
				if (LogicProcedureProcedure.execute())
					guiGraphics.blit(RenderPipelines.GUI_TEXTURED, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_block);
		testCheckBox = Checkbox.builder(Component.translatable("gui.test.test_gui.testCheckBox"), this.font).pos(this.leftPos + 156, this.topPos + 45).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "testCheckBox", value, false);
		}).build();
		this.addRenderableWidget(testCheckBox);
		slider1 = new ExtendedSlider(this.leftPos + 217, this.topPos + 139, 39, 20, Component.translatable("gui.test.test_gui.slider1_prefix"), Component.translatable("gui.test.test_gui.slider1_suffix"), 3, 16, 6, 4, 0, true) {
			@Override
			protected void applyValue() {
				if (!menuStateUpdateActive)
					menu.sendMenuStateUpdate(entity, 2, "slider1", this.getValue(), false);
				ClientPacketDistributor.sendToServer(new TestGUISliderMessage(0, x, y, z, this.getValue()));
				TestGUISliderMessage.handleSliderAction(entity, 0, x, y, z, this.getValue());
			}
		};
		this.addRenderableWidget(slider1);
		if (!menuStateUpdateActive)
			menu.sendMenuStateUpdate(entity, 2, "slider1", slider1.getValue(), false);
	}
}