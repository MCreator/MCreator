/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.RaftRenderer;
import net.minecraft.client.renderer.entity.BoatRenderer;

import net.mcreator.test.client.renderer.TestLivingEntityRenderer;
import net.mcreator.test.client.renderer.TestLivingEntity2Renderer;
import net.mcreator.test.client.renderer.TestEntity2Renderer;
import net.mcreator.test.client.renderer.ProjectileTwoRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class TestModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY.get(), TestLivingEntityRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_RANGED_ITEM_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_2.get(), TestLivingEntity2Renderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_ENTITY_2.get(), TestEntity2Renderer::new);
		event.registerEntityRenderer(TestModEntities.PROJECTILE_TWO.get(), ProjectileTwoRenderer::new);
		event.registerEntityRenderer(TestModEntities.BOAT_ONE.get(), context -> new BoatRenderer(context, TestModModels.BOAT_ONE_LAYER_LOCATION));
		event.registerEntityRenderer(TestModEntities.BOAT_TWO.get(), context -> new BoatRenderer(context, TestModModels.BOAT_TWO_LAYER_LOCATION));
		event.registerEntityRenderer(TestModEntities.CUSTOM_RAFT.get(), context -> new RaftRenderer(context, TestModModels.CUSTOM_RAFT_LAYER_LOCATION));
		event.registerEntityRenderer(TestModEntities.CUSTOM_CHEST_RAFT.get(), context -> new RaftRenderer(context, TestModModels.CUSTOM_CHEST_RAFT_LAYER_LOCATION));
	}
}