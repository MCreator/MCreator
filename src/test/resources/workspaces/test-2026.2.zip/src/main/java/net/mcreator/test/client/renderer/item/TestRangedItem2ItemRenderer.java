package net.mcreator.test.client.renderer.item;

import org.joml.Vector3fc;

import net.neoforged.neoforge.client.event.RegisterSpecialModelRendererEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.animation.KeyframeAnimation;
import net.minecraft.client.animation.AnimationDefinition;

import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.client.model.animations.MonsterAnimation;
import net.mcreator.test.client.model.ModelKreper117;

import java.util.stream.IntStream;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.WeakHashMap;
import java.util.Optional;
import java.util.Map;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.MapCodec;
import com.mojang.blaze3d.vertex.PoseStack;

@EventBusSubscriber(Dist.CLIENT)
public class TestRangedItem2ItemRenderer implements SpecialModelRenderer<ItemStack> {
	@SubscribeEvent
	public static void registerItemRenderers(RegisterSpecialModelRendererEvent event) {
		event.register(Identifier.parse("test:test_ranged_item_2"), TestRangedItem2ItemRenderer.Unbaked.MAP_CODEC);
	}

	private static final Map<Integer, Function<Unbaked.CustomBakingContext, TestRangedItem2ItemRenderer>> MODELS = Map.ofEntries(
			Map.entry(-1, context -> new TestRangedItem2ItemRenderer(new AnimatedModel(context.bakingContext().entityModelSet().bakeLayer(ModelKreper117.LAYER_LOCATION)), Identifier.parse("test:textures/item/item.png"), context.display())));
	private final EntityModel<LivingEntityRenderState> model;
	private final Identifier texture;
	private final ItemDisplayContext displayContext;
	private final LivingEntityRenderState renderState;
	private final long start;

	private TestRangedItem2ItemRenderer(EntityModel<LivingEntityRenderState> model, Identifier texture, ItemDisplayContext displayContext) {
		this.model = model;
		this.texture = texture;
		this.displayContext = displayContext;
		this.renderState = new LivingEntityRenderState();
		this.start = System.currentTimeMillis();
	}

	@Override
	public void submit(ItemStack itemstack, PoseStack poseStack, SubmitNodeCollector submitNodeCollector, int lightCoords, int overlayCoords, boolean glint, int outlineColor) {
		updateRenderState(itemstack);
		poseStack.pushPose();
		poseStack.translate(0.5, isInventory(displayContext) ? 1.5 : 2, 0.5);
		poseStack.scale(1, -1, displayContext == ItemDisplayContext.GUI ? -1 : 1);
		renderState.ageInTicks = (System.currentTimeMillis() - start) / 50.0f;
		if (model instanceof AnimatedModel animatedModel)
			animatedModel.setupItemStackAnim(this, itemstack, renderState);
		else
			model.setupAnim(renderState);
		submitNodeCollector.submitModel(this.model, renderState, poseStack, texture, lightCoords, overlayCoords, outlineColor, null);
		if (glint) {
			submitNodeCollector.submitModel(this.model, renderState, poseStack, RenderTypes.entityGlint(), lightCoords, overlayCoords, -1, null);
		}
		poseStack.popPose();
	}

	@Override
	public ItemStack extractArgument(ItemStack itemstack) {
		return itemstack;
	}

	@Override
	public void getExtents(Consumer<Vector3fc> output) {
		PoseStack posestack = new PoseStack();
		this.model.root().getExtentsForGui(posestack, output);
	}

	private static boolean isInventory(ItemDisplayContext type) {
		return type == ItemDisplayContext.GUI || type == ItemDisplayContext.FIXED;
	}

	public record Unbaked(int index, ItemDisplayContext display) implements SpecialModelRenderer.Unbaked<ItemStack> {
		public static final MapCodec<TestRangedItem2ItemRenderer.Unbaked> MAP_CODEC = RecordCodecBuilder
				.mapCodec(instance -> instance.group(ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("index").xmap(opt -> opt.orElse(-1), i -> i == -1 ? Optional.empty() : Optional.of(i)).forGetter(TestRangedItem2ItemRenderer.Unbaked::index),
						ItemDisplayContext.CODEC.optionalFieldOf("display", ItemDisplayContext.NONE).forGetter(TestRangedItem2ItemRenderer.Unbaked::display)).apply(instance, TestRangedItem2ItemRenderer.Unbaked::new));

		@Override
		public MapCodec<TestRangedItem2ItemRenderer.Unbaked> type() {
			return MAP_CODEC;
		}

		@Override
		public SpecialModelRenderer<ItemStack> bake(BakingContext bakingContext) {
			return TestRangedItem2ItemRenderer.MODELS.get(index).apply(new CustomBakingContext(bakingContext, display));
		}

		public record CustomBakingContext(BakingContext bakingContext, ItemDisplayContext display) {
		}
	}

	private final Map<ItemStack, Map<Integer, AnimationState>> CACHE = new WeakHashMap<>();

	private Map<Integer, AnimationState> getAnimationState(ItemStack stack) {
		return CACHE.computeIfAbsent(stack, s -> IntStream.range(0, 2).boxed().collect(Collectors.toMap(i -> i, i -> new AnimationState(), (a, b) -> b)));
	}

	private void updateRenderState(ItemStack itemstack) {
		int tickCount = (int) (System.currentTimeMillis() - start) / 50;
		getAnimationState(itemstack).get(0).animateWhen(true, tickCount);
		getAnimationState(itemstack).get(1).animateWhen(LogicProcedureProcedure.execute(), tickCount);
	}

	private static final class AnimatedModel extends ModelKreper117 {
		private final KeyframeAnimation keyframeAnimation0;
		private final KeyframeAnimation keyframeAnimation1;

		public AnimatedModel(ModelPart root) {
			super(root);
			this.keyframeAnimation0 = safeBake(MonsterAnimation.MONSTER_IDLE);
			this.keyframeAnimation1 = safeBake(MonsterAnimation.MONSTER_ATTACK1);
		}

		private KeyframeAnimation safeBake(AnimationDefinition source) {
			try {
				return source.bake(root);
			} catch (IllegalArgumentException e) {
				return new AnimationDefinition(0, false, Map.of()).bake(root);
			}
		}

		public void setupItemStackAnim(TestRangedItem2ItemRenderer renderer, ItemStack itemstack, LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.keyframeAnimation0.apply(renderer.getAnimationState(itemstack).get(0), state.ageInTicks, 1f);
			this.keyframeAnimation1.apply(renderer.getAnimationState(itemstack).get(1), state.ageInTicks, 1.4f);
			super.setupAnim(state);
		}
	}
}