/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.Identifier;
import net.minecraft.client.model.object.boat.RaftModel;
import net.minecraft.client.model.object.boat.BoatModel;
import net.minecraft.client.model.geom.ModelLayerLocation;

import net.mcreator.test.client.model.ModelKreper117;

@EventBusSubscriber(Dist.CLIENT)
public class TestModModels {
	public static final ModelLayerLocation BOAT_ONE_LAYER_LOCATION = new ModelLayerLocation(Identifier.parse("test:boat/boat_one"), "main");
	public static final ModelLayerLocation CUSTOM_RAFT_LAYER_LOCATION = new ModelLayerLocation(Identifier.parse("test:boat/custom_raft"), "main");
	public static final ModelLayerLocation BOAT_TWO_LAYER_LOCATION = new ModelLayerLocation(Identifier.parse("test:boat/boat_two"), "main");
	public static final ModelLayerLocation CUSTOM_CHEST_RAFT_LAYER_LOCATION = new ModelLayerLocation(Identifier.parse("test:chest_boat/custom_chest_raft"), "main");

	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelKreper117.LAYER_LOCATION, ModelKreper117::createBodyLayer);
		event.registerLayerDefinition(BOAT_ONE_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(CUSTOM_RAFT_LAYER_LOCATION, RaftModel::createRaftModel);
		event.registerLayerDefinition(BOAT_TWO_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(CUSTOM_CHEST_RAFT_LAYER_LOCATION, RaftModel::createChestRaftModel);
	}
}