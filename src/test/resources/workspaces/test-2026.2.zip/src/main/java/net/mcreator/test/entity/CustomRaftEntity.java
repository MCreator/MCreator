package net.mcreator.test.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.boat.Raft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;

import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.init.TestModItems;

public class CustomRaftEntity extends Raft {
	public CustomRaftEntity(EntityType<CustomRaftEntity> type, Level world) {
		super(type, world, TestModItems.CUSTOM_RAFT);
	}

	@Override
	public void baseTick() {
		super.baseTick();
		TestProcedureProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ());
	}

	@Override
	public void playerTouch(Player sourceentity) {
		super.playerTouch(sourceentity);
		TestProcedureProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ());
	}
}