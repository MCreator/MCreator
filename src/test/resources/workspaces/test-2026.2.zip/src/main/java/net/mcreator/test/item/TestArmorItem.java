package net.mcreator.test.item;

import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.procedures.TextProcedureProcedure;
import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.init.TestModAttributes;
import net.mcreator.test.TestMod;

import javax.annotation.Nullable;

import java.util.function.Consumer;
import java.util.Map;

public abstract class TestArmorItem extends Item {
	public static ArmorMaterial ARMOR_MATERIAL = new ArmorMaterial(25, Map.of(ArmorType.BOOTS, 2, ArmorType.LEGGINGS, 5, ArmorType.CHESTPLATE, 6, ArmorType.HELMET, 2, ArmorType.BODY, 6), 9,
			DeferredHolder.create(Registries.SOUND_EVENT, Identifier.parse("block.anvil.land")), 0.1f, 0f, TagKey.create(Registries.ITEM, Identifier.parse("test:test_armor_repair_items")),
			ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.parse("test:test_armor")));

	private TestArmorItem(Item.Properties properties) {
		super(properties);
	}

	public static class Helmet extends TestArmorItem {
		public Helmet(Item.Properties properties) {
			super(properties.fireResistant().rarity(Rarity.RARE).humanoidArmor(ARMOR_MATERIAL, ArmorType.HELMET)
					.attributes(ItemAttributeModifiers.builder().add(Attributes.ARMOR, new AttributeModifier(Identifier.withDefaultNamespace("armor.helmet"), 2, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.HEAD)
							.add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(Identifier.withDefaultNamespace("armor.helmet"), 0.1, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.HEAD)
							.add(NeoForgeMod.NAMETAG_DISTANCE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_0.helmet"), 54, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(TestModAttributes.DEMO_ATTRIBUTE_2, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_1.helmet"), 1.23, AttributeModifier.Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.ANY)
							.build()));
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			Entity entity = TestMod.clientPlayer();
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				for (String line : hoverText.split("\n")) {
					componentConsumer.accept(Component.literal(line));
				}
			}
		}

		@Override
		public void inventoryTick(ItemStack itemstack, ServerLevel world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
			super.inventoryTick(itemstack, world, entity, equipmentSlot);
			if (entity instanceof Player player && (equipmentSlot != null && equipmentSlot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR)) {
				TestProcedureProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
			}
		}
	}

	public static class Chestplate extends TestArmorItem {
		public Chestplate(Item.Properties properties) {
			super(properties.fireResistant().rarity(Rarity.RARE).humanoidArmor(ARMOR_MATERIAL, ArmorType.CHESTPLATE)
					.attributes(ItemAttributeModifiers.builder().add(Attributes.ARMOR, new AttributeModifier(Identifier.withDefaultNamespace("armor.chestplate"), 6, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.CHEST)
							.add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(Identifier.withDefaultNamespace("armor.chestplate"), 0.1, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.CHEST)
							.add(NeoForgeMod.NAMETAG_DISTANCE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_0.chestplate"), 54, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(Attributes.SCALE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_1.chestplate"), 45, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(TestModAttributes.DEMO_ATTRIBUTE_2, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_2.chestplate"), 1.23, AttributeModifier.Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.ANY)
							.build()));
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			Entity entity = TestMod.clientPlayer();
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				for (String line : hoverText.split("\n")) {
					componentConsumer.accept(Component.literal(line));
				}
			}
		}

		@Override
		public boolean makesPiglinsNeutral(ItemStack itemstack, LivingEntity entity) {
			return true;
		}

		@Override
		public void inventoryTick(ItemStack itemstack, ServerLevel world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
			super.inventoryTick(itemstack, world, entity, equipmentSlot);
			if (entity instanceof Player player && (equipmentSlot != null && equipmentSlot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR)) {
				TestProcedureProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
			}
		}
	}

	public static class Leggings extends TestArmorItem {
		public Leggings(Item.Properties properties) {
			super(properties.rarity(Rarity.RARE).humanoidArmor(ARMOR_MATERIAL, ArmorType.LEGGINGS)
					.attributes(ItemAttributeModifiers.builder().add(Attributes.ARMOR, new AttributeModifier(Identifier.withDefaultNamespace("armor.leggings"), 5, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.LEGS)
							.add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(Identifier.withDefaultNamespace("armor.leggings"), 0.1, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.LEGS)
							.add(NeoForgeMod.NAMETAG_DISTANCE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_0.leggings"), 54, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(Attributes.SCALE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_1.leggings"), 45, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(TestModAttributes.DEMO_ATTRIBUTE_2, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_2.leggings"), 1.23, AttributeModifier.Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.ANY)
							.add(Attributes.ATTACK_SPEED, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_3.leggings"), 0.003, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL), EquipmentSlotGroup.ANY).build()));
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			Entity entity = TestMod.clientPlayer();
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				for (String line : hoverText.split("\n")) {
					componentConsumer.accept(Component.literal(line));
				}
			}
		}

		@Override
		public boolean isFoil(ItemStack itemstack) {
			return LogicProcedureProcedure.execute();
		}

		@Override
		public boolean makesPiglinsNeutral(ItemStack itemstack, LivingEntity entity) {
			return LogicProcedureProcedure.execute();
		}

		@Override
		public void inventoryTick(ItemStack itemstack, ServerLevel world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
			super.inventoryTick(itemstack, world, entity, equipmentSlot);
			if (entity instanceof Player player && (equipmentSlot != null && equipmentSlot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR)) {
				TestProcedureProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
			}
		}
	}

	public static class Boots extends TestArmorItem {
		public Boots(Item.Properties properties) {
			super(properties.fireResistant().rarity(Rarity.RARE).humanoidArmor(ARMOR_MATERIAL, ArmorType.BOOTS)
					.attributes(ItemAttributeModifiers.builder().add(Attributes.ARMOR, new AttributeModifier(Identifier.withDefaultNamespace("armor.boots"), 2, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.FEET)
							.add(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(Identifier.withDefaultNamespace("armor.boots"), 0.1, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.FEET)
							.add(NeoForgeMod.NAMETAG_DISTANCE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_0.boots"), 54, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(Attributes.SCALE, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_1.boots"), 45, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.ANY)
							.add(TestModAttributes.DEMO_ATTRIBUTE_2, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_2.boots"), 1.23, AttributeModifier.Operation.ADD_MULTIPLIED_BASE), EquipmentSlotGroup.ANY)
							.add(Attributes.ATTACK_SPEED, new AttributeModifier(Identifier.fromNamespaceAndPath(TestMod.MODID, "test_armor_3.boots"), 0.003, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL), EquipmentSlotGroup.ANY).build()));
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			Entity entity = TestMod.clientPlayer();
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				for (String line : hoverText.split("\n")) {
					componentConsumer.accept(Component.literal(line));
				}
			}
		}

		@Override
		public boolean isFoil(ItemStack itemstack) {
			return true;
		}

		@Override
		public boolean makesPiglinsNeutral(ItemStack itemstack, LivingEntity entity) {
			return LogicProcedureProcedure.execute();
		}

		@Override
		public void inventoryTick(ItemStack itemstack, ServerLevel world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
			super.inventoryTick(itemstack, world, entity, equipmentSlot);
			if (entity instanceof Player player && (equipmentSlot != null && equipmentSlot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR)) {
				TestProcedureProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
			}
		}
	}
}