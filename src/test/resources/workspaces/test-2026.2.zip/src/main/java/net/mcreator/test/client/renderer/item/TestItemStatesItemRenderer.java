package net.mcreator.test.client.renderer.item;

import org.joml.Vector3fc;

import net.neoforged.neoforge.client.event.RegisterSpecialModelRendererEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.model.EntityModel;

import net.mcreator.test.client.model.ModelKreper117;

import java.util.function.Function;
import java.util.function.Consumer;
import java.util.Optional;
import java.util.Map;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.MapCodec;
import com.mojang.blaze3d.vertex.PoseStack;

@EventBusSubscriber(Dist.CLIENT)
public class TestItemStatesItemRenderer implements SpecialModelRenderer<ItemStack> {
	@SubscribeEvent
	public static void registerItemRenderers(RegisterSpecialModelRendererEvent event) {
		event.register(Identifier.parse("test:test_item_states"), TestItemStatesItemRenderer.Unbaked.MAP_CODEC);
	}

	private static final Map<Integer, Function<Unbaked.CustomBakingContext, TestItemStatesItemRenderer>> MODELS = Map.ofEntries(
			Map.entry(2, context -> new TestItemStatesItemRenderer(new ModelKreper117(context.bakingContext().entityModelSet().bakeLayer(ModelKreper117.LAYER_LOCATION)), Identifier.parse("minecraft:textures/item/clock_56.png"), context.display())));
	private final EntityModel<LivingEntityRenderState> model;
	private final Identifier texture;
	private final ItemDisplayContext displayContext;
	private final LivingEntityRenderState renderState;
	private final long start;

	private TestItemStatesItemRenderer(EntityModel<LivingEntityRenderState> model, Identifier texture, ItemDisplayContext displayContext) {
		this.model = model;
		this.texture = texture;
		this.displayContext = displayContext;
		this.renderState = new LivingEntityRenderState();
		this.start = System.currentTimeMillis();
	}

	@Override
	public void submit(ItemStack itemstack, PoseStack poseStack, SubmitNodeCollector submitNodeCollector, int lightCoords, int overlayCoords, boolean glint, int outlineColor) {
		poseStack.pushPose();
		poseStack.translate(0.5, isInventory(displayContext) ? 1.5 : 2, 0.5);
		poseStack.scale(1, -1, displayContext == ItemDisplayContext.GUI ? -1 : 1);
		renderState.ageInTicks = (System.currentTimeMillis() - start) / 50.0f;
		model.setupAnim(renderState);
		submitNodeCollector.submitModel(this.model, renderState, poseStack, texture, lightCoords, overlayCoords, outlineColor, null);
		if (glint) {
			submitNodeCollector.submitModel(this.model, renderState, poseStack, RenderTypes.entityGlint(), lightCoords, overlayCoords, -1, null);
		}
		poseStack.popPose();
	}

	@Override
	public ItemStack extractArgument(ItemStack itemstack) {
		return itemstack;
	}

	@Override
	public void getExtents(Consumer<Vector3fc> output) {
		PoseStack posestack = new PoseStack();
		this.model.root().getExtentsForGui(posestack, output);
	}

	private static boolean isInventory(ItemDisplayContext type) {
		return type == ItemDisplayContext.GUI || type == ItemDisplayContext.FIXED;
	}

	public record Unbaked(int index, ItemDisplayContext display) implements SpecialModelRenderer.Unbaked<ItemStack> {
		public static final MapCodec<TestItemStatesItemRenderer.Unbaked> MAP_CODEC = RecordCodecBuilder
				.mapCodec(instance -> instance.group(ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("index").xmap(opt -> opt.orElse(-1), i -> i == -1 ? Optional.empty() : Optional.of(i)).forGetter(TestItemStatesItemRenderer.Unbaked::index),
						ItemDisplayContext.CODEC.optionalFieldOf("display", ItemDisplayContext.NONE).forGetter(TestItemStatesItemRenderer.Unbaked::display)).apply(instance, TestItemStatesItemRenderer.Unbaked::new));

		@Override
		public MapCodec<TestItemStatesItemRenderer.Unbaked> type() {
			return MAP_CODEC;
		}

		@Override
		public SpecialModelRenderer<ItemStack> bake(BakingContext bakingContext) {
			return TestItemStatesItemRenderer.MODELS.get(index).apply(new CustomBakingContext(bakingContext, display));
		}

		public record CustomBakingContext(BakingContext bakingContext, ItemDisplayContext display) {
		}
	}
}