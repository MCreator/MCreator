package net.mcreator.test.procedures;

import net.neoforged.neoforge.server.ServerLifecycleHooks;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.storage.WritableLevelData;
import net.minecraft.world.level.storage.LevelData;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.animal.squid.GlowSquid;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.clock.WorldClock;
import net.minecraft.world.clock.ServerClockManager;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.Difficulty;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.functions.CommandFunction;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.client.Minecraft;

import net.mcreator.test.init.TestModParticleTypes;
import net.mcreator.test.init.TestModGameRules;
import net.mcreator.test.init.TestModEntities;
import net.mcreator.test.block.TestDimensionPortalBlock;

import java.util.Optional;
import java.util.Comparator;
import java.util.ArrayList;

public class TestWorldProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands()
					.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), "clear");
		if (world instanceof Level _level && !_level.isClientSide())
			_level.explode(null, (world.getLevelData().getRespawnData().pos().getX()), (world.getLevelData().getRespawnData().pos().getY()), (world.getLevelData().getRespawnData().pos().getZ()), world.players().size(),
					Level.ExplosionInteraction.BLOCK);
		if (world instanceof ServerLevel _serverworld) {
			StructureTemplate template = _serverworld.getStructureManager().getOrCreate(Identifier.fromNamespaceAndPath("test", "plain_village_wheat_culture"));
			if (template != null) {
				template.placeInWorld(_serverworld, BlockPos.containing(x, y, z), BlockPos.containing(x, y, z), new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.LEFT_RIGHT).setIgnoreEntities(false),
						_serverworld.getRandom(), 3);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("music.game")), SoundSource.NEUTRAL,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z) * (((world instanceof Level _lvl_getIndPow ? _lvl_getIndPow.getBestNeighborSignal(BlockPos.containing(x, y, z)) : 0)
								- (world instanceof Level _lvl_getRedPow ? _lvl_getRedPow.getSignal(BlockPos.containing(x, y, z), (getDirectionFromBlockState((world.getBlockState(BlockPos.containing(x, y, z)))))) : 0))
								/ (world.getBiome(BlockPos.containing(x, y, z)).value().getBaseTemperature() * 100f + world.getMaxLocalRawBrightness(BlockPos.containing(x, y, z)))))
								% (world.isClientSide() ? Minecraft.getInstance().getConnection().getOnlinePlayers().size() : ServerLifecycleHooks.getCurrentServer().getPlayerCount()),
						Mth.nextInt(RandomSource.create(), 1, 5));
			} else {
				_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("music.game")), SoundSource.NEUTRAL,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z) * (((world instanceof Level _lvl_getIndPow ? _lvl_getIndPow.getBestNeighborSignal(BlockPos.containing(x, y, z)) : 0)
								- (world instanceof Level _lvl_getRedPow ? _lvl_getRedPow.getSignal(BlockPos.containing(x, y, z), (getDirectionFromBlockState((world.getBlockState(BlockPos.containing(x, y, z)))))) : 0))
								/ (world.getBiome(BlockPos.containing(x, y, z)).value().getBaseTemperature() * 100f + world.getMaxLocalRawBrightness(BlockPos.containing(x, y, z)))))
								% (world.isClientSide() ? Minecraft.getInstance().getConnection().getOnlinePlayers().size() : ServerLifecycleHooks.getCurrentServer().getPlayerCount()),
						Mth.nextInt(RandomSource.create(), 1, 5), false);
			}
		}
		if (world instanceof ServerLevel _level && _level.getServer() != null) {
			Optional<CommandFunction<CommandSourceStack>> _fopt = _level.getServer().getFunctions().get(Identifier.parse("minecraft:load"));
			if (_fopt.isPresent())
				_level.getServer().getFunctions().execute(_fopt.get(),
						new CommandSourceStack(CommandSource.NULL, new Vec3((world.getLevelData().getRespawnData().pos().getX()), (world.getLevelData().getRespawnData().pos().getY()), (world.getLevelData().getRespawnData().pos().getZ())), Vec2.ZERO,
								_level, LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null));
		}
		if (world instanceof ServerLevel _level) {
			ServerClockManager _clockManager = _level.getServer().clockManager();
			Optional<Holder<WorldClock>> _clock = _level.dimensionType().defaultClock();
			if (_clock.isPresent())
				_clockManager.setTotalTicks(_clock.get(), (int) world.getGameTime());
		}
		if (world.getLevelData() instanceof WritableLevelData _levelData && world instanceof Level _level)
			_levelData.setSpawn(LevelData.RespawnData.of(_level.dimension(), BlockPos.containing(x, y, z), 0.0F, 0.0F));
		if (((world instanceof Level _lvl24 && _lvl24.isBrightOutside() && world.isClientSide()) != world.isEmptyBlock(BlockPos.containing(x, y, z))) == (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("test:test_biome"))
				^ world.getBiome(BlockPos.containing(x, y, z)).is(TagKey.create(Registries.BIOME, Identifier.parse("test:test4"))) || world instanceof Level _level29 && _level29.hasNeighborSignal(BlockPos.containing(x, y, z)))) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, world.environmentAttributes().getValue(EnvironmentAttributes.MOON_PHASE, BlockPos.ZERO).index()));
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = TestModEntities.TEST_LIVING_ENTITY.get().spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(
						(BuiltInRegistries.ITEM.getRandomElementOf(ItemTags.create(Identifier.parse("minecraft:cluster_max_harvestables")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value())));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			world.addParticle(ParticleTypes.BUBBLE, x, y, z, 0, 1, 0);
		}
		for (Entity entityiterator : new ArrayList<>(world.players())) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = EntityType.AXOLOTL.spawn(_level, BlockPos.containing(entityiterator.getX(), entityiterator.getY(), entityiterator.getZ()), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(entityiterator.getYRot());
					entityToSpawn.setYBodyRot(entityiterator.getYRot());
					entityToSpawn.setYHeadRot(entityiterator.getYRot());
					entityToSpawn.setXRot(entityiterator.getXRot());
				}
			}
		}
		if (!world.getEntitiesOfClass(GlowSquid.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3(x, y, z)).inflate(4 / 2d), e -> true).isEmpty()
				&& (world.getDifficulty() == Difficulty.PEACEFUL || world.canSeeSkyFromBelowWater(BlockPos.containing(x, y, z)))
						^ (world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)) == ResourceKey.create(Registries.DIMENSION, Identifier.parse("test:test_dimension"))) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = EntityType.AXOLOTL.spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot((findEntityInWorldRange(world, GlowSquid.class, x, y, z, 4)).getYRot());
					entityToSpawn.setYBodyRot((findEntityInWorldRange(world, GlowSquid.class, x, y, z, 4)).getYRot());
					entityToSpawn.setYHeadRot((findEntityInWorldRange(world, GlowSquid.class, x, y, z, 4)).getYRot());
					entityToSpawn.setXRot((findEntityInWorldRange(world, GlowSquid.class, x, y, z, 4)).getXRot());
					entityToSpawn.setDeltaMovement(0, 0, 0);
				}
			}
		}
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (TestModParticleTypes.TEST_PARTICLE.get()), x, y, z, (int) Mth.nextDouble(RandomSource.create(), 3, 16), 3, 3, 3, 1);
		{
			final Vec3 _center = new Vec3(x, y, z);
			for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
					entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(entityiterator.getX(), entityiterator.getY(), entityiterator.getZ())));;
					_level.addFreshEntity(entityToSpawn);
				}
			}
		}
		if (world instanceof ServerLevel _origLevel) {
			LevelAccessor _switchworld65 = _origLevel.getServer().getLevel(Level.OVERWORLD);
			if (_switchworld65 != null) {
				worldSwitch65(world, x, y, z);
			}
		}
		if (world instanceof Level _level)
			TestDimensionPortalBlock.portalSpawn(_level, BlockPos.containing(x, y, z));
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Hello world!"), false);
		}
		if (world instanceof ServerLevel _level && _level.getServer() != null) {
			_level.getServer().setWeatherParameters(0, ServerLevel.RAIN_DURATION.sample(_level.getRandom()), true, false);
		}
		if (world instanceof ServerLevel _level)
			FallingBlockEntity.fall(_level, BlockPos.containing(x, y, z),
					(BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(Identifier.parse("minecraft:enderman_holdable")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value()).defaultBlockState());
		if (world instanceof ServerLevel _level73
				&& _level73.holderOrThrow(ResourceKey.create(Registries.CONFIGURED_FEATURE, Identifier.parse("test:test_block"))).value().place(_level73, _level73.getChunkSource().getGenerator(), _level73.getRandom(), BlockPos.containing(x, y, z))) {
			if (world instanceof ServerLevel _level)
				_level.holderOrThrow(ResourceKey.create(Registries.CONFIGURED_FEATURE, Identifier.parse("test:test_structure_feature"))).value().place(_level, _level.getChunkSource().getGenerator(), _level.getRandom(), BlockPos.containing(x, y, z));
			if (world instanceof ServerLevel _level) {
				BlockPos _bp = BlockPos.containing(x, y, z);
				if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), _level, _bp, null) || BoneMealItem.growWaterPlant(new ItemStack(Items.BONE_MEAL), _level, _bp, null)) {
					_level.levelEvent(2005, _bp, 0);
				}
			}
		}
	}

	private static void worldSwitch65(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _serverLevel)
			_serverLevel.getGameRules().set(GameRules.KEEP_INVENTORY, (world instanceof ServerLevel _serverLevelGR61 && _serverLevelGR61.getGameRules().get(GameRules.KEEP_INVENTORY)), world.getServer());
		if (world instanceof ServerLevel _serverLevel)
			_serverLevel.getGameRules().set(TestModGameRules.TEST_RULE.get(), (world instanceof ServerLevel _serverLevelGR63 ? _serverLevelGR63.getGameRules().get(TestModGameRules.TEST_RULE.get()) : 0), world.getServer());
	}

	private static Direction getDirectionFromBlockState(BlockState blockState) {
		if (getPropertyByName(blockState, "facing") instanceof EnumProperty ep && ep.getValueClass() == Direction.class)
			return (Direction) blockState.getValue(ep);
		if (getPropertyByName(blockState, "axis") instanceof EnumProperty ep && ep.getValueClass() == Direction.Axis.class)
			return Direction.fromAxisAndDirection((Direction.Axis) blockState.getValue(ep), Direction.AxisDirection.POSITIVE);
		return Direction.NORTH;
	}

	private static Entity findEntityInWorldRange(LevelAccessor world, Class<? extends Entity> clazz, double x, double y, double z, double range) {
		return (Entity) world.getEntitiesOfClass(clazz, AABB.ofSize(new Vec3(x, y, z), range, range, range), e -> true).stream().sorted(Comparator.comparingDouble(e -> e.distanceToSqr(x, y, z))).findFirst().orElse(null);
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}
}