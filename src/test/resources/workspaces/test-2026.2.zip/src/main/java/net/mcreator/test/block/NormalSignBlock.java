package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.test.init.TestModWoodTypes;

public class NormalSignBlock extends StandingSignBlock {
	public NormalSignBlock(BlockBehaviour.Properties properties) {
		super(TestModWoodTypes.NORMAL_SIGN_WOOD_TYPE, properties.sound(SoundType.GRAVEL).strength(1f, 10f).noCollision().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}