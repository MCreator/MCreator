package net.mcreator.test.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.boat.ChestRaft;
import net.minecraft.world.entity.EntityType;

import net.mcreator.test.init.TestModItems;

public class CustomChestRaftEntity extends ChestRaft {
	public CustomChestRaftEntity(EntityType<CustomChestRaftEntity> type, Level world) {
		super(type, world, TestModItems.CUSTOM_CHEST_RAFT);
	}
}