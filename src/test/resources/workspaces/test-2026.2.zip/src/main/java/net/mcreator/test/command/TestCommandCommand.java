package net.mcreator.test.command;

import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.commands.BossBarCommands;
import net.minecraft.core.Direction;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.commands.arguments.IdentifierArgument;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.Commands;

import net.mcreator.test.procedures.TestCommandProcedureBlocksProcedure;

import java.util.HashMap;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;

@EventBusSubscriber
public class TestCommandCommand {
	@SubscribeEvent
	public static void registerCommand(RegisterCommandsEvent event) {
		if (event.getCommandSelection() == Commands.CommandSelection.DEDICATED)
			event.getDispatcher().register(Commands.literal("test123").requires(Commands.hasPermission(Commands.LEVEL_OWNERS))
					.then(Commands.argument("logic", BoolArgumentType.bool()).then(Commands.argument("number", DoubleArgumentType.doubleArg(16, 64)).then(Commands.argument("string", StringArgumentType.string())
							.then(Commands.argument("blockpos", BlockPosArgument.blockPos()).then(Commands.argument("entity", EntityArgument.entity()).then(Commands.argument("arguments", StringArgumentType.greedyString()).executes(arguments -> {
								Level world = arguments.getSource().getUnsidedLevel();
								double x = arguments.getSource().getPosition().x();
								double y = arguments.getSource().getPosition().y();
								double z = arguments.getSource().getPosition().z();
								Entity entity = arguments.getSource().getEntity();
								if (entity == null && world instanceof ServerLevel _servLevel)
									entity = FakePlayerFactory.getMinecraft(_servLevel);
								Direction direction = Direction.DOWN;
								if (entity != null)
									direction = entity.getDirection();
								HashMap<String, String> cmdparams = new HashMap<>();
								int index = -1;
								for (String param : arguments.getInput().split("\\s+")) {
									if (index >= 0)
										cmdparams.put(Integer.toString(index), param);
									index++;
								}

								TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
								return 0;
							})).executes(arguments -> {
								Level world = arguments.getSource().getUnsidedLevel();
								double x = arguments.getSource().getPosition().x();
								double y = arguments.getSource().getPosition().y();
								double z = arguments.getSource().getPosition().z();
								Entity entity = arguments.getSource().getEntity();
								if (entity == null && world instanceof ServerLevel _servLevel)
									entity = FakePlayerFactory.getMinecraft(_servLevel);
								Direction direction = Direction.DOWN;
								if (entity != null)
									direction = entity.getDirection();
								HashMap<String, String> cmdparams = new HashMap<>();
								int index = -1;
								for (String param : arguments.getInput().split("\\s+")) {
									if (index >= 0)
										cmdparams.put(Integer.toString(index), param);
									index++;
								}

								TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
								return 0;
							})).then(Commands.argument("entities", EntityArgument.entities())
									.then(Commands.argument("blockstate", BlockStateArgument.block(event.getBuildContext())).then(Commands.argument("itemstack", ItemArgument.item(event.getBuildContext()))
											.then(Commands.argument("message", MessageArgument.message()).then(Commands.argument("arguments", StringArgumentType.greedyString()).executes(arguments -> {
												Level world = arguments.getSource().getUnsidedLevel();
												double x = arguments.getSource().getPosition().x();
												double y = arguments.getSource().getPosition().y();
												double z = arguments.getSource().getPosition().z();
												Entity entity = arguments.getSource().getEntity();
												if (entity == null && world instanceof ServerLevel _servLevel)
													entity = FakePlayerFactory.getMinecraft(_servLevel);
												Direction direction = Direction.DOWN;
												if (entity != null)
													direction = entity.getDirection();
												HashMap<String, String> cmdparams = new HashMap<>();
												int index = -1;
												for (String param : arguments.getInput().split("\\s+")) {
													if (index >= 0)
														cmdparams.put(Integer.toString(index), param);
													index++;
												}

												TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
												return 0;
											})).executes(arguments -> {
												Level world = arguments.getSource().getUnsidedLevel();
												double x = arguments.getSource().getPosition().x();
												double y = arguments.getSource().getPosition().y();
												double z = arguments.getSource().getPosition().z();
												Entity entity = arguments.getSource().getEntity();
												if (entity == null && world instanceof ServerLevel _servLevel)
													entity = FakePlayerFactory.getMinecraft(_servLevel);
												Direction direction = Direction.DOWN;
												if (entity != null)
													direction = entity.getDirection();
												HashMap<String, String> cmdparams = new HashMap<>();
												int index = -1;
												for (String param : arguments.getInput().split("\\s+")) {
													if (index >= 0)
														cmdparams.put(Integer.toString(index), param);
													index++;
												}

												TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
												return 0;
											})))))))))
					.then(Commands.argument("fgj", IdentifierArgument.id()).suggests(SuggestionProviders.cast(SuggestionProviders.SUMMONABLE_ENTITIES))
							.then(Commands.argument("fgjgfd", IdentifierArgument.id()).suggests(BossBarCommands.SUGGEST_BOSS_BAR)
									.then(Commands.argument("fdgj", IdentifierArgument.id()).suggests(SuggestionProviders.cast(SuggestionProviders.SUMMONABLE_ENTITIES)).then(Commands.argument("fdgjame", IdentifierArgument.id())
											.suggests(SuggestionProviders.cast(SuggestionProviders.SUMMONABLE_ENTITIES)).then(Commands.argument("arguments", StringArgumentType.greedyString()).executes(arguments -> {
												Level world = arguments.getSource().getUnsidedLevel();
												double x = arguments.getSource().getPosition().x();
												double y = arguments.getSource().getPosition().y();
												double z = arguments.getSource().getPosition().z();
												Entity entity = arguments.getSource().getEntity();
												if (entity == null && world instanceof ServerLevel _servLevel)
													entity = FakePlayerFactory.getMinecraft(_servLevel);
												Direction direction = Direction.DOWN;
												if (entity != null)
													direction = entity.getDirection();
												HashMap<String, String> cmdparams = new HashMap<>();
												int index = -1;
												for (String param : arguments.getInput().split("\\s+")) {
													if (index >= 0)
														cmdparams.put(Integer.toString(index), param);
													index++;
												}

												TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
												return 0;
											})).executes(arguments -> {
												Level world = arguments.getSource().getUnsidedLevel();
												double x = arguments.getSource().getPosition().x();
												double y = arguments.getSource().getPosition().y();
												double z = arguments.getSource().getPosition().z();
												Entity entity = arguments.getSource().getEntity();
												if (entity == null && world instanceof ServerLevel _servLevel)
													entity = FakePlayerFactory.getMinecraft(_servLevel);
												Direction direction = Direction.DOWN;
												if (entity != null)
													direction = entity.getDirection();
												HashMap<String, String> cmdparams = new HashMap<>();
												int index = -1;
												for (String param : arguments.getInput().split("\\s+")) {
													if (index >= 0)
														cmdparams.put(Integer.toString(index), param);
													index++;
												}

												TestCommandProcedureBlocksProcedure.execute(world, arguments, cmdparams);
												return 0;
											}))))));
	}

}