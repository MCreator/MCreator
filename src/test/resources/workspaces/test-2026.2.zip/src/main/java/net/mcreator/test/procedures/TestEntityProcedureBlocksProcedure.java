package net.mcreator.test.procedures;

import net.neoforged.neoforge.transfer.transaction.Transaction;
import net.neoforged.neoforge.transfer.item.ItemUtil;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ServerExplosion;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.server.permissions.LevelBasedPermissionSet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.commands.functions.CommandFunction;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.test.init.TestModMobEffects;
import net.mcreator.test.init.TestModAttributes;
import net.mcreator.test.entity.TestLivingEntityEntity;
import net.mcreator.test.TestMod;

import java.util.Optional;
import java.util.ArrayList;

public class TestEntityProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity immediatesourceentity, Entity sourceentity) {
		if (entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		{
			Entity _ent = entity;
			if (_ent.level() instanceof ServerLevel _serverLevel) {
				_ent.hurtServer(_serverLevel, new DamageSource(world.holderOrThrow(DamageTypes.LIGHTNING_BOLT)),
						(float) ((immediatesourceentity instanceof Projectile _projEnt ? _projEnt.getDeltaMovement().length() : 0) % (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)));
			}
		}
		if (entity instanceof LivingEntity _entity)
			_entity.removeAllEffects();
		if (!entity.level().isClientSide())
			entity.discard();
		entity.clearFire();
		sourceentity.startRiding(entity);
		entity.makeStuckInBlock(Blocks.AIR.defaultBlockState(), new Vec3(0.25, 0.05, 0.25));
		if (entity instanceof TamableAnimal _toTame && sourceentity instanceof Player _owner)
			_toTame.tame(_owner);
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(TestModMobEffects.TEST_POTION, 60, 1));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.SPEED, 60, 3, (!((entity.level().dimension()) == ResourceKey.create(Registries.DIMENSION, Identifier.parse("test:test_dimension")))), ((entity.level().dimension()) == Level.OVERWORLD)));
		{
			Entity _ent = entity;
			if (_ent.level() instanceof ServerLevel _serverLevel) {
				_ent.hurtServer(_serverLevel, new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 1);
			}
		}
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.level().getServer() != null) {
				_ent.level().getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
						LevelBasedPermissionSet.OWNER, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "clear");
			}
		}
		if ((entity instanceof ItemEntity _itemEnt ? _itemEnt.getItem() : ItemStack.EMPTY).getItem() == ItemStack.EMPTY.getItem()) {
			if (entity instanceof LivingEntity _living) {
				_living.setItemSlot(EquipmentSlot.FEET, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY));
			}
			if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandler) {
				setStackInSlot(_resourceHandler, 0, ItemResource.of((entity instanceof ItemEntity _itemEnt ? _itemEnt.getItem() : ItemStack.EMPTY)), 1);
			}
		}
		if ((getEntitySlot(entity, 0)).is(ItemTags.create(Identifier.parse("minecraft:music_discs")))) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack31 = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).copy();
				_setstack31.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack31);
				ItemStack _setstack33 = (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).copy();
				_setstack33.setCount(1);
				_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack33);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		}
		if (entity.getCapability(Capabilities.Item.ENTITY, null) instanceof ResourceHandler<ItemResource> _resourceHandler) {
			for (int _idx = 0; _idx < _resourceHandler.size(); _idx++) {
				ItemStack itemstackiterator = ItemUtil.getStack(_resourceHandler, _idx);
				entity.getPersistentData().putBoolean("logic",
						(((((entity.isInLava() && entity.isCurrentlyGlowing()) != isInWaterOrBubble(entity)) == ((entity instanceof LivingEntity _livEnt37 && _livEnt37.isSleeping()) ^ entity.canTeleport(entity.level(), entity.level())
								|| entity instanceof LivingEntity _livEnt39 && _livEnt39.isBaby())
								&& ((entity.isSwimming() && entity.level() instanceof ServerLevel _levelExplosionCheck41
										&& entity.ignoreExplosion(new ServerExplosion(_levelExplosionCheck41, null, null, null, new Vec3(0, 0, 0), 1, false, Explosion.BlockInteraction.DESTROY))) != entity
												.isVehicle()) == ((entity instanceof LivingEntity _livEnt43 && _livEnt43.isFallFlying()) ^ (entity instanceof TamableAnimal _tamEnt44 && _tamEnt44.isTame())
														|| entity.isOnFire())) != (((entity instanceof LivingEntity _livEnt46 && _livEnt46.isBlocking() && entity.isInWall()) != entity instanceof TestLivingEntityEntity) == (entity.isAlive()
																^ entity.isInvisible()
																|| entity instanceof LivingEntity _livEnt51 && _livEnt51.hasEffect(TestModMobEffects.TEST_POTION)))) == (((entity.isInvulnerable() && entity.isPassenger()) != entity
																		.is(TagKey.create(Registries.ENTITY_TYPE, Identifier.parse("test:test3")))) == (entity
																				.isInWater() ^ (entity instanceof TamableAnimal _tamIsTamedBy56 && sourceentity instanceof LivingEntity _livEnt56 && _tamIsTamedBy56.isOwnedBy(_livEnt56))
																				|| hasEntityPermissionLevel(entity, 4))
																		^ ((entity.level()
																				.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY,
																						entity))
																				.getType() == HitResult.Type.BLOCK && entity.is(EntityTypeTags.AQUATIC)) != entity.fireImmune()) == (entity.onGround() ^ isInWaterRainOrBubble(entity)
																						|| entity instanceof Mob _mobEnt63 && _mobEnt63.isLeashed())
																		|| entity.getPersistentData().getBooleanOr(("logic" + itemstackiterator), false))));
			}
		}
		entity.getPersistentData().putDouble("number", (entity.getPersistentData().getDoubleOr("number", 0)
				+ Math.pow(((entity.getBbHeight() - getEntitySubmergedHeight(entity)) * entity.getBbWidth()) / entity.getAirSupply(), Mth.nextInt(RandomSource.create(), 0, 2023) % Mth.nextDouble(RandomSource.create(), 0, 4))));
		entity.getPersistentData().putString("string", (entity.getPersistentData().getStringOr("string", "")));
		if ((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.VISUAL, ClipContext.Fluid.SOURCE_ONLY, entity)).getDirection()) == (entity
				.getDirection())) {
			entity.fallDistance = 0;
		}
		for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.SLOWNESS);
			}
		}
		{
			Entity _ent = entity;
			if (_ent.level() instanceof ServerLevel _serverLevel && _serverLevel.getServer() != null) {
				Optional<CommandFunction<CommandSourceStack>> _fopt = _serverLevel.getServer().getFunctions().get(Identifier.parse("minecraft:tick"));
				if (_fopt.isPresent())
					_serverLevel.getServer().getFunctions().execute(_fopt.get(), _ent.createCommandSourceStackForNameResolution(_serverLevel));
			}
		}
		entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), (entity.getDeltaMovement().y()), (entity.getDeltaMovement().z())));
		entity.setDeltaMovement(new Vec3((entity.getLookAngle().x), (entity.getLookAngle().y), (entity.getLookAngle().z)));
		for (Entity entityiterator : entity.getIndirectPassengers()) {
			entity.igniteForSeconds(15);
		}
		entity.setCustomName(Component.literal((entity.getDisplayName().getString())));
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth(entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
		entity.setNoGravity((entity.isNoGravity()));
		entity.setAirSupply(0);
		{
			Entity _ent = entity;
			_ent.setYRot(entity.getYRot());
			_ent.setXRot(entity.getXRot());
			_ent.setYBodyRot(_ent.getYRot());
			_ent.setYHeadRot(_ent.getYRot());
			_ent.yRotO = _ent.getYRot();
			_ent.xRotO = _ent.getXRot();
			if (_ent instanceof LivingEntity _entity) {
				_entity.yBodyRotO = _entity.getYRot();
				_entity.yHeadRotO = _entity.getYRot();
			}
		}
		entity.setShiftKeyDown((entity.isShiftKeyDown()));
		entity.setSprinting((entity.isSprinting()));
		if ((entity.getVehicle()) == (entity.getRootVehicle())) {
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.OFF_HAND, true);
		}
		{
			Entity _ent = entity;
			double _tx = (entity.getX());
			double _ty = (entity.getY());
			double _tz = (entity.getZ());
			_ent.teleportTo(_tx, _ty, _tz);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(_tx, _ty, _tz, _ent.getYRot(), _ent.getXRot());
		}
		{
			Entity _ent = entity;
			double _tx = (entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getX());
			double _ty = (entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getY());
			double _tz = (entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ());
			_ent.teleportTo(_tx, _ty, _tz);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(_tx, _ty, _tz, _ent.getYRot(), _ent.getXRot());
		}
		if (!((entity.getControllingPassenger()) == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null))) {
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.level().getScoreboard();
				Objective _so = _sc.getObjective("custom_score");
				if (_so == null)
					_so = _sc.addObjective("custom_score", ObjectiveCriteria.DUMMY, Component.literal("custom_score"), ObjectiveCriteria.RenderType.INTEGER, true, null);
				_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so)
						.set((int) Math.pow(((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.LUCK) ? _livEnt.getEffect(MobEffects.LUCK).getDuration() : 0) + entity.getRemainingFireTicks())
								- ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) / (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1))
										* (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.STRENGTH) ? _livEnt.getEffect(MobEffects.STRENGTH).getAmplifier() : 0),
								getEntityScore("custom_score", entity)));
			}
		}
		if (entity instanceof LivingEntity _livingEntity134 && _livingEntity134.getAttributes().hasAttribute(Attributes.ATTACK_SPEED)) {
			if (entity instanceof LivingEntity _livingEntity136 && _livingEntity136.getAttributes().hasAttribute(TestModAttributes.DEMO_ATTRIBUTE))
				_livingEntity136.getAttribute(TestModAttributes.DEMO_ATTRIBUTE).setBaseValue(
						(entity instanceof LivingEntity _livingEntity135 && _livingEntity135.getAttributes().hasAttribute(TestModAttributes.DEMO_ATTRIBUTE_2) ? _livingEntity135.getAttribute(TestModAttributes.DEMO_ATTRIBUTE_2).getBaseValue() : 0));
			TestMod.LOGGER.info(entity instanceof LivingEntity _livingEntity137 && _livingEntity137.getAttributes().hasAttribute(Attributes.SUBMERGED_MINING_SPEED) ? _livingEntity137.getAttribute(Attributes.SUBMERGED_MINING_SPEED).getValue() : 0);
		}
		if (entity instanceof LivingEntity _livingEntity138 && _livingEntity138.getAttribute(TestModAttributes.DEMO_ATTRIBUTE_2).hasModifier(Identifier.parse("test:custom2"))) {
			if (entity instanceof LivingEntity _entity) {
				_entity.getAttribute(TestModAttributes.DEMO_ATTRIBUTE).removeModifier(Identifier.parse("test:custom1"));
			}
			if (entity instanceof LivingEntity _entity) {
				AttributeModifier modifier = new AttributeModifier(Identifier.parse("test:custom1"), 0, AttributeModifier.Operation.ADD_VALUE);
				if (!_entity.getAttribute(Attributes.SWEEPING_DAMAGE_RATIO).hasModifier(modifier.id())) {
					_entity.getAttribute(Attributes.SWEEPING_DAMAGE_RATIO).addPermanentModifier(modifier);
				}
			}
		}
	}

	private static void setStackInSlot(ResourceHandler<ItemResource> handler, int index, ItemResource resource, int amount) {
		try (var tx = Transaction.openRoot()) {
			if (!handler.getResource(index).isEmpty())
				handler.extract(index, handler.getResource(index), handler.getAmountAsInt(index), tx);
			if (!resource.isEmpty() && amount > 0)
				handler.insert(index, resource, amount, tx);
			tx.commit();
		}
	}

	private static ItemStack getEntitySlot(Entity entity, int slot) {
		if (entity != null) {
			ResourceHandler<ItemResource> resourceHandler = entity.getCapability(Capabilities.Item.ENTITY, null);
			if (resourceHandler != null) {
				return ItemUtil.getStack(resourceHandler, slot);
			}
		}
		return ItemStack.EMPTY;
	}

	private static boolean isInWaterOrBubble(Entity entity) {
		return entity.isInWater() || entity.getInBlockState().is(Blocks.BUBBLE_COLUMN);
	}

	private static boolean hasEntityPermissionLevel(Entity entity, int permissionLevel) {
		if (entity instanceof Player _player) {
			return switch (permissionLevel) {
				case 0 -> true;
				case 1 -> _player.permissions().hasPermission(Permissions.COMMANDS_MODERATOR);
				case 2 -> _player.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER);
				case 3 -> _player.permissions().hasPermission(Permissions.COMMANDS_ADMIN);
				default -> _player.permissions().hasPermission(Permissions.COMMANDS_OWNER);
			};
		}
		return false;
	}

	private static boolean isInWaterRainOrBubble(Entity entity) {
		return entity.isInWaterOrRain() || entity.getInBlockState().is(Blocks.BUBBLE_COLUMN);
	}

	private static double getEntitySubmergedHeight(Entity entity) {
		return Math.max(entity.getFluidHeight(FluidTags.WATER), entity.getFluidHeight(FluidTags.LAVA));
	}

	private static int getEntityScore(String score, Entity entity) {
		Scoreboard scoreboard = entity.level().getScoreboard();
		Objective scoreboardObjective = scoreboard.getObjective(score);
		if (scoreboardObjective != null)
			return scoreboard.getOrCreatePlayerScore(ScoreHolder.forNameOnly(entity.getScoreboardName()), scoreboardObjective).get();
		return 0;
	}
}