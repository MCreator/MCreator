package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.test.init.TestModWoodTypes;
import net.mcreator.test.init.TestModBlocks;

public class CustomWallHangingSignBlock extends WallHangingSignBlock {
	public CustomWallHangingSignBlock(BlockBehaviour.Properties properties) {
		super(TestModWoodTypes.CUSTOM_HANGING_SIGN_WOOD_TYPE, properties.sound(SoundType.GRAVEL).strength(1f, 10f).noCollision().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn()
				.overrideLootTable(TestModBlocks.CUSTOM_HANGING_SIGN.get().getLootTable()).overrideDescription(TestModBlocks.CUSTOM_HANGING_SIGN.get().getDescriptionId()));
	}
}