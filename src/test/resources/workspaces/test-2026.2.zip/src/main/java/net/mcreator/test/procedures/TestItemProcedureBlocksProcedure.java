package net.mcreator.test.procedures;

import net.neoforged.neoforge.transfer.transaction.Transaction;
import net.neoforged.neoforge.transfer.item.ItemUtil;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.access.ItemAccess;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.Holder;
import net.minecraft.client.Minecraft;

public class TestItemProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		Entity fakePlayer = null;
		itemstack.grow(0);
		itemstack.setCount(itemstack.getCount());
		itemstack.shrink(0);
		if (world instanceof ServerLevel _level) {
			itemstack.hurtAndBreak(0, _level, null, _stkprov -> {
			});
		}
		itemstack.setDamageValue(itemstack.getDamageValue());
		itemstack.enchant(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, Identifier.parse("test:test_enchantment"))), (int) Mth.nextDouble(RandomSource.create(), 1, 20));
		EnchantmentHelper.updateEnchantments(itemstack, mutableEnchantments -> mutableEnchantments.removeIf(enchantment -> enchantment.is(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.VANISHING_CURSE))));
		if (world.getServer() != null) {
			fakePlayer = null;
			if (fakePlayer instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack, Mth.nextInt(RandomSource.create(), 10, 200));
		}
		itemstack.applyComponents((itemstack.copy()).getComponents());
		{
			final String _tagName = "logic";
			final boolean _tagValue = (((itemstack.has(DataComponents.FOOD) && world instanceof ServerLevel _level29
					&& _level29.recipeAccess().getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(itemstack), _level29).isPresent()) != (itemstack.getRarity() == Rarity.EPIC)) == (itemstack.isEnchanted() ^ itemstack.isEnchantable()
							|| itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.FORTUNE)) != 0)
					|| (itemstack.getItem() == (getItemStackSmeltingResult(world,
							(new ItemStack((BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(Identifier.parse("minecraft:copper_ores")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value())))))
							.getItem()
							&& itemstack.is(ItemTags.PICKAXES)) != (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBooleanOr("logic", false) ^ new ItemStack(
									(BuiltInRegistries.ITEM.getRandomElementOf(ItemTags.create(Identifier.parse("minecraft:mineable/pickaxe")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value()))
									.isCorrectToolForDrops(
											(BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(Identifier.parse("minecraft:diamond_ores")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value())
													.defaultBlockState())));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
		}
		{
			final String _tagName = "number";
			final double _tagValue = (((world instanceof Level _levelFV53 ? itemstack.getBurnTime(null, _levelFV53.fuelValues()) : 0)
					/ itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY))
					+ (world instanceof Level _levelFV57 ? itemstack.getBurnTime(null, _levelFV57.fuelValues()) : 0) % itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY)))
					* (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDoubleOr("number", 0)
							- Math.pow(itemstack.getMaxDamage(), itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.MENDING)))));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
		}
		{
			final String _tagName = "string";
			final String _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getStringOr("string", ""));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putString(_tagName, _tagValue));
		}
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation((EnchantmentHelper.enchantItem(world.getRandom(),
					((BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(Identifier.parse("minecraft:walls")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value()) instanceof LiquidBlock _liquid
							? new ItemStack(_liquid.fluid.getBucket())
							: ItemStack.EMPTY),
					(int) (Math.round(Math.random()) == 1 ? (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).nutrition() : 0) : (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).saturation() : 0)),
					((itemstack.is(ItemTags.create(Identifier.parse("test:test")))))
							? world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).listElements().map(reference -> (Holder<Enchantment>) reference)
							: world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(EnchantmentTags.IN_ENCHANTING_TABLE).get().stream())));
		ItemStack _itemStack89 = itemstack;
		if (_itemStack89.getCapability(Capabilities.Item.ITEM, ItemAccess.forStack(_itemStack89)) instanceof ResourceHandler<ItemResource> _resourceHandler) {
			setStackInSlot(_resourceHandler, 0, ItemResource.of(((getItemStackFromItemStackSlot(0, itemstack)).copy())), (getItemStackFromItemStackSlot(0, itemstack)).getCount());
		}
		itemstack.set(DataComponents.CUSTOM_NAME, Component.literal((itemstack.getDisplayName().getString())));
	}

	private static ItemStack getItemStackSmeltingResult(LevelAccessor level, ItemStack input) {
		SingleRecipeInput recipeInput = new SingleRecipeInput(input);
		if (level instanceof ServerLevel serverLevel) {
			return serverLevel.recipeAccess().getRecipeFor(RecipeType.SMELTING, recipeInput, serverLevel).map(recipe -> recipe.value().assemble(recipeInput).copy()).orElse(ItemStack.EMPTY);
		}
		return ItemStack.EMPTY;
	}

	private static ItemStack getItemStackFromItemStackSlot(int slotID, ItemStack itemStack) {
		ResourceHandler<ItemResource> itemHandler = itemStack.getCapability(Capabilities.Item.ITEM, ItemAccess.forStack(itemStack));
		if (itemHandler != null)
			return ItemUtil.getStack(itemHandler, slotID);
		return ItemStack.EMPTY;
	}

	private static void setStackInSlot(ResourceHandler<ItemResource> handler, int index, ItemResource resource, int amount) {
		try (var tx = Transaction.openRoot()) {
			if (!handler.getResource(index).isEmpty())
				handler.extract(index, handler.getResource(index), handler.getAmountAsInt(index), tx);
			if (!resource.isEmpty() && amount > 0)
				handler.insert(index, resource, amount, tx);
			tx.commit();
		}
	}
}