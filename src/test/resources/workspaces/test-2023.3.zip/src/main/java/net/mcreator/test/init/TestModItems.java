
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.test.item.TestToolItem;
import net.mcreator.test.item.TestTool4Item;
import net.mcreator.test.item.TestTool3Item;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestRangedItemItem;
import net.mcreator.test.item.TestMusicDiscItem;
import net.mcreator.test.item.TestItemItem;
import net.mcreator.test.item.TestFoodItem;
import net.mcreator.test.item.TestFluidItem;
import net.mcreator.test.item.TestDimensionItem;
import net.mcreator.test.item.TestArmorItem;
import net.mcreator.test.TestMod;

public class TestModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TestMod.MODID);
	public static final RegistryObject<Item> TEST_ARMOR_HELMET = REGISTRY.register("test_armor_helmet", () -> new TestArmorItem.Helmet());
	public static final RegistryObject<Item> TEST_ARMOR_CHESTPLATE = REGISTRY.register("test_armor_chestplate", () -> new TestArmorItem.Chestplate());
	public static final RegistryObject<Item> TEST_ARMOR_LEGGINGS = REGISTRY.register("test_armor_leggings", () -> new TestArmorItem.Leggings());
	public static final RegistryObject<Item> TEST_ARMOR_BOOTS = REGISTRY.register("test_armor_boots", () -> new TestArmorItem.Boots());
	public static final RegistryObject<Item> TEST_BLOCK = block(TestModBlocks.TEST_BLOCK);
	public static final RegistryObject<Item> TEST_DIMENSION = REGISTRY.register("test_dimension", () -> new TestDimensionItem());
	public static final RegistryObject<Item> TEST_FOOD = REGISTRY.register("test_food", () -> new TestFoodItem());
	public static final RegistryObject<Item> TEST_FLUID_BUCKET = REGISTRY.register("test_fluid_bucket", () -> new TestFluidItem());
	public static final RegistryObject<Item> TEST_ITEM = REGISTRY.register("test_item", () -> new TestItemItem());
	public static final RegistryObject<Item> TEST_LIVING_ENTITY_SPAWN_EGG = REGISTRY.register("test_living_entity_spawn_egg", () -> new ForgeSpawnEggItem(TestModEntities.TEST_LIVING_ENTITY, -13369396, -52378, new Item.Properties()));
	public static final RegistryObject<Item> TEST_MUSIC_DISC = REGISTRY.register("test_music_disc", () -> new TestMusicDiscItem());
	public static final RegistryObject<Item> TEST_PLANT = block(TestModBlocks.TEST_PLANT);
	public static final RegistryObject<Item> TEST_RANGED_ITEM = REGISTRY.register("test_ranged_item", () -> new TestRangedItemItem());
	public static final RegistryObject<Item> TEST_TOOL = REGISTRY.register("test_tool", () -> new TestToolItem());
	public static final RegistryObject<Item> TEST_TOOL_2 = REGISTRY.register("test_tool_2", () -> new TestTool2Item());
	public static final RegistryObject<Item> TEST_TOOL_3 = REGISTRY.register("test_tool_3", () -> new TestTool3Item());
	public static final RegistryObject<Item> TEST_TOOL_4 = REGISTRY.register("test_tool_4", () -> new TestTool4Item());
	public static final RegistryObject<Item> TEST_PLANT_2 = block(TestModBlocks.TEST_PLANT_2);
	public static final RegistryObject<Item> TEST_PLANT_3 = doubleBlock(TestModBlocks.TEST_PLANT_3);
	public static final RegistryObject<Item> NO_GEN_BLOCK = block(TestModBlocks.NO_GEN_BLOCK);
	public static final RegistryObject<Item> ORE_BLOCK_2 = block(TestModBlocks.ORE_BLOCK_2);
	public static final RegistryObject<Item> ORE_BLOCK_3 = block(TestModBlocks.ORE_BLOCK_3);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
