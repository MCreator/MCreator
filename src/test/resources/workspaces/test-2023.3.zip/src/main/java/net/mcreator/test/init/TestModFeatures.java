
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.test.world.features.plants.TestPlantFeature;
import net.mcreator.test.world.features.plants.TestPlant3Feature;
import net.mcreator.test.world.features.plants.TestPlant2Feature;
import net.mcreator.test.world.features.ores.TestBlockFeature;
import net.mcreator.test.world.features.ores.OreBlock3Feature;
import net.mcreator.test.world.features.ores.OreBlock2Feature;
import net.mcreator.test.world.features.TestStructureFeature;
import net.mcreator.test.world.features.TestFluidFeatureFeature;
import net.mcreator.test.world.features.TestFeatureFeature;
import net.mcreator.test.world.features.TestFeature2Feature;
import net.mcreator.test.world.features.SimpleCommonStructureFeature;
import net.mcreator.test.world.features.AnotherStructureFeature;
import net.mcreator.test.world.features.AllPlacementsFeature;
import net.mcreator.test.TestMod;

@Mod.EventBusSubscriber
public class TestModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, TestMod.MODID);
	public static final RegistryObject<Feature<?>> TEST_BLOCK = REGISTRY.register("test_block", TestBlockFeature::new);
	public static final RegistryObject<Feature<?>> TEST_PLANT = REGISTRY.register("test_plant", TestPlantFeature::new);
	public static final RegistryObject<Feature<?>> TEST_STRUCTURE = REGISTRY.register("test_structure", TestStructureFeature::new);
	public static final RegistryObject<Feature<?>> TEST_FLUID_FEATURE = REGISTRY.register("test_fluid_feature", TestFluidFeatureFeature::new);
	public static final RegistryObject<Feature<?>> TEST_PLANT_2 = REGISTRY.register("test_plant_2", TestPlant2Feature::new);
	public static final RegistryObject<Feature<?>> TEST_PLANT_3 = REGISTRY.register("test_plant_3", TestPlant3Feature::new);
	public static final RegistryObject<Feature<?>> ORE_BLOCK_2 = REGISTRY.register("ore_block_2", OreBlock2Feature::new);
	public static final RegistryObject<Feature<?>> ORE_BLOCK_3 = REGISTRY.register("ore_block_3", OreBlock3Feature::new);
	public static final RegistryObject<Feature<?>> ALL_PLACEMENTS = REGISTRY.register("all_placements", AllPlacementsFeature::new);
	public static final RegistryObject<Feature<?>> SIMPLE_COMMON_STRUCTURE = REGISTRY.register("simple_common_structure", SimpleCommonStructureFeature::new);
	public static final RegistryObject<Feature<?>> TEST_FEATURE = REGISTRY.register("test_feature", TestFeatureFeature::new);
	public static final RegistryObject<Feature<?>> TEST_FEATURE_2 = REGISTRY.register("test_feature_2", TestFeature2Feature::new);
	public static final RegistryObject<Feature<?>> ANOTHER_STRUCTURE = REGISTRY.register("another_structure", AnotherStructureFeature::new);
}
