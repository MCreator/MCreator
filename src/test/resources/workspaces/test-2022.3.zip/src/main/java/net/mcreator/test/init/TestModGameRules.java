
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModGameRules {
	public static final GameRules.Key<GameRules.IntegerValue> TEST_RULE = GameRules.register("test_rule", GameRules.Category.MISC,
			GameRules.IntegerValue.create(0));
}
