
package net.mcreator.test.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.damagesource.DamageSource;

public class TestEnchantmentEnchantment extends Enchantment {
	public TestEnchantmentEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.WEARABLE, slots);
	}

	@Override
	public int getMaxLevel() {
		return 16;
	}

	@Override
	public int getDamageProtection(int level, DamageSource source) {
		return level * 8;
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}
}
