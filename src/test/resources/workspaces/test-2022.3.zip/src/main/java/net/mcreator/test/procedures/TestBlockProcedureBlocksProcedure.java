package net.mcreator.test.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.TierSortingRegistry;
import net.minecraftforge.common.PlantType;
import net.minecraftforge.common.IPlantable;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Map;

public class TestBlockProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		Entity fakePlayer = null;
		world.setBlock(new BlockPos(x, y, z), (world.getFluidState(new BlockPos(x, y, z)).createLegacyBlock()), 3);
		world.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
		if ((world.getBlockState(new BlockPos(x, y, z))) == ((new Object() {
			public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
							.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
				return _retval.get();
			}
		}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BlockItem _bi
				? _bi.getBlock().defaultBlockState()
				: Blocks.AIR.defaultBlockState())) {
			{
				BlockPos _bp = new BlockPos(x, y, z);
				BlockState _bs = (world.getBlockState(new BlockPos(x, y, z)));
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				BlockEntity _be = world.getBlockEntity(_bp);
				CompoundTag _bnbt = null;
				if (_be != null) {
					_bnbt = _be.saveWithFullMetadata();
					_be.setRemoved();
				}
				world.setBlock(_bp, _bs, 3);
				if (_bnbt != null) {
					_be = world.getBlockEntity(_bp);
					if (_be != null) {
						try {
							_be.load(_bnbt);
						} catch (Exception ignored) {
						}
					}
				}
			}
		} else if ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == ((new Object() {
			public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
							.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
				return _retval.get();
			}
		}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BlockItem _bi
				? _bi.getBlock().defaultBlockState()
				: Blocks.AIR.defaultBlockState()).getBlock()) {
			if (world instanceof Level _level)
				_level.updateNeighborsAt(new BlockPos(x, y, z), _level.getBlockState(new BlockPos(x, y, z)).getBlock());
		}
		{
			BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
			if (_ent != null) {
				final int _slotid = 0;
				_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					if (capability instanceof IItemHandlerModifiable)
						((IItemHandlerModifiable) capability).setStackInSlot(_slotid, ItemStack.EMPTY);
				});
			}
		}
		{
			BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
			if (_ent != null) {
				final int _slotid = 0;
				final int _amount = 1;
				_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					if (capability instanceof IItemHandlerModifiable) {
						ItemStack _stk = capability.getStackInSlot(_slotid).copy();
						if (_stk.hurt(_amount, RandomSource.create(), null)) {
							_stk.shrink(1);
							_stk.setDamageValue(0);
						}
						((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _stk);
					}
				});
			}
		}
		{
			BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
			if (_ent != null) {
				final int _slotid = 0;
				final int _amount = 1;
				_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					if (capability instanceof IItemHandlerModifiable) {
						ItemStack _stk = capability.getStackInSlot(_slotid).copy();
						_stk.shrink(_amount);
						((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _stk);
					}
				});
			}
		}
		{
			BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
			if (_ent != null) {
				final int _slotid = 0;
				final ItemStack _setstack = (new Object() {
					public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
						AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
						BlockEntity _ent = world.getBlockEntity(pos);
						if (_ent != null)
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
									.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
						return _retval.get();
					}
				}.getItemStack(world, new BlockPos(x, y, z), 0));
				_setstack.setCount(1);
				_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					if (capability instanceof IItemHandlerModifiable)
						((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
				});
			}
		}
		if (!world.isClientSide()) {
			BlockPos _bp = new BlockPos(x, y, z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null)
				_blockEntity.getPersistentData().putBoolean("logic", ((((new Object() {
					public BlockState with(BlockState _bs, String _property, int _newValue) {
						Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty(_property);
						return _prop instanceof IntegerProperty _ip && _prop.getPossibleValues().contains(_newValue)
								? _bs.setValue(_ip, _newValue)
								: _bs;
					}
				}.with((ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("minecraft:crops")))
						.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).defaultBlockState(), "age",
						Mth.nextInt(RandomSource.create(), 1, 8))).getBlock() instanceof BonemealableBlock && ((new Object() {
							public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
								AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
								BlockEntity _ent = world.getBlockEntity(pos);
								if (_ent != null)
									_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
											.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
								return _retval.get();
							}
						}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BlockItem _bi
								? _bi.getBlock().defaultBlockState()
								: Blocks.AIR.defaultBlockState()).getBlock() instanceof LiquidBlock) != ((new Object() {
									public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
										AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
										BlockEntity _ent = world.getBlockEntity(pos);
										if (_ent != null)
											_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
													.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
										return _retval.get();
									}
								}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BucketItem _bucket
										? _bucket.getFluid().defaultFluidState().createLegacyBlock()
										: Blocks.AIR.defaultBlockState())
										.getFluidState()
										.isSource()) == ((ForgeRegistries.BLOCKS.tags()
												.getTag(BlockTags.create(new ResourceLocation("minecraft:logs")))
												.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).defaultBlockState()
												.is(BlockTags.create(new ResourceLocation("minecraft:logs"))) ^ new Object() {
													public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
														BlockEntity blockEntity = world.getBlockEntity(pos);
														if (blockEntity != null)
															return blockEntity.getPersistentData().getBoolean(tag);
														return false;
													}
												}.getValue(world, new BlockPos(x, y, z), "logic") || (ForgeRegistries.BLOCKS.tags()
														.getTag(BlockTags.create(new ResourceLocation("minecraft:impermeable")))
														.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).defaultBlockState()
														.getMaterial() == net.minecraft.world.level.material.Material.STONE)));
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
		if (!world.isClientSide()) {
			BlockPos _bp = new BlockPos(x, y, z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null)
				_blockEntity.getPersistentData().putDouble("number", ((new Object() {
					public double getValue(LevelAccessor world, BlockPos pos, String tag) {
						BlockEntity blockEntity = world.getBlockEntity(pos);
						if (blockEntity != null)
							return blockEntity.getPersistentData().getDouble(tag);
						return -1;
					}
				}.getValue(world, new BlockPos(x, y, z), "number"))
						* world.getBlockState(new BlockPos(x, y, z)).getDestroySpeed(world, new BlockPos(x, y, z))
						- world.getBlockState(new BlockPos(x, y, z)).getEnchantPowerBonus(world, new BlockPos(x, y, z))
								/ world.getBlockState(new BlockPos(x, y, z)).getLightEmission(world, new BlockPos(x, y, z))
						+ Math.pow(world.getBlockState(new BlockPos(x, y, z)).getLightBlock(world, new BlockPos(x, y, z)) % new Object() {
							public int getHarvestLevel(BlockState _bs) {
								return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag() != null && _bs.is(t.getTag()))
										.map(Tier::getLevel).findFirst().orElse(0);
							}
						}.getHarvestLevel(world.getBlockState(new BlockPos(x, y, z))), new Object() {
							public int getAmount(LevelAccessor world, BlockPos pos, int slotid) {
								AtomicInteger _retval = new AtomicInteger(0);
								BlockEntity _ent = world.getBlockEntity(pos);
								if (_ent != null)
									_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
											.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).getCount()));
								return _retval.get();
							}
						}.getAmount(world, new BlockPos(x, y, z), 0))));
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
		if (!world.isClientSide()) {
			BlockPos _bp = new BlockPos(x, y, z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null)
				_blockEntity.getPersistentData().putString("string", (new Object() {
					public String getValue(LevelAccessor world, BlockPos pos, String tag) {
						BlockEntity blockEntity = world.getBlockEntity(pos);
						if (blockEntity != null)
							return blockEntity.getPersistentData().getString(tag);
						return "";
					}
				}.getValue(world, new BlockPos(x, y, z), "string")));
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
		world.levelEvent(2001, new BlockPos(x, y, z), Block.getId((new Object() {
			public BlockState with(BlockState _bs, Direction newValue) {
				Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty("facing");
				if (_prop instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(newValue))
					return _bs.setValue(_dp, newValue);
				_prop = _bs.getBlock().getStateDefinition().getProperty("axis");
				return _prop instanceof EnumProperty _ep && _ep.getPossibleValues().contains(newValue.getAxis())
						? _bs.setValue(_ep, newValue.getAxis())
						: _bs;
			}
		}.with((ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("test:test2"))).getRandomElement(RandomSource.create())
				.orElseGet(() -> Blocks.AIR)).defaultBlockState(), (new Object() {
					public Direction getDirection(BlockPos pos) {
						BlockState _bs = world.getBlockState(pos);
						Property<?> property = _bs.getBlock().getStateDefinition().getProperty("facing");
						if (property != null && _bs.getValue(property) instanceof Direction _dir)
							return _dir;
						property = _bs.getBlock().getStateDefinition().getProperty("axis");
						if (property != null && _bs.getValue(property) instanceof Direction.Axis _axis)
							return Direction.fromAxisAndDirection(_axis, Direction.AxisDirection.POSITIVE);
						return Direction.NORTH;
					}
				}.getDirection(new BlockPos(x, y, z)))))));
		world.destroyBlock(new BlockPos(x, y, z), false);
		{
			BlockPos _pos = new BlockPos(x, y, z);
			Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
			world.destroyBlock(_pos, false);
		}
		world.scheduleTick(new BlockPos(x, y, z), world.getBlockState(new BlockPos(x, y, z)).getBlock(), 0);
		{
			BlockPos _pos = new BlockPos(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			if (_bs.getBlock().getStateDefinition().getProperty("waterlogged") instanceof BooleanProperty _booleanProp)
				world.setBlock(_pos,
						_bs.setValue(_booleanProp,
								((((world.getBlockState(new BlockPos(x, y, z)).getBlock() instanceof IPlantable _plant
										? _plant.getPlantType(world, new BlockPos(x, y, z)) == PlantType.PLAINS
										: false) && world.getBlockState(new BlockPos(x, y, z)).canOcclude()) != world
												.getBlockState(new BlockPos(x, y, z)).isFaceSturdy(world, new BlockPos(x, y, z), (new Object() {
													public Direction getDirection(BlockPos pos) {
														BlockState _bs = world.getBlockState(pos);
														Property<?> property = _bs.getBlock().getStateDefinition().getProperty("facing");
														if (property != null && _bs.getValue(property) instanceof Direction _dir)
															return _dir;
														property = _bs.getBlock().getStateDefinition().getProperty("axis");
														if (property != null && _bs.getValue(property) instanceof Direction.Axis _axis)
															return Direction.fromAxisAndDirection(_axis, Direction.AxisDirection.POSITIVE);
														return Direction.NORTH;
													}
												}.getDirection(new BlockPos(x, y, z))))) == ((world.getFluidState(new BlockPos(x, y, z))
														.createLegacyBlock()).canSurvive(world, new BlockPos(x, y, z))
														^ ((ForgeRegistries.BLOCKS.tags()
																.getTag(BlockTags.create(new ResourceLocation("minecraft:fences")))
																.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR))
																.getStateDefinition().getProperty("waterlogged") instanceof BooleanProperty _withbp59
																		? (ForgeRegistries.BLOCKS.tags()
																				.getTag(BlockTags.create(new ResourceLocation("minecraft:fences")))
																				.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR))
																				.defaultBlockState().setValue(_withbp59, (Math.random() < 0.5))
																		: (ForgeRegistries.BLOCKS.tags()
																				.getTag(BlockTags.create(new ResourceLocation("minecraft:fences")))
																				.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR))
																				.defaultBlockState())
																.getBlock() instanceof SimpleWaterloggedBlock
														|| !((world.getBlockState(new BlockPos(x, y, z))).getBlock().getStateDefinition()
																.getProperty("waterlogged") instanceof BooleanProperty _getbp62
																&& (world.getBlockState(new BlockPos(x, y, z))).getValue(_getbp62))))),
						3);
		}
		{
			Direction _dir = (new Object() {
				public Direction getDirection(BlockState _bs) {
					Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty("facing");
					if (_prop instanceof DirectionProperty _dp)
						return _bs.getValue(_dp);
					_prop = _bs.getBlock().getStateDefinition().getProperty("axis");
					return _prop instanceof EnumProperty _ep && _ep.getPossibleValues().toArray()[0] instanceof Direction.Axis
							? Direction.fromAxisAndDirection((Direction.Axis) _bs.getValue(_ep), Direction.AxisDirection.POSITIVE)
							: Direction.NORTH;
				}
			}.getDirection((new Object() {
				public BlockState with(BlockState _bs, String _property, String _newValue) {
					Property<?> _prop = _bs.getBlock().getStateDefinition().getProperty(_property);
					return _prop instanceof EnumProperty _ep && _ep.getValue(_newValue).isPresent()
							? _bs.setValue(_ep, (Enum) _ep.getValue(_newValue).get())
							: _bs;
				}
			}.with((ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("minecraft:beds")))
					.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).defaultBlockState(), "part", "head"))));
			BlockPos _pos = new BlockPos(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
			if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
				world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
			} else {
				_property = _bs.getBlock().getStateDefinition().getProperty("axis");
				if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
					world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
			}
		}
		{
			String _value = ((ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("minecraft:beds")))
					.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).getStateDefinition()
					.getProperty("part") instanceof EnumProperty _getep69
							? (ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("minecraft:beds")))
									.getRandomElement(RandomSource.create()).orElseGet(() -> Blocks.AIR)).defaultBlockState().getValue(_getep69)
									.toString()
							: "");
			BlockPos _pos = new BlockPos(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			if (_bs.getBlock().getStateDefinition().getProperty("part") instanceof EnumProperty _enumProp && _enumProp.getValue(_value).isPresent())
				world.setBlock(_pos, _bs.setValue(_enumProp, (Enum) _enumProp.getValue(_value).get()), 3);
		}
		{
			int _value = (int) (Math.random() >= 0.5 ? (((new Object() {
				public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					BlockEntity _ent = world.getBlockEntity(pos);
					if (_ent != null)
						_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
								.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
					return _retval.get();
				}
			}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BlockItem _bi
					? _bi.getBlock().defaultBlockState()
					: Blocks.AIR.defaultBlockState()).getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _getip73
							? ((new Object() {
								public ItemStack getItemStack(LevelAccessor world, BlockPos pos, int slotid) {
									AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
									BlockEntity _ent = world.getBlockEntity(pos);
									if (_ent != null)
										_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null)
												.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).copy()));
									return _retval.get();
								}
							}.getItemStack(world, new BlockPos(x, y, z), 0)).getItem() instanceof BlockItem _bi
									? _bi.getBlock().defaultBlockState()
									: Blocks.AIR.defaultBlockState()).getValue(_getip73)
							: -1)
					: Mth.nextDouble(RandomSource.create(), 0, 8));
			BlockPos _pos = new BlockPos(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			if (_bs.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _integerProp
					&& _integerProp.getPossibleValues().contains(_value))
				world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
		}
		if (world.getServer() != null) {
			fakePlayer = FakePlayerFactory.get(world.getServer().overworld(), Minecraft.getInstance().getUser().getGameProfile());
			if (fakePlayer instanceof Player _player) {
				BlockPos _bp = new BlockPos(x, y, z);
				_player.level.getBlockState(_bp).use(_player.level, _player, InteractionHand.MAIN_HAND,
						BlockHitResult.miss(new Vec3(_bp.getX(), _bp.getY(), _bp.getZ()), Direction.UP, _bp));
			}
		}
	}
}
