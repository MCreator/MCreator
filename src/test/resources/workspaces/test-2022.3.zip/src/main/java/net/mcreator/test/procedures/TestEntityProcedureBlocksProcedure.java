package net.mcreator.test.procedures;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Registry;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandFunction;

import net.mcreator.test.init.TestModMobEffects;
import net.mcreator.test.entity.TestLivingEntityEntity;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Optional;
import java.util.ArrayList;

public class TestEntityProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity immediatesourceentity, Entity sourceentity) {
		if (entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		entity.hurt(DamageSource.LIGHTNING_BOLT,
				(float) ((immediatesourceentity instanceof Projectile _projEnt ? _projEnt.getDeltaMovement().length() : 0)
						% (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)));
		if (entity instanceof LivingEntity _entity)
			_entity.removeAllEffects();
		if (!entity.level.isClientSide())
			entity.discard();
		entity.clearFire();
		sourceentity.startRiding(entity);
		entity.makeStuckInBlock(Blocks.AIR.defaultBlockState(), new Vec3(0.25, 0.05, 0.25));
		if (entity instanceof TamableAnimal _toTame && sourceentity instanceof Player _owner)
			_toTame.tame(_owner);
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(TestModMobEffects.TEST_POTION.get(), 60, 1));
		if (entity instanceof LivingEntity _entity)
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 3,
					(!((entity.level.dimension()) == (ResourceKey.create(Registry.DIMENSION_REGISTRY, new ResourceLocation("test:test_dimension"))))),
					((entity.level.dimension()) == (Level.OVERWORLD))));
		if (entity instanceof LivingEntity _entity)
			_entity.hurt(new DamageSource("custom").bypassArmor(), 1);
		{
			Entity _ent = entity;
			if (!_ent.level.isClientSide() && _ent.getServer() != null) {
				_ent.getServer().getCommands()
						.performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
								_ent.level instanceof ServerLevel ? (ServerLevel) _ent.level : null, 4, _ent.getName().getString(),
								_ent.getDisplayName(), _ent.level.getServer(), _ent), "clear");
			}
		}
		{
			AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
			entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> _iitemhandlerref.set(capability));
			if (_iitemhandlerref.get() != null) {
				for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
					ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
					if ((entity instanceof ItemEntity _itemEnt ? _itemEnt.getItem() : ItemStack.EMPTY).getItem() == (ItemStack.EMPTY).getItem()) {
						{
							Entity _entity = entity;
							if (_entity instanceof Player _player) {
								_player.getInventory().armor.set(0,
										(entity instanceof LivingEntity _entGetArmor
												? _entGetArmor.getItemBySlot(EquipmentSlot.FEET)
												: ItemStack.EMPTY));
								_player.getInventory().setChanged();
							} else if (_entity instanceof LivingEntity _living) {
								_living.setItemSlot(EquipmentSlot.FEET,
										(entity instanceof LivingEntity _entGetArmor
												? _entGetArmor.getItemBySlot(EquipmentSlot.FEET)
												: ItemStack.EMPTY));
							}
						}
						{
							final int _slotid = 0;
							final ItemStack _setstack = itemstackiterator;
							_setstack.setCount(1);
							entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable _modHandler)
									_modHandler.setStackInSlot(_slotid, _setstack);
							});
						}
					}
					if ((new Object() {
						public ItemStack getItemStack(int sltid, Entity entity) {
							AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
							entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								_retval.set(capability.getStackInSlot(sltid).copy());
							});
							return _retval.get();
						}
					}.getItemStack(0, entity)).is(ItemTags.create(new ResourceLocation("minecraft:music_discs")))) {
						if (entity instanceof LivingEntity _entity) {
							ItemStack _setstack = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_setstack.setCount(1);
							_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
						if (entity instanceof LivingEntity _entity) {
							ItemStack _setstack = (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY);
							_setstack.setCount(1);
							_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
					}
				}
			}
		}
		entity.getPersistentData().putBoolean("logic",
				(((((entity.isInLava() && entity.isCurrentlyGlowing()) != entity
						.isInWaterOrBubble()) == ((entity instanceof LivingEntity _livEnt ? _livEnt.isSleeping() : false)
								^ entity.canChangeDimensions() || (entity instanceof LivingEntity _livEnt ? _livEnt.isBaby() : false))
						&& ((entity.isSwimming() && entity.ignoreExplosion()) != entity
								.isVehicle()) == ((entity instanceof LivingEntity _livEnt ? _livEnt.isFallFlying() : false)
										^ (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)
										|| entity.isOnFire())) != ((((entity instanceof LivingEntity _livEnt ? _livEnt.isBlocking() : false)
												&& entity.isInWall()) != entity instanceof TestLivingEntityEntity) == (entity.isAlive()
														^ entity.isInvisible()
														|| (entity instanceof LivingEntity _livEnt
																? _livEnt.hasEffect(TestModMobEffects.TEST_POTION.get())
																: false)))) == (((entity.isInvulnerable() && entity.isPassenger()) != entity
																		.getType()
																		.is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation(
																				"test:test3")))) == (entity.isInWater()
																						^ (entity instanceof TamableAnimal _tamIsTamedBy
																								&& sourceentity instanceof LivingEntity _livEnt
																										? _tamIsTamedBy.isOwnedBy(_livEnt)
																										: false)
																						|| entity.hasPermissions(4))
																		^ ((entity.level
																				.clip(new ClipContext(entity.getEyePosition(1f),
																						entity.getEyePosition(1f)
																								.add(entity.getViewVector(1f).scale(5)),
																						ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY, entity))
																				.getType() == HitResult.Type.BLOCK
																				&& (entity instanceof LivingEntity _livEnt
																						? _livEnt.getMobType() == MobType.WATER
																						: false)) != entity.fireImmune()) == (entity.isOnGround()
																								^ entity.isInWaterRainOrBubble()
																								|| (entity instanceof Mob _mobEnt
																										? _mobEnt.isLeashed()
																										: false))
																		|| entity.getPersistentData().getBoolean("logic"))));
		entity.getPersistentData().putDouble("number",
				(entity.getPersistentData().getDouble("number") + Math.pow(((entity.getBbHeight() - new Object() {
					public double getSubmergedHeight(Entity _entity) {
						for (TagKey<Fluid> _fldtag : Registry.FLUID.getTagNames().toList()) {
							if (_entity.level.getFluidState(entity.blockPosition()).is(_fldtag))
								return _entity.getFluidHeight(_fldtag);
						}
						return 0;
					}
				}.getSubmergedHeight(entity)) * entity.getBbWidth()) / entity.getAirSupply(),
						Mth.nextInt(RandomSource.create(), 0, 2023) % Mth.nextDouble(RandomSource.create(), 0, 4))));
		entity.getPersistentData().putString("string", (entity.getPersistentData().getString("string")));
		if ((entity.level.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
				ClipContext.Block.VISUAL, ClipContext.Fluid.SOURCE_ONLY, entity)).getDirection()) == (entity.getDirection())) {
			entity.fallDistance = 0;
		}
		for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			}
		}
		{
			Entity _ent = entity;
			if (!_ent.level.isClientSide() && _ent.getServer() != null) {
				Optional<CommandFunction> _fopt = _ent.getServer().getFunctions().get(new ResourceLocation("minecraft:tick"));
				if (_fopt.isPresent())
					_ent.getServer().getFunctions().execute(_fopt.get(), _ent.createCommandSourceStack());
			}
		}
		entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), (entity.getDeltaMovement().y()), (entity.getDeltaMovement().z())));
		entity.setDeltaMovement(new Vec3((entity.getLookAngle().x), (entity.getLookAngle().y), (entity.getLookAngle().z)));
		for (Entity entityiterator : entity.getIndirectPassengers()) {
			entity.setSecondsOnFire(15);
		}
		entity.setCustomName(Component.literal((entity.getDisplayName().getString())));
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth(entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
		entity.setNoGravity((entity.isNoGravity()));
		entity.setAirSupply(0);
		{
			Entity _ent = entity;
			_ent.setYRot(entity.getYRot());
			_ent.setXRot(entity.getXRot());
			_ent.setYBodyRot(_ent.getYRot());
			_ent.setYHeadRot(_ent.getYRot());
			_ent.yRotO = _ent.getYRot();
			_ent.xRotO = _ent.getXRot();
			if (_ent instanceof LivingEntity _entity) {
				_entity.yBodyRotO = _entity.getYRot();
				_entity.yHeadRotO = _entity.getYRot();
			}
		}
		entity.setShiftKeyDown((entity.isShiftKeyDown()));
		entity.setSprinting((entity.isSprinting()));
		if ((entity.getVehicle()) == (entity.getRootVehicle())) {
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.OFF_HAND, true);
		}
		{
			Entity _ent = entity;
			_ent.teleportTo((entity.getX()), (entity.getY()), (entity.getZ()));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport((entity.getX()), (entity.getY()), (entity.getZ()), _ent.getYRot(), _ent.getXRot());
		}
		{
			Entity _ent = entity;
			_ent.teleportTo(
					(entity.level.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
							ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getX()),
					(entity.level.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
							ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getY()),
					(entity.level.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
							ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ()));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(
						(entity.level
								.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
										ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity))
								.getBlockPos().getX()),
						(entity.level
								.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
										ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity))
								.getBlockPos().getY()),
						(entity.level
								.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)),
										ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity))
								.getBlockPos().getZ()),
						_ent.getYRot(), _ent.getXRot());
		}
		if (!((entity.getControllingPassenger()) == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null))) {
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.getLevel().getScoreboard();
				Objective _so = _sc.getObjective("custom_score");
				if (_so == null)
					_so = _sc.addObjective("custom_score", ObjectiveCriteria.DUMMY, Component.literal("custom_score"),
							ObjectiveCriteria.RenderType.INTEGER);
				_sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so)
						.setScore((int) Math.pow(((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.LUCK)
								? _livEnt.getEffect(MobEffects.LUCK).getDuration()
								: 0) + entity.getRemainingFireTicks())
								- ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)
										/ (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1))
										* (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.DAMAGE_BOOST)
												? _livEnt.getEffect(MobEffects.DAMAGE_BOOST).getAmplifier()
												: 0),
								new Object() {
									public int getScore(String score, Entity _ent) {
										Scoreboard _sc = _ent.getLevel().getScoreboard();
										Objective _so = _sc.getObjective(score);
										if (_so != null)
											return _sc.getOrCreatePlayerScore(_ent.getScoreboardName(), _so).getScore();
										return 0;
									}
								}.getScore("custom_score", entity)));
			}
		}
	}
}
