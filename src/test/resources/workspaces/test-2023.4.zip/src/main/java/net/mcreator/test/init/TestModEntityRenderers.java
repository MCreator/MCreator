
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.test.client.renderer.TestLivingEntityRenderer;
import net.mcreator.test.client.renderer.TestLivingEntity2Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TestModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY.get(), TestLivingEntityRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_RANGED_ITEM_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_2.get(), TestLivingEntity2Renderer::new);
	}
}
