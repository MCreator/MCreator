package net.mcreator.test.procedures;

import net.minecraft.world.entity.Entity;

public class EntityProviderProcedure {
	public static Entity execute(Entity entity) {
		if (entity == null)
			return null;
		return entity;
	}
}
