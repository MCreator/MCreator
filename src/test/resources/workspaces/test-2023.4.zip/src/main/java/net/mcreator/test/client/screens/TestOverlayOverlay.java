
package net.mcreator.test.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.test.procedures.TextProcedureProcedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.procedures.EntityProviderProcedure;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class TestOverlayOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexShader);
		RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		RenderSystem.setShaderColor(1, 1, 1, 1);
		if (true) {
			if (LogicProcedureProcedure.execute()) {
				event.getGuiGraphics().blit(new ResourceLocation("test:textures/screens/block.png"), w - 268, 173, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_label_text"), w / 2 + -182, h / 2 + -98, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					TextProcedureProcedure.execute(), w / 2 + -34, h / 2 + -97, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_empty"), w / 2 + -5, 54, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_bottom_corner"), w - 90, h - 25, -1, false);
			if (LogicProcedureProcedure.execute())
				event.getGuiGraphics().drawString(Minecraft.getInstance().font,

						TextProcedureProcedure.execute(), 30, h / 2 + -7, -16738048, false);
			if (EntityProviderProcedure.execute(entity) instanceof LivingEntity livingEntity) {
				if (LogicProcedureProcedure.execute())
					InventoryScreen.renderEntityInInventoryFollowsAngle(event.getGuiGraphics(), w - 56, 40, 30, 0f, 0, livingEntity);
			}
		}
		RenderSystem.depthMask(true);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}
