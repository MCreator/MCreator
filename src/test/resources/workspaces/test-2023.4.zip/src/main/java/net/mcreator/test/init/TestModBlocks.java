
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.test.block.TestPlantBlock;
import net.mcreator.test.block.TestPlant3Block;
import net.mcreator.test.block.TestPlant2Block;
import net.mcreator.test.block.TestFluidBlock;
import net.mcreator.test.block.TestDimensionPortalBlock;
import net.mcreator.test.block.TestBlockBlock;
import net.mcreator.test.block.OreBlock3Block;
import net.mcreator.test.block.OreBlock2Block;
import net.mcreator.test.block.NoGenBlockBlock;
import net.mcreator.test.TestMod;

public class TestModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TestMod.MODID);
	public static final RegistryObject<Block> TEST_BLOCK = REGISTRY.register("test_block", () -> new TestBlockBlock());
	public static final RegistryObject<Block> TEST_DIMENSION_PORTAL = REGISTRY.register("test_dimension_portal", () -> new TestDimensionPortalBlock());
	public static final RegistryObject<Block> TEST_FLUID = REGISTRY.register("test_fluid", () -> new TestFluidBlock());
	public static final RegistryObject<Block> TEST_PLANT = REGISTRY.register("test_plant", () -> new TestPlantBlock());
	public static final RegistryObject<Block> TEST_PLANT_2 = REGISTRY.register("test_plant_2", () -> new TestPlant2Block());
	public static final RegistryObject<Block> TEST_PLANT_3 = REGISTRY.register("test_plant_3", () -> new TestPlant3Block());
	public static final RegistryObject<Block> NO_GEN_BLOCK = REGISTRY.register("no_gen_block", () -> new NoGenBlockBlock());
	public static final RegistryObject<Block> ORE_BLOCK_2 = REGISTRY.register("ore_block_2", () -> new OreBlock2Block());
	public static final RegistryObject<Block> ORE_BLOCK_3 = REGISTRY.register("ore_block_3", () -> new OreBlock3Block());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			TestPlant3Block.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			TestPlant3Block.itemColorLoad(event);
		}
	}
}
