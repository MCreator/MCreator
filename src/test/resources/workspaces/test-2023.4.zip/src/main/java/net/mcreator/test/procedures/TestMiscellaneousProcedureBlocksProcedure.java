package net.mcreator.test.procedures;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.InteractionResult;
import net.minecraft.util.RandomSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.Advancement;

import net.mcreator.test.TestMod;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.ArrayList;

public class TestMiscellaneousProcedureBlocksProcedure {
	public static InteractionResult execute(LevelAccessor world, double x, double y, double z, Advancement advancement, BlockState blockstate, ResourceKey<Level> dimension, Direction direction, Entity entity, Entity immediatesourceentity,
			Entity sourceentity, ItemStack itemstack) {
		if (advancement == null || dimension == null || direction == null || entity == null || immediatesourceentity == null || sourceentity == null)
			return InteractionResult.PASS;
		world.setBlock(BlockPos.containing(x, y, z), Blocks.CHEST.defaultBlockState(), 3);
		if (new Object() {
			public int getAmount(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicInteger _retval = new AtomicInteger(0);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).getCount()));
				return _retval.get();
			}
		}.getAmount(world, BlockPos.containing(x, y, z), 0) == 0) {
			{
				BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y, z));
				if (_ent != null) {
					final int _slotid = 0;
					final ItemStack _setstack = new ItemStack(Items.APPLE);
					_setstack.setCount(1);
					_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
						if (capability instanceof IItemHandlerModifiable)
							((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
					});
				}
			}
		}
		if (((world instanceof Level _lvl3 && _lvl3.getServer() != null && _lvl3.getServer().getAdvancements().getAdvancement(new ResourceLocation("test:test_advancement"))
				.equals(advancement)) != (dimension == (ResourceKey.create(Registries.DIMENSION, new ResourceLocation("test:test_dimension"))))) == (entity.getDisplayName().getString()).equals(entity.getPersistentData().getString("name"))) {
			entity.clearFire();
		}
		if (false ^ entity instanceof AgeableMob) {
			sourceentity.startRiding(entity);
			if (!immediatesourceentity.level().isClientSide())
				immediatesourceentity.discard();
			if (entity.isVehicle()) {
				for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
					if (!(entityiterator == sourceentity)) {
						entityiterator.clearFire();
					}
				}
			}
		} else {
			{
				AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
				entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(_iitemhandlerref::set);
				if (_iitemhandlerref.get() != null) {
					for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
						ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
						if (itemstackiterator.getItem() == ItemStack.EMPTY.getItem()) {
							continue;
						} else if (itemstackiterator.getItem() == itemstack.getItem()) {
							while (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(itemstackiterator) : false) {
								if (entity instanceof Player _player) {
									ItemStack _stktoremove = itemstackiterator;
									_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
								}
							}
						} else {
							{
								ItemStack _ist = itemstack;
								if (_ist.hurt(1, RandomSource.create(), null)) {
									_ist.shrink(1);
									_ist.setDamageValue(0);
								}
							}
						}
					}
				}
			}
		}
		if (direction.getAxis() == Direction.Axis.Y) {
			for (Direction directioniterator : Direction.values()) {
				for (int index1 = 0; index1 < 1; index1++) {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate == Blocks.PISTON.defaultBlockState()) {
						{
							Direction _dir = (directioniterator.getClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x + direction.getStepX(), y + direction.getStepY(), z + direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
							if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else {
								_property = _bs.getBlock().getStateDefinition().getProperty("axis");
								if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
									world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				}
			}
			for (Direction directioniterator : Direction.Plane.HORIZONTAL) {
				TestMod.queueServerWork(20, () -> {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate.getBlock() == Blocks.OBSIDIAN) {
						{
							Direction _dir = (directioniterator.getCounterClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x - direction.getStepX(), y - direction.getStepY(), z - direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
							if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else {
								_property = _bs.getBlock().getStateDefinition().getProperty("axis");
								if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
									world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				});
			}
		}
		return (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.CHEST ? InteractionResult.SUCCESS : InteractionResult.PASS;
	}
}
