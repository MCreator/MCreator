
package net.mcreator.test.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;

import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.entity.TestLivingEntity2Entity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class TestLivingEntity2Renderer extends MobRenderer<TestLivingEntity2Entity, CreeperModel<TestLivingEntity2Entity>> {
	public TestLivingEntity2Renderer(EntityRendererProvider.Context context) {
		super(context, new CreeperModel<TestLivingEntity2Entity>(context.bakeLayer(ModelLayers.CREEPER)), 0.5f);
		this.addLayer(new RenderLayer<TestLivingEntity2Entity, CreeperModel<TestLivingEntity2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = ResourceLocation.parse("test:textures/entities/testgui.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, TestLivingEntity2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
				this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0));
			}
		});
		this.addLayer(new RenderLayer<TestLivingEntity2Entity, CreeperModel<TestLivingEntity2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = ResourceLocation.parse("test:textures/entities/testgui.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, TestLivingEntity2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (LogicProcedureProcedure.execute()) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, OverlayTexture.NO_OVERLAY);
				}
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(TestLivingEntity2Entity entity) {
		return ResourceLocation.parse("test:textures/entities/testgui.png");
	}

	@Override
	protected boolean isBodyVisible(TestLivingEntity2Entity entity) {
		return false;
	}

	@Override
	protected boolean isShaking(TestLivingEntity2Entity entity) {
		return true;
	}
}
