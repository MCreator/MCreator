
package net.mcreator.test.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class OreBlock2Block extends Block {
	public static final BooleanProperty DEMO = BooleanProperty.create("demo");
	public static final IntegerProperty EHRL = IntegerProperty.create("ehrl", 0, 6);
	public static final BooleanProperty INVERTED = BlockStateProperties.INVERTED;
	public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.AXIS;

	public OreBlock2Block() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.GRAVEL).strength(1f, 10f));
		this.registerDefaultState(this.stateDefinition.any().setValue(DEMO, true).setValue(EHRL, 0).setValue(INVERTED, false).setValue(AXIS, AXIS.getValue("y").get()));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(DEMO, EHRL, INVERTED, AXIS);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(DEMO, true).setValue(EHRL, 0).setValue(INVERTED, false).setValue(AXIS, AXIS.getValue("y").get());
	}
}
