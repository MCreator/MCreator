
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.test.TestMod;

import java.util.stream.Collectors;
import java.util.List;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TestModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(BuiltInRegistries.ATTRIBUTE, TestMod.MODID);
	public static final DeferredHolder<Attribute, Attribute> DEMO_ATTRIBUTE = REGISTRY.register("demo_attribute", () -> new RangedAttribute("attribute.test.demo_attribute", 0, 0, 10).setSyncable(true));
	public static final DeferredHolder<Attribute, Attribute> DEMO_ATTRIBUTE_2 = REGISTRY.register("demo_attribute_2", () -> new RangedAttribute("attribute.test.demo_attribute_2", 0, 0, 123).setSyncable(true));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.getTypes().forEach(entity -> event.add(entity, DEMO_ATTRIBUTE));
		List.of(TestModEntities.TEST_LIVING_ENTITY.get(), TestModEntities.TEST_LIVING_ENTITY_2.get(), TestModEntities.TEST_RANGED_ITEM_PROJECTILE.get(), EntityType.ALLAY, EntityType.AREA_EFFECT_CLOUD, EntityType.ARMADILLO, EntityType.ARMOR_STAND,
				EntityType.ARROW, EntityType.AXOLOTL, EntityType.BAT, EntityType.BEE, EntityType.BLAZE, EntityType.BLOCK_DISPLAY, EntityType.BOAT, EntityType.CHEST_BOAT, EntityType.BOGGED, EntityType.BREEZE, EntityType.BREEZE_WIND_CHARGE,
				EntityType.CAMEL, EntityType.CAT, EntityType.CAVE_SPIDER, EntityType.CHICKEN, EntityType.COD, EntityType.COW, EntityType.CREEPER, EntityType.DOLPHIN, EntityType.DONKEY, EntityType.ENDER_DRAGON, EntityType.DRAGON_FIREBALL,
				EntityType.DROWNED, EntityType.EGG, EntityType.ELDER_GUARDIAN, EntityType.END_CRYSTAL, EntityType.ENDER_PEARL, EntityType.ENDERMAN, EntityType.ENDERMITE, EntityType.EVOKER, EntityType.EVOKER_FANGS, EntityType.EXPERIENCE_BOTTLE,
				EntityType.EXPERIENCE_ORB, EntityType.EYE_OF_ENDER, EntityType.FALLING_BLOCK, EntityType.FIREBALL, EntityType.FIREWORK_ROCKET, EntityType.FOX, EntityType.FROG, EntityType.GHAST, EntityType.GIANT, EntityType.GLOW_ITEM_FRAME,
				EntityType.GLOW_SQUID, EntityType.GOAT, EntityType.GUARDIAN, EntityType.HOGLIN, EntityType.HORSE, EntityType.HUSK, EntityType.ILLUSIONER, EntityType.INTERACTION, EntityType.IRON_GOLEM, EntityType.ITEM, EntityType.ITEM_DISPLAY,
				EntityType.ITEM_FRAME, EntityType.LEASH_KNOT, EntityType.LIGHTNING_BOLT, EntityType.LLAMA, EntityType.LLAMA_SPIT, EntityType.MAGMA_CUBE, EntityType.MARKER, EntityType.MINECART, EntityType.CHEST_MINECART,
				EntityType.COMMAND_BLOCK_MINECART, EntityType.FURNACE_MINECART, EntityType.HOPPER_MINECART, EntityType.SPAWNER_MINECART, EntityType.TNT_MINECART, EntityType.MOOSHROOM, EntityType.MULE, EntityType.OCELOT,
				EntityType.OMINOUS_ITEM_SPAWNER, EntityType.PAINTING, EntityType.PANDA, EntityType.PARROT, EntityType.PHANTOM, EntityType.PIG, EntityType.PIGLIN, EntityType.PIGLIN_BRUTE, EntityType.PILLAGER, EntityType.POLAR_BEAR, EntityType.POTION,
				EntityType.PUFFERFISH, EntityType.RABBIT, EntityType.RAVAGER, EntityType.SALMON, EntityType.SHEEP, EntityType.SHULKER, EntityType.SHULKER_BULLET, EntityType.SILVERFISH, EntityType.SKELETON, EntityType.SKELETON_HORSE, EntityType.SLIME,
				EntityType.SMALL_FIREBALL, EntityType.SNIFFER, EntityType.SNOW_GOLEM, EntityType.SNOWBALL, EntityType.SPECTRAL_ARROW, EntityType.SPIDER, EntityType.SQUID, EntityType.STRAY, EntityType.STRIDER, EntityType.TADPOLE,
				EntityType.TEXT_DISPLAY, EntityType.TNT, EntityType.TRADER_LLAMA, EntityType.TRIDENT, EntityType.TROPICAL_FISH, EntityType.TURTLE, EntityType.VEX, EntityType.VILLAGER, EntityType.VINDICATOR, EntityType.WANDERING_TRADER,
				EntityType.WARDEN, EntityType.WIND_CHARGE, EntityType.WITCH, EntityType.WITHER, EntityType.WITHER_SKELETON, EntityType.WITHER_SKULL, EntityType.WOLF, EntityType.ZOGLIN, EntityType.ZOMBIE, EntityType.ZOMBIE_HORSE,
				EntityType.ZOMBIE_VILLAGER, EntityType.ZOMBIFIED_PIGLIN).stream().filter(DefaultAttributes::hasSupplier).map(entityType -> (EntityType<? extends LivingEntity>) entityType).collect(Collectors.toList())
				.forEach(entity -> event.add(entity, DEMO_ATTRIBUTE_2));
		event.add(EntityType.PLAYER, DEMO_ATTRIBUTE_2);
	}
}
