
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.test.client.renderer.TestLivingEntityRenderer;
import net.mcreator.test.client.renderer.TestLivingEntity2Renderer;
import net.mcreator.test.client.renderer.TestEntity2Renderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TestModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY.get(), TestLivingEntityRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_RANGED_ITEM_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_LIVING_ENTITY_2.get(), TestLivingEntity2Renderer::new);
		event.registerEntityRenderer(TestModEntities.TEST_ENTITY_2.get(), TestEntity2Renderer::new);
	}
}
