
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.test.procedures.NumberProvider2Procedure;
import net.mcreator.test.procedures.NumberProcedureProcedure;
import net.mcreator.test.item.inventory.TestMusicDiscInventoryCapability;
import net.mcreator.test.item.TestToolShieldItem;
import net.mcreator.test.item.TestToolItem;
import net.mcreator.test.item.TestTool4Item;
import net.mcreator.test.item.TestTool3Item;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestRangedItemItem;
import net.mcreator.test.item.TestRangedItem2Item;
import net.mcreator.test.item.TestMusicDiscItem;
import net.mcreator.test.item.TestItemStatesItem;
import net.mcreator.test.item.TestItemItem;
import net.mcreator.test.item.TestFoodItem;
import net.mcreator.test.item.TestFluidItem;
import net.mcreator.test.item.TestDimensionItem;
import net.mcreator.test.item.TestArmorItem;
import net.mcreator.test.TestMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TestModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TestMod.MODID);
	public static final DeferredItem<Item> TEST_ARMOR_HELMET = REGISTRY.register("test_armor_helmet", TestArmorItem.Helmet::new);
	public static final DeferredItem<Item> TEST_ARMOR_CHESTPLATE = REGISTRY.register("test_armor_chestplate", TestArmorItem.Chestplate::new);
	public static final DeferredItem<Item> TEST_ARMOR_LEGGINGS = REGISTRY.register("test_armor_leggings", TestArmorItem.Leggings::new);
	public static final DeferredItem<Item> TEST_ARMOR_BOOTS = REGISTRY.register("test_armor_boots", TestArmorItem.Boots::new);
	public static final DeferredItem<Item> TEST_BLOCK = block(TestModBlocks.TEST_BLOCK);
	public static final DeferredItem<Item> TEST_DIMENSION = REGISTRY.register("test_dimension", TestDimensionItem::new);
	public static final DeferredItem<Item> TEST_FOOD = REGISTRY.register("test_food", TestFoodItem::new);
	public static final DeferredItem<Item> TEST_FLUID_BUCKET = REGISTRY.register("test_fluid_bucket", TestFluidItem::new);
	public static final DeferredItem<Item> TEST_ITEM = REGISTRY.register("test_item", TestItemItem::new);
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_SPAWN_EGG = REGISTRY.register("test_living_entity_spawn_egg", () -> new DeferredSpawnEggItem(TestModEntities.TEST_LIVING_ENTITY, -13369396, -52378, new Item.Properties()));
	public static final DeferredItem<Item> TEST_PLANT = block(TestModBlocks.TEST_PLANT);
	public static final DeferredItem<Item> TEST_TOOL = REGISTRY.register("test_tool", TestToolItem::new);
	public static final DeferredItem<Item> TEST_TOOL_2 = REGISTRY.register("test_tool_2", TestTool2Item::new);
	public static final DeferredItem<Item> TEST_TOOL_3 = REGISTRY.register("test_tool_3", TestTool3Item::new);
	public static final DeferredItem<Item> TEST_TOOL_4 = REGISTRY.register("test_tool_4", TestTool4Item::new);
	public static final DeferredItem<Item> TEST_PLANT_2 = block(TestModBlocks.TEST_PLANT_2);
	public static final DeferredItem<Item> TEST_PLANT_3 = doubleBlock(TestModBlocks.TEST_PLANT_3);
	public static final DeferredItem<Item> NO_GEN_BLOCK = block(TestModBlocks.NO_GEN_BLOCK);
	public static final DeferredItem<Item> ORE_BLOCK_2 = block(TestModBlocks.ORE_BLOCK_2);
	public static final DeferredItem<Item> ORE_BLOCK_3 = block(TestModBlocks.ORE_BLOCK_3);
	public static final DeferredItem<Item> TEST_RANGED_ITEM = REGISTRY.register("test_ranged_item", TestRangedItemItem::new);
	public static final DeferredItem<Item> TEST_TOOL_SHIELD = REGISTRY.register("test_tool_shield", TestToolShieldItem::new);
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_2_SPAWN_EGG = REGISTRY.register("test_living_entity_2_spawn_egg", () -> new DeferredSpawnEggItem(TestModEntities.TEST_LIVING_ENTITY_2, -1, -1, new Item.Properties()));
	public static final DeferredItem<Item> TEST_RANGED_ITEM_2 = REGISTRY.register("test_ranged_item_2", TestRangedItem2Item::new);
	public static final DeferredItem<Item> TEST_ITEM_STATES = REGISTRY.register("test_item_states", TestItemStatesItem::new);
	public static final DeferredItem<Item> TEST_MUSIC_DISC = REGISTRY.register("test_music_disc", TestMusicDiscItem::new);
	public static final DeferredItem<Item> TEST_ENTITY_2_SPAWN_EGG = REGISTRY.register("test_entity_2_spawn_egg", () -> new DeferredSpawnEggItem(TestModEntities.TEST_ENTITY_2, -1, -1, new Item.Properties()));
	public static final DeferredItem<Item> TEST_PLANT_4 = block(TestModBlocks.TEST_PLANT_4);

	// Start of user code block custom items
	// End of user code block custom items
	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new TestMusicDiscInventoryCapability(stack), TEST_MUSIC_DISC.get());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(TEST_RANGED_ITEM.get(), ResourceLocation.parse("test:test_ranged_item_property1"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_RANGED_ITEM.get(), ResourceLocation.parse("test:test_ranged_item_property2"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_TOOL_SHIELD.get(), ResourceLocation.parse("minecraft:blocking"), ItemProperties.getProperty(new ItemStack(Items.SHIELD), ResourceLocation.parse("minecraft:blocking")));
				ItemProperties.register(TEST_RANGED_ITEM_2.get(), ResourceLocation.parse("test:test_ranged_item_2_property1"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_RANGED_ITEM_2.get(), ResourceLocation.parse("test:test_ranged_item_2_property2"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_ITEM_STATES.get(), ResourceLocation.parse("test:test_item_states_test"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_ITEM_STATES.get(), ResourceLocation.parse("test:test_item_states_test2"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProvider2Procedure.execute());
			});
		}
	}
}
