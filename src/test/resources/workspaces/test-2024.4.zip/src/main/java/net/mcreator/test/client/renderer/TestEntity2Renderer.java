
package net.mcreator.test.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.animation.definitions.ArmadilloAnimation;

import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.entity.TestEntity2Entity;
import net.mcreator.test.client.model.animations.MonsterAnimation;
import net.mcreator.test.client.model.ModelKreper117;

public class TestEntity2Renderer extends MobRenderer<TestEntity2Entity, ModelKreper117<TestEntity2Entity>> {
	public TestEntity2Renderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelKreper117.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(TestEntity2Entity entity) {
		return ResourceLocation.parse("test:textures/entities/testgui.png");
	}

	private static final class AnimatedModel extends ModelKreper117<TestEntity2Entity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<TestEntity2Entity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(TestEntity2Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, MonsterAnimation.MONSTER_IDLE, ageInTicks, 1f);
				this.animateWalk(ArmadilloAnimation.ARMADILLO_PEEK, limbSwing, limbSwingAmount, 1f, 1f);
				if (LogicProcedureProcedure.execute())
					this.animateWalk(MonsterAnimation.MONSTER_WALK, limbSwing, limbSwingAmount, 1f, 1.3f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(TestEntity2Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
