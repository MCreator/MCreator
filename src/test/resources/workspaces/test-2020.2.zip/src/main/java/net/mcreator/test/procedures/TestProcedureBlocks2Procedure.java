package net.mcreator.test.procedures;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Hand;
import net.minecraft.util.DamageSource;
import net.minecraft.potion.EffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.FunctionObject;

import net.mcreator.test.potion.TestPotionPotion;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestArmorItem;
import net.mcreator.test.entity.TestLivingEntityEntity;
import net.mcreator.test.TestElements;

import java.util.Optional;
import java.util.Collection;

@TestElements.ModElement.Tag
public class TestProcedureBlocks2Procedure extends TestElements.ModElement {
	public TestProcedureBlocks2Procedure(TestElements instance) {
		super(instance, 32);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure TestProcedureBlocks2!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure TestProcedureBlocks2!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure TestProcedureBlocks2!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure TestProcedureBlocks2!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure TestProcedureBlocks2!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure TestProcedureBlocks2!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		World world = (World) dependencies.get("world");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(TestPotionPotion.potion, (int) 60, (int) 1));
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(TestPotionPotion.potion, (int) 60,
					(int) ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getTotalArmorValue() : 0), (entity.isPassenger()),
					(entity.isBurning())));
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).clearActivePotions();
		entity.attackEntityFrom(DamageSource.GENERIC, (float) 1);
		entity.remove();
		if ((entity.hasPermissionLevel((int) 2))) {
			System.out.println((entity.getHorizontalFacing()));
		}
		if (!entity.world.isRemote && entity.world.getServer() != null) {
			entity.world.getServer().getCommandManager().handleCommand(entity.getCommandSource().withFeedbackDisabled().withPermissionLevel(4),
					(entity.getDisplayName().getFormattedText()));
		}
		entity.extinguish();
		System.out.println((((entity.getPersistentData().getBoolean("tagName"))) + "" + ((entity.getPersistentData().getDouble("tagName"))) + ""
				+ ((entity.getPersistentData().getString("tagName")))));
		if ((entity instanceof TestLivingEntityEntity.CustomEntity)) {
			entity.setPositionAndUpdate(x, y, z);
			entity.fallDistance = (float) (0);
		} else {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				Optional<FunctionObject> _fopt = entity.world.getServer().getFunctionManager().get(new ResourceLocation("namespace:function"));
				if (_fopt.isPresent()) {
					FunctionObject _fobj = _fopt.get();
					entity.world.getServer().getFunctionManager().execute(_fobj, entity.getCommandSource());
				}
			}
		}
		if ((new Object() {
			boolean check() {
				if (entity instanceof LivingEntity) {
					Collection<EffectInstance> effects = ((LivingEntity) entity).getActivePotionEffects();
					for (EffectInstance effect : effects) {
						if (effect.getPotion() == TestPotionPotion.potion)
							return true;
					}
				}
				return false;
			}
		}.check())) {
			entity.getPersistentData().putBoolean("tagName", (entity.isBeingRidden()));
		} else if ((entity.isSneaking())) {
			entity.getPersistentData().putDouble("tagName", (entity.dimension.getId()));
			entity.getPersistentData().putString("tagName", "tagValue");
		} else if ((entity.isSprinting())) {
			System.out.println(/* @ItemStack */((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY));
			System.out.println(/* @ItemStack */((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY));
		}
		entity.setMotionMultiplier(null, new Vec3d(0.25D, (double) 0.05F, 0.25D));
		entity.setMotion(0, 0, 0);
		entity.rotationYaw = 0;
		entity.rotationPitch = 0;
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).setHealth((float) 0);
		if (entity instanceof LivingEntity) {
			ItemStack _setstack = new ItemStack(TestTool2Item.block, (int) (1));
			_setstack.setCount(1);
			((LivingEntity) entity).setHeldItem(Hand.MAIN_HAND, _setstack);
			if (entity instanceof ServerPlayerEntity)
				((ServerPlayerEntity) entity).inventory.markDirty();
		}
		if (entity instanceof LivingEntity) {
			ItemStack _setstack = new ItemStack(TestArmorItem.legs, (int) (1));
			_setstack.setCount(1);
			((LivingEntity) entity).setHeldItem(Hand.OFF_HAND, _setstack);
			if (entity instanceof ServerPlayerEntity)
				((ServerPlayerEntity) entity).inventory.markDirty();
		}
		entity.setFire((int) 15);
		entity.setCustomName(new StringTextComponent("Display name"));
		if (!world.isRemote && entity instanceof LivingEntity) {
			ArrowEntity entityToSpawn = new ArrowEntity(world, (LivingEntity) entity);
			entityToSpawn.shoot(entity.getLookVec().x, entity.getLookVec().y, entity.getLookVec().z, ((float) 1) * 2.0F, 0);
			entityToSpawn.setDamage(((float) 5) * 2.0F);
			entityToSpawn.setKnockbackStrength((int) ((itemstack).getOrCreateTag().getDouble(((itemstack).getOrCreateTag().getString("tagName")))));
			world.addEntity(entityToSpawn);
		}
		if (entity instanceof LivingEntity) {
			((LivingEntity) entity).swingArm(Hand.MAIN_HAND);
		}
		if (entity instanceof LivingEntity) {
			((LivingEntity) entity).swingArm(Hand.OFF_HAND);
		}
	}
}
