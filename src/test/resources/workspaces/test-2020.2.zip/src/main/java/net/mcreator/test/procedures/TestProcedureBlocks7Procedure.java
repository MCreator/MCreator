package net.mcreator.test.procedures;

import net.minecraft.world.World;

import net.mcreator.test.TestVariables;
import net.mcreator.test.TestElements;

@TestElements.ModElement.Tag
public class TestProcedureBlocks7Procedure extends TestElements.ModElement {
	public TestProcedureBlocks7Procedure(TestElements instance) {
		super(instance, 37);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure TestProcedureBlocks7!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure TestProcedureBlocks7!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure TestProcedureBlocks7!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure TestProcedureBlocks7!");
			return;
		}
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		boolean local = false;
		double local2 = 0;
		String local3 = "";
		{
			java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
			$_dependencies.put("x", x);
			$_dependencies.put("y", y);
			$_dependencies.put("z", z);
			$_dependencies.put("world", world);
			TestProcedureProcedure.executeProcedure($_dependencies);
		}
		{
			java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
			$_dependencies.put("world", world);
			$_dependencies.put("x", (int) (x));
			$_dependencies.put("y", (int) (y));
			$_dependencies.put("z", (int) (z));
			TestProcedureProcedure.executeProcedure($_dependencies);
		}
		/* code */ local = (boolean) (local);
		local2 = (double) (local2);
		local3 = (String) (local3);
		TestVariables.MapVariables.get(world).test = (boolean) (TestVariables.MapVariables.get(world).test);
		TestVariables.MapVariables.get(world).syncData(world);
		TestVariables.MapVariables.get(world).test4 = (double) (TestVariables.MapVariables.get(world).test4);
		TestVariables.MapVariables.get(world).syncData(world);
		TestVariables.MapVariables.get(world).test7 = (String) (TestVariables.MapVariables.get(world).test7);
		TestVariables.MapVariables.get(world).syncData(world);
		TestVariables.WorldVariables.get(world).test2 = (boolean) (TestVariables.WorldVariables.get(world).test2);
		TestVariables.WorldVariables.get(world).syncData(world);
		TestVariables.WorldVariables.get(world).test5 = (double) (TestVariables.WorldVariables.get(world).test5);
		TestVariables.WorldVariables.get(world).syncData(world);
		TestVariables.WorldVariables.get(world).test8 = (String) (TestVariables.WorldVariables.get(world).test8);
		TestVariables.WorldVariables.get(world).syncData(world);
		TestVariables.test3 = (boolean) (TestVariables.test3);
		TestVariables.test6 = (double) (TestVariables.test6);
		TestVariables.test9 = (String) (TestVariables.test9);
		TestVariables.MapVariables.get(world).test4 = (double) new Object() {
			int convert(String s) {
				try {
					return Integer.parseInt(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((TestVariables.test9));
		TestVariables.MapVariables.get(world).syncData(world);
	}
}
