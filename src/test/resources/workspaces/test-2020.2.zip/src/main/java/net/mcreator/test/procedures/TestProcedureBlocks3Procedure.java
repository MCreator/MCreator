package net.mcreator.test.procedures;

import net.minecraftforge.common.ForgeHooks;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.Inventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.block.Blocks;

import net.mcreator.test.TestElements;

import java.util.Random;

@TestElements.ModElement.Tag
public class TestProcedureBlocks3Procedure extends TestElements.ModElement {
	public TestProcedureBlocks3Procedure(TestElements instance) {
		super(instance, 33);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure TestProcedureBlocks3!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure TestProcedureBlocks3!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure TestProcedureBlocks3!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		World world = (World) dependencies.get("world");
		itemstack.addEnchantment(Enchantments.PROTECTION, (int) 10);
		if (((new ItemStack(Blocks.ACACIA_LOG.getDefaultState().getBlock())).getItem().canHarvestBlock(Blocks.CYAN_BED.getDefaultState()))) {
			if (entity instanceof PlayerEntity)
				((PlayerEntity) entity).getCooldownTracker().setCooldown(itemstack.getItem(), (int) (itemstack.getDamage()));
		} else if ((world.getRecipeManager().getRecipe(IRecipeType.SMELTING, new Inventory(new ItemStack(Blocks.STICKY_PISTON, (int) (1))), world)
				.isPresent())) {
			if (itemstack.attemptDamageItem(
					(int) (EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, new ItemStack(Blocks.STICKY_PISTON, (int) (1)))),
					new Random(), null)) {
				itemstack.shrink(1);
				itemstack.setDamage(0);
			}
		}
		System.out.println(((itemstack).getOrCreateTag().getBoolean((new ItemStack(Blocks.PISTON_HEAD, (int) (1)).getDisplayName().getString()))));
		System.out.println((ForgeHooks.getBurnTime(new ItemStack(Blocks.ACACIA_LEAVES, (int) (1)))));
		(itemstack).getOrCreateTag().putBoolean("tagName",
				(ItemTags.getCollection().getOrCreate(new ResourceLocation(("logWood").toLowerCase(java.util.Locale.ENGLISH)))
						.contains((world.getRecipeManager()
								.getRecipe(IRecipeType.SMELTING, new Inventory(new ItemStack(Blocks.MOVING_PISTON, (int) (1))), world).isPresent()
										? world.getRecipeManager()
												.getRecipe(IRecipeType.SMELTING, new Inventory(new ItemStack(Blocks.MOVING_PISTON, (int) (1))), world)
												.get().getRecipeOutput().copy()
										: ItemStack.EMPTY).getItem())));
		(itemstack).getOrCreateTag().putDouble("tagName", (itemstack.getMaxDamage()));
		((itemstack).copy()).getOrCreateTag().putString("tagName", "tagValue");
		itemstack.setDamage((int) 0);
		itemstack.setDisplayName(new StringTextComponent("Display name"));
	}
}
