package net.mcreator.test.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.server.ServerLifecycleHooks;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.gen.feature.template.Template;
import net.minecraft.world.gen.feature.template.PlacementSettings;
import net.minecraft.world.World;
import net.minecraft.world.Explosion;
import net.minecraft.world.Difficulty;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.Rotation;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Mirror;
import net.minecraft.server.MinecraftServer;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.item.ExperienceOrbEntity;
import net.minecraft.entity.effect.LightningBoltEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.FunctionObject;
import net.minecraft.command.CommandSource;
import net.minecraft.block.Blocks;

import net.mcreator.test.world.dimension.TestDimensionDimension;
import net.mcreator.test.entity.TestLivingEntityEntity;
import net.mcreator.test.TestElements;

import java.util.Optional;

@TestElements.ModElement.Tag
public class TestProcedureBlocks6Procedure extends TestElements.ModElement {
	public TestProcedureBlocks6Procedure(TestElements instance) {
		super(instance, 36);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure TestProcedureBlocks6!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure TestProcedureBlocks6!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure TestProcedureBlocks6!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure TestProcedureBlocks6!");
			return;
		}
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		world.getWorldInfo().setRaining((world.canBlockSeeSky(new BlockPos((int) x, (int) y, (int) z))));
		if (!world.isRemote && world.getServer() != null) {
			world.getServer().getCommandManager()
					.handleCommand(new CommandSource(ICommandSource.field_213139_a_,
							new Vec3d((world.getBiome(new BlockPos((int) x, (int) y, (int) z)).getTemperature(new BlockPos((int) x, (int) y, (int) z))
									* 100.f), (world.getSpawnPoint().getX()), (world.getSpawnPoint().getY())),
							Vec2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), world.getServer(), null).withFeedbackDisabled(),
							"clear");
		}
		if (!world.isRemote) {
			world.createExplosion(null, (int) (world.getSpawnPoint().getZ()), (int) (world.getDayTime()),
					(int) (world.getDimension().getType().getId()), (float) (world.getCurrentMoonPhaseFactor()), Explosion.Mode.BREAK);
		}
		if ((world.isAirBlock(new BlockPos((int) x, (int) y, (int) z)))) {
			if ((ForgeRegistries.BIOMES.getKey(world.getBiome(new BlockPos((int) x, (int) y, (int) z)))
					.equals(new ResourceLocation("test:testbiome")))) {
				if (!world.isRemote) {
					Template template = ((ServerWorld) world.getWorld()).getSaveHandler().getStructureTemplateManager()
							.getTemplateDefaulted(new ResourceLocation("test", "plain_village_wheat_culture"));
					if (template != null) {
						template.addBlocksToWorldChunk(world,
								new BlockPos((int) (TestDimensionDimension.type.getId()),
										(int) (world.getRedstonePowerFromNeighbors(new BlockPos((int) x, (int) y, (int) z))),
										(int) (world.getLight(new BlockPos((int) x, (int) y, (int) z)))),
								new PlacementSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setChunk((ChunkPos) null)
										.setIgnoreEntities(false));
					}
				}
				world.playSound((PlayerEntity) null, x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("ambient.cave")),
						SoundCategory.NEUTRAL, (float) 1, (float) 1);
				if (!world.isRemote && world.getServer() != null) {
					Optional<FunctionObject> _fopt = world.getServer().getFunctionManager().get(new ResourceLocation("namespace:function"));
					if (_fopt.isPresent()) {
						FunctionObject _fobj = _fopt.get();
						world.getServer().getFunctionManager().execute(_fobj, new CommandSource(ICommandSource.field_213139_a_, new Vec3d(x, y, z),
								Vec2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), world.getServer(), null));
					}
				}
				{
					MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
					if (mcserv != null)
						mcserv.getPlayerList().sendMessage(new StringTextComponent("Message"));
				}
				if ((world.isDaytime())) {
					world.setSpawnPoint(new BlockPos((int) x, (int) x, (int) x));
				} else if ((world.getDifficulty() == Difficulty.PEACEFUL)) {
					world.setDayTime((int) 1);
				} else if ((true)) {
					for (int _ct = 0; _ct < 5; _ct++) {
						world.addOptionalParticle(ParticleTypes.EXPLOSION, x, y, z, 3, 3, 3);
					}
				} else if ((world.isRemote)) {
					if (!world.isRemote) {
						world.addEntity(new ExperienceOrbEntity(world, x, y, z, (int) 2));
					}
				} else if ((true)) {
					if (!world.isRemote) {
						Entity entityToSpawn = new TestLivingEntityEntity.CustomEntity(TestLivingEntityEntity.entity, world);
						entityToSpawn.setLocationAndAngles(x, y, z, world.rand.nextFloat() * 360F, 0);
						world.addEntity(entityToSpawn);
					}
				} else if ((world.isRaining())) {
					if (!world.isRemote) {
						ItemEntity entityToSpawn = new ItemEntity(world, x, y, z, new ItemStack(Blocks.AIR, (int) (1)));
						entityToSpawn.setPickupDelay(10);
						world.addEntity(entityToSpawn);
					}
				} else if ((world.isThundering())) {
					world.addParticle(ParticleTypes.EXPLOSION, x, y, z, 0, 1, 0);
					if (world instanceof ServerWorld)
						((ServerWorld) world).addLightningBolt(new LightningBoltEntity(world, (int) x, (int) y, (int) z, false));
				}
			}
		}
	}
}
