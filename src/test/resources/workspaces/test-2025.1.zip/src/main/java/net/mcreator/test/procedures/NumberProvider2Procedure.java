package net.mcreator.test.procedures;

public class NumberProvider2Procedure {
	public static double execute() {
		return 12;
	}
}
