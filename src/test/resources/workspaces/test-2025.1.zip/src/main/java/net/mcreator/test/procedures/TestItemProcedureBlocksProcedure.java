package net.mcreator.test.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.Holder;
import net.minecraft.client.Minecraft;

public class TestItemProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		Entity fakePlayer = null;
		itemstack.grow(0);
		itemstack.setCount(itemstack.getCount());
		itemstack.shrink(0);
		if (world instanceof ServerLevel _level) {
			itemstack.hurtAndBreak(0, _level, null, _stkprov -> {
			});
		}
		itemstack.setDamageValue(itemstack.getDamageValue());
		itemstack.enchant(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("test:test_enchantment"))), (int) Mth.nextDouble(RandomSource.create(), 1, 20));
		EnchantmentHelper.updateEnchantments(itemstack, mutableEnchantments -> mutableEnchantments.removeIf(enchantment -> enchantment.is(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.VANISHING_CURSE))));
		if (world.getServer() != null) {
			fakePlayer = null;
			if (fakePlayer instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack, Mth.nextInt(RandomSource.create(), 10, 200));
		}
		itemstack.applyComponents((itemstack.copy()).getComponents());
		{
			final String _tagName = "logic";
			final boolean _tagValue = (((itemstack.has(DataComponents.FOOD) && world instanceof ServerLevel _level29
					&& _level29.recipeAccess().getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(itemstack), _level29).isPresent()) != (itemstack.getRarity() == Rarity.EPIC)) == (itemstack.isEnchanted() ^ itemstack.isEnchantable()
							|| itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.FORTUNE)) != 0)
					|| (itemstack.getItem() == (getItemStackFromItemStackSlot(world,
							(new ItemStack(
									(BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(ResourceLocation.parse("minecraft:copper_ores")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value())))))
							.getItem()
							&& itemstack.getItem() instanceof PickaxeItem) != (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("logic") ^ new ItemStack(
									(BuiltInRegistries.ITEM.getRandomElementOf(ItemTags.create(ResourceLocation.parse("minecraft:mineable/pickaxe")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value()))
									.isCorrectToolForDrops((BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(ResourceLocation.parse("minecraft:diamond_ores")), RandomSource.create())
											.orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value()).defaultBlockState())));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(_tagName, _tagValue));
		}
		{
			final String _tagName = "number";
			final double _tagValue = (((world instanceof Level _levelFV53 ? itemstack.getBurnTime(null, _levelFV53.fuelValues()) : 0)
					/ itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY))
					+ (world instanceof Level _levelFV57 ? itemstack.getBurnTime(null, _levelFV57.fuelValues()) : 0) % itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.EFFICIENCY)))
					* (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("number")
							- Math.pow(itemstack.getMaxDamage(), itemstack.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.MENDING)))));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
		}
		{
			final String _tagName = "string";
			final String _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("string"));
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putString(_tagName, _tagValue));
		}
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation((EnchantmentHelper.enchantItem(world.getRandom(),
					((BuiltInRegistries.BLOCK.getRandomElementOf(BlockTags.create(ResourceLocation.parse("minecraft:walls")), RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR))
							.value()) instanceof LiquidBlock _liquid ? new ItemStack(_liquid.fluid.getBucket()) : ItemStack.EMPTY),
					(int) (Math.round(Math.random()) == 1 ? (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).nutrition() : 0) : (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).saturation() : 0)),
					((itemstack.is(ItemTags.create(ResourceLocation.parse("test:test")))))
							? world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).listElements().map(reference -> (Holder<Enchantment>) reference)
							: world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(EnchantmentTags.IN_ENCHANTING_TABLE).get().stream())));
		if (itemstack.getCapability(Capabilities.ItemHandler.ITEM, null) instanceof IItemHandlerModifiable _modHandlerItemSetSlot) {
			ItemStack _setstack = ((getItemStackFromItemStackSlot(0, itemstack)).copy()).copy();
			_setstack.setCount((getItemStackFromItemStackSlot(0, itemstack)).getCount());
			_modHandlerItemSetSlot.setStackInSlot(0, _setstack);
		}
		itemstack.set(DataComponents.CUSTOM_NAME, Component.literal((itemstack.getDisplayName().getString())));
	}

	private static ItemStack getItemStackFromItemStackSlot(LevelAccessor level, ItemStack input) {
		SingleRecipeInput recipeInput = new SingleRecipeInput(input);
		if (level instanceof ServerLevel serverLevel) {
			return serverLevel.recipeAccess().getRecipeFor(RecipeType.SMELTING, recipeInput, serverLevel).map(recipe -> recipe.value().assemble(recipeInput, serverLevel.registryAccess()).copy()).orElse(ItemStack.EMPTY);
		}
		return ItemStack.EMPTY;
	}

	private static ItemStack getItemStackFromItemStackSlot(int slotID, ItemStack itemStack) {
		IItemHandler itemHandler = itemStack.getCapability(Capabilities.ItemHandler.ITEM, null);
		if (itemHandler != null)
			return itemHandler.getStackInSlot(slotID).copy();
		return ItemStack.EMPTY;
	}
}
