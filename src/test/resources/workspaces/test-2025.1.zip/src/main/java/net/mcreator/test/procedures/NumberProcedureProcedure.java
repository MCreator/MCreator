package net.mcreator.test.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.test.entity.TestLivingEntityEntity;

public class NumberProcedureProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		return entity instanceof TestLivingEntityEntity _datEntI ? _datEntI.getEntityData().get(TestLivingEntityEntity.DATA_test1) : 0;
	}
}
