package net.mcreator.test.procedures;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ServerExplosion;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.commands.functions.CommandFunction;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.test.init.TestModMobEffects;
import net.mcreator.test.init.TestModAttributes;
import net.mcreator.test.entity.TestLivingEntityEntity;
import net.mcreator.test.TestMod;

import java.util.Optional;
import java.util.ArrayList;

public class TestEntityProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity immediatesourceentity, Entity sourceentity) {
		if (entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.LIGHTNING_BOLT)),
				(float) ((immediatesourceentity instanceof Projectile _projEnt ? _projEnt.getDeltaMovement().length() : 0) % (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)));
		if (entity instanceof LivingEntity _entity)
			_entity.removeAllEffects();
		if (!entity.level().isClientSide())
			entity.discard();
		entity.clearFire();
		sourceentity.startRiding(entity);
		entity.makeStuckInBlock(Blocks.AIR.defaultBlockState(), new Vec3(0.25, 0.05, 0.25));
		if (entity instanceof TamableAnimal _toTame && sourceentity instanceof Player _owner)
			_toTame.tame(_owner);
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(TestModMobEffects.TEST_POTION, 60, 1));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 3, (!((entity.level().dimension()) == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("test:test_dimension")))),
					((entity.level().dimension()) == Level.OVERWORLD)));
		entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 1);
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.getServer() != null) {
				_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
						_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "clear");
			}
		}
		if ((entity instanceof ItemEntity _itemEnt ? _itemEnt.getItem() : ItemStack.EMPTY).getItem() == ItemStack.EMPTY.getItem()) {
			{
				Entity _entity = entity;
				if (_entity instanceof Player _player) {
					_player.getInventory().armor.set(0, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY));
					_player.getInventory().setChanged();
				} else if (_entity instanceof LivingEntity _living) {
					_living.setItemSlot(EquipmentSlot.FEET, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY));
				}
			}
			if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler) {
				ItemStack _setstack = (entity instanceof ItemEntity _itemEnt ? _itemEnt.getItem() : ItemStack.EMPTY).copy();
				_setstack.setCount(1);
				_modHandler.setStackInSlot(0, _setstack);
			}
		}
		if ((entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler ? _modHandler.getStackInSlot(0).copy() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:music_discs")))) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).copy();
				_setstack.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack = (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).copy();
				_setstack.setCount(1);
				_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
		}
		if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandlerIter) {
			for (int _idx = 0; _idx < _modHandlerIter.getSlots(); _idx++) {
				ItemStack itemstackiterator = _modHandlerIter.getStackInSlot(_idx).copy();
				entity.getPersistentData().putBoolean("logic",
						(((((entity.isInLava() && entity.isCurrentlyGlowing()) != entity.isInWaterOrBubble()) == ((entity instanceof LivingEntity _livEnt37 && _livEnt37.isSleeping()) ^ entity.canTeleport(entity.level(), entity.level())
								|| entity instanceof LivingEntity _livEnt39 && _livEnt39.isBaby())
								&& ((entity.isSwimming() && entity.level() instanceof ServerLevel _levelExplosionCheck41
										&& entity.ignoreExplosion(new ServerExplosion(_levelExplosionCheck41, null, null, null, new Vec3(0, 0, 0), 1, false, Explosion.BlockInteraction.DESTROY))) != entity
												.isVehicle()) == ((entity instanceof LivingEntity _livEnt43 && _livEnt43.isFallFlying()) ^ (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)
														|| entity.isOnFire())) != (((entity instanceof LivingEntity _livEnt46 && _livEnt46.isBlocking() && entity.isInWall()) != entity instanceof TestLivingEntityEntity) == (entity.isAlive()
																^ entity.isInvisible()
																|| entity instanceof LivingEntity _livEnt51 && _livEnt51.hasEffect(TestModMobEffects.TEST_POTION)))) == (((entity.isInvulnerable() && entity.isPassenger()) != entity.getType()
																		.is(TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.parse("test:test3")))) == (entity.isInWater()
																				^ (entity instanceof TamableAnimal _tamIsTamedBy && sourceentity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false)
																				|| entity instanceof Player _playerCmd57 && _playerCmd57.hasPermissions(4))
																		^ ((entity.level()
																				.clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.OUTLINE, ClipContext.Fluid.ANY,
																						entity))
																				.getType() == HitResult.Type.BLOCK && entity.getType().is(EntityTypeTags.AQUATIC)) != entity.fireImmune()) == (entity.onGround() ^ entity.isInWaterRainOrBubble()
																						|| (entity instanceof Mob _mobEnt ? _mobEnt.isLeashed() : false))
																		|| entity.getPersistentData().getBoolean(("logic" + itemstackiterator)))));
			}
		}
		entity.getPersistentData().putDouble("number", (entity.getPersistentData().getDouble("number")
				+ Math.pow(((entity.getBbHeight() - getEntitySubmergedHeight(entity)) * entity.getBbWidth()) / entity.getAirSupply(), Mth.nextInt(RandomSource.create(), 0, 2023) % Mth.nextDouble(RandomSource.create(), 0, 4))));
		entity.getPersistentData().putString("string", (entity.getPersistentData().getString("string")));
		if ((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.VISUAL, ClipContext.Fluid.SOURCE_ONLY, entity)).getDirection()) == (entity
				.getDirection())) {
			entity.fallDistance = 0;
		}
		for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			}
		}
		{
			Entity _ent = entity;
			if (_ent.level() instanceof ServerLevel _serverLevel && _ent.getServer() != null) {
				Optional<CommandFunction<CommandSourceStack>> _fopt = _ent.getServer().getFunctions().get(ResourceLocation.parse("minecraft:tick"));
				if (_fopt.isPresent())
					_ent.getServer().getFunctions().execute(_fopt.get(), _ent.createCommandSourceStackForNameResolution(_serverLevel));
			}
		}
		entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), (entity.getDeltaMovement().y()), (entity.getDeltaMovement().z())));
		entity.setDeltaMovement(new Vec3((entity.getLookAngle().x), (entity.getLookAngle().y), (entity.getLookAngle().z)));
		for (Entity entityiterator : entity.getIndirectPassengers()) {
			entity.igniteForSeconds(15);
		}
		entity.setCustomName(Component.literal((entity.getDisplayName().getString())));
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth(entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1);
		entity.setNoGravity((entity.isNoGravity()));
		entity.setAirSupply(0);
		{
			Entity _ent = entity;
			_ent.setYRot(entity.getYRot());
			_ent.setXRot(entity.getXRot());
			_ent.setYBodyRot(_ent.getYRot());
			_ent.setYHeadRot(_ent.getYRot());
			_ent.yRotO = _ent.getYRot();
			_ent.xRotO = _ent.getXRot();
			if (_ent instanceof LivingEntity _entity) {
				_entity.yBodyRotO = _entity.getYRot();
				_entity.yHeadRotO = _entity.getYRot();
			}
		}
		entity.setShiftKeyDown((entity.isShiftKeyDown()));
		entity.setSprinting((entity.isSprinting()));
		if ((entity.getVehicle()) == (entity.getRootVehicle())) {
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			if (entity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.OFF_HAND, true);
		}
		{
			Entity _ent = entity;
			_ent.teleportTo((entity.getX()), (entity.getY()), (entity.getZ()));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport((entity.getX()), (entity.getY()), (entity.getZ()), _ent.getYRot(), _ent.getXRot());
		}
		{
			Entity _ent = entity;
			_ent.teleportTo((entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getX()),
					(entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getY()),
					(entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ()));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(
						(entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getX()),
						(entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getY()),
						(entity.level().clip(new ClipContext(entity.getEyePosition(1f), entity.getEyePosition(1f).add(entity.getViewVector(1f).scale(5)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity)).getBlockPos().getZ()),
						_ent.getYRot(), _ent.getXRot());
		}
		if (!((entity.getControllingPassenger()) == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null))) {
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.level().getScoreboard();
				Objective _so = _sc.getObjective("custom_score");
				if (_so == null)
					_so = _sc.addObjective("custom_score", ObjectiveCriteria.DUMMY, Component.literal("custom_score"), ObjectiveCriteria.RenderType.INTEGER, true, null);
				_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()),
						_so).set(
								(int) Math.pow(
										((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.LUCK) ? _livEnt.getEffect(MobEffects.LUCK).getDuration() : 0) + entity.getRemainingFireTicks())
												- ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) / (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1))
														* (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.DAMAGE_BOOST) ? _livEnt.getEffect(MobEffects.DAMAGE_BOOST).getAmplifier() : 0),
										getEntityScore("custom_score", entity)));
			}
		}
		if (entity instanceof LivingEntity _livingEntity134 && _livingEntity134.getAttributes().hasAttribute(Attributes.ATTACK_SPEED)) {
			if (entity instanceof LivingEntity _livingEntity136 && _livingEntity136.getAttributes().hasAttribute(TestModAttributes.DEMO_ATTRIBUTE))
				_livingEntity136.getAttribute(TestModAttributes.DEMO_ATTRIBUTE).setBaseValue(
						(entity instanceof LivingEntity _livingEntity135 && _livingEntity135.getAttributes().hasAttribute(TestModAttributes.DEMO_ATTRIBUTE_2) ? _livingEntity135.getAttribute(TestModAttributes.DEMO_ATTRIBUTE_2).getBaseValue() : 0));
			TestMod.LOGGER.info(entity instanceof LivingEntity _livingEntity137 && _livingEntity137.getAttributes().hasAttribute(Attributes.SUBMERGED_MINING_SPEED) ? _livingEntity137.getAttribute(Attributes.SUBMERGED_MINING_SPEED).getValue() : 0);
		}
	}

	private static double getEntitySubmergedHeight(Entity entity) {
		for (FluidType fluidType : NeoForgeRegistries.FLUID_TYPES) {
			if (entity.level().getFluidState(entity.blockPosition()).getFluidType() == fluidType)
				return entity.getFluidTypeHeight(fluidType);
		}
		return 0;
	}

	private static int getEntityScore(String score, Entity entity) {
		Scoreboard scoreboard = entity.level().getScoreboard();
		Objective scoreboardObjective = scoreboard.getObjective(score);
		if (scoreboardObjective != null)
			return scoreboard.getOrCreatePlayerScore(ScoreHolder.forNameOnly(entity.getScoreboardName()), scoreboardObjective).get();
		return 0;
	}
}
