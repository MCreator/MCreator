
package net.mcreator.test.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.test.init.TestModParticleTypes;
import net.mcreator.test.init.TestModAttributes;
import net.mcreator.test.TestMod;

public class TestEffectMobEffect extends MobEffect {
	public TestEffectMobEffect() {
		super(MobEffectCategory.NEUTRAL, -1, mobEffectInstance -> (SimpleParticleType) (TestModParticleTypes.TEST_PARTICLE_2.get()));
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.basalt_deltas.additions")));
		this.addAttributeModifier(TestModAttributes.DEMO_ATTRIBUTE, ResourceLocation.fromNamespaceAndPath(TestMod.MODID, "effect.test_effect_0"), 0.03, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(TestModAttributes.DEMO_ATTRIBUTE_2, ResourceLocation.fromNamespaceAndPath(TestMod.MODID, "effect.test_effect_1"), 0.03, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
		this.addAttributeModifier(Attributes.ATTACK_SPEED, ResourceLocation.fromNamespaceAndPath(TestMod.MODID, "effect.test_effect_2"), -3, AttributeModifier.Operation.ADD_VALUE);
		this.addAttributeModifier(Attributes.KNOCKBACK_RESISTANCE, ResourceLocation.fromNamespaceAndPath(TestMod.MODID, "effect.test_effect_3"), -0.16, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
	}
}
