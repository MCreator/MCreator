
package net.mcreator.test.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.animation.definitions.ArmadilloAnimation;

import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.entity.TestEntity2Entity;
import net.mcreator.test.client.model.animations.MonsterAnimation;
import net.mcreator.test.client.model.ModelKreper117;

public class TestEntity2Renderer extends MobRenderer<TestEntity2Entity, LivingEntityRenderState, ModelKreper117> {
	private TestEntity2Entity entity = null;

	public TestEntity2Renderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelKreper117.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(TestEntity2Entity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("test:textures/entities/testgui.png");
	}

	private static final class AnimatedModel extends ModelKreper117 {
		private TestEntity2Entity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(TestEntity2Entity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, MonsterAnimation.MONSTER_IDLE, state.ageInTicks, 1f);
			this.animateWalk(ArmadilloAnimation.ARMADILLO_PEEK, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1f);
			if (LogicProcedureProcedure.execute())
				this.animateWalk(MonsterAnimation.MONSTER_WALK, state.walkAnimationPos, state.walkAnimationSpeed, 1f, 1.3f);
			super.setupAnim(state);
		}
	}
}
