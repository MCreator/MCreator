
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.test.procedures.NumberProcedureProcedure;
import net.mcreator.test.item.TestToolShieldItem;
import net.mcreator.test.item.TestToolItem;
import net.mcreator.test.item.TestTool4Item;
import net.mcreator.test.item.TestTool3Item;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestRangedItemItem;
import net.mcreator.test.item.TestMusicDiscItem;
import net.mcreator.test.item.TestItemItem;
import net.mcreator.test.item.TestFoodItem;
import net.mcreator.test.item.TestFluidItem;
import net.mcreator.test.item.TestDimensionItem;
import net.mcreator.test.item.TestArmorItem;
import net.mcreator.test.TestMod;

public class TestModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, TestMod.MODID);
	public static final DeferredHolder<Item, Item> TEST_ARMOR_HELMET = REGISTRY.register("test_armor_helmet", () -> new TestArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> TEST_ARMOR_CHESTPLATE = REGISTRY.register("test_armor_chestplate", () -> new TestArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> TEST_ARMOR_LEGGINGS = REGISTRY.register("test_armor_leggings", () -> new TestArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> TEST_ARMOR_BOOTS = REGISTRY.register("test_armor_boots", () -> new TestArmorItem.Boots());
	public static final DeferredHolder<Item, Item> TEST_BLOCK = block(TestModBlocks.TEST_BLOCK);
	public static final DeferredHolder<Item, Item> TEST_DIMENSION = REGISTRY.register("test_dimension", () -> new TestDimensionItem());
	public static final DeferredHolder<Item, Item> TEST_FOOD = REGISTRY.register("test_food", () -> new TestFoodItem());
	public static final DeferredHolder<Item, Item> TEST_FLUID_BUCKET = REGISTRY.register("test_fluid_bucket", () -> new TestFluidItem());
	public static final DeferredHolder<Item, Item> TEST_ITEM = REGISTRY.register("test_item", () -> new TestItemItem());
	public static final DeferredHolder<Item, Item> TEST_LIVING_ENTITY_SPAWN_EGG = REGISTRY.register("test_living_entity_spawn_egg", () -> new DeferredSpawnEggItem(TestModEntities.TEST_LIVING_ENTITY, -13369396, -52378, new Item.Properties()));
	public static final DeferredHolder<Item, Item> TEST_MUSIC_DISC = REGISTRY.register("test_music_disc", () -> new TestMusicDiscItem());
	public static final DeferredHolder<Item, Item> TEST_PLANT = block(TestModBlocks.TEST_PLANT);
	public static final DeferredHolder<Item, Item> TEST_TOOL = REGISTRY.register("test_tool", () -> new TestToolItem());
	public static final DeferredHolder<Item, Item> TEST_TOOL_2 = REGISTRY.register("test_tool_2", () -> new TestTool2Item());
	public static final DeferredHolder<Item, Item> TEST_TOOL_3 = REGISTRY.register("test_tool_3", () -> new TestTool3Item());
	public static final DeferredHolder<Item, Item> TEST_TOOL_4 = REGISTRY.register("test_tool_4", () -> new TestTool4Item());
	public static final DeferredHolder<Item, Item> TEST_PLANT_2 = block(TestModBlocks.TEST_PLANT_2);
	public static final DeferredHolder<Item, Item> TEST_PLANT_3 = doubleBlock(TestModBlocks.TEST_PLANT_3);
	public static final DeferredHolder<Item, Item> NO_GEN_BLOCK = block(TestModBlocks.NO_GEN_BLOCK);
	public static final DeferredHolder<Item, Item> ORE_BLOCK_2 = block(TestModBlocks.ORE_BLOCK_2);
	public static final DeferredHolder<Item, Item> ORE_BLOCK_3 = block(TestModBlocks.ORE_BLOCK_3);
	public static final DeferredHolder<Item, Item> TEST_RANGED_ITEM = REGISTRY.register("test_ranged_item", () -> new TestRangedItemItem());
	public static final DeferredHolder<Item, Item> TEST_TOOL_SHIELD = REGISTRY.register("test_tool_shield", () -> new TestToolShieldItem());
	public static final DeferredHolder<Item, Item> TEST_LIVING_ENTITY_2_SPAWN_EGG = REGISTRY.register("test_living_entity_2_spawn_egg", () -> new DeferredSpawnEggItem(TestModEntities.TEST_LIVING_ENTITY_2, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static DeferredHolder<Item, Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(TEST_RANGED_ITEM.get(), new ResourceLocation("test:test_ranged_item_property1"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_RANGED_ITEM.get(), new ResourceLocation("test:test_ranged_item_property2"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) NumberProcedureProcedure.execute(entity));
				ItemProperties.register(TEST_TOOL_SHIELD.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
			});
		}
	}
}
