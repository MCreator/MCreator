package net.mcreator.test.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.test.init.TestModMobEffects;
import net.mcreator.test.TestMod;

public class TestNewProceduresProcedure {
	public static void execute(LevelAccessor world, double x, DamageSource damagesource, Entity entity, Entity immediatesourceentity, Entity sourceentity, ItemStack itemstack) {
		if (damagesource == null || entity == null || immediatesourceentity == null || sourceentity == null)
			return;
		if (damagesource.isCreativePlayer()) {
			(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("test:custom_damage_type")))).getDirectEntity())
					.startRiding((new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.BAD_RESPAWN_POINT), sourceentity).getEntity()));
		} else if (entity.isAttackable()) {
			TestMod.LOGGER.info(damagesource.is(TagKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("minecraft:is_fire"))));
			TestMod.LOGGER.info((new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.DROWN), sourceentity).getEntity()).getStringUUID());
		} else if (damagesource.isIndirect()) {
			TestMod.LOGGER.info(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.THROWN), immediatesourceentity, sourceentity).getFoodExhaustion());
			TestMod.LOGGER.info(damagesource.scalesWithDifficulty());
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(TestModMobEffects.TEST_POTION.get(), 60, (int) (entity.getPercentFrozen() * 100), (entity.isUnderWater()),
						(entity instanceof LivingEntity _entMainHand17 && _entMainHand17.getMainArm() == HumanoidArm.RIGHT)));
			entity.setInvisible((entity instanceof Player _plrCldCheck20 && _plrCldCheck20.getCooldowns().isOnCooldown((entity instanceof LivingEntity _entUseItem19 ? _entUseItem19.getUseItem() : ItemStack.EMPTY).getItem())));
			if (world instanceof ILevelExtension _ext
					&& _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, entity instanceof Player _plrCldRem23 ? _plrCldRem23.getCooldowns().getCooldownPercent(itemstack.getItem(), 0f) * 100 : 0, new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.level().getScoreboard();
							Objective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so).get();
							return 0;
						}
					}.getScore("score1", entity)), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
				ItemStack _setstack = (entity instanceof LivingEntity _entUseItem26 ? _entUseItem26.getUseItem() : ItemStack.EMPTY).copy();
				_setstack.setCount(1);
				_itemHandlerModifiable.setStackInSlot(entity instanceof LivingEntity _entUseTicks25 ? _entUseTicks25.getTicksUsingItem() : 0, _setstack);
			}
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.level().getScoreboard();
				Objective _so = _sc.getObjective("custom_score");
				if (_so == null)
					_so = _sc.addObjective("custom_score", ObjectiveCriteria.DUMMY, Component.literal("custom_score"), ObjectiveCriteria.RenderType.INTEGER, true, null);
				_sc.getOrCreatePlayerScore(ScoreHolder.forNameOnly(_ent.getScoreboardName()), _so).set(1);
			}
		}
		if (world instanceof Level _level && _level.getScoreboard().getPlayerTeam("team_name") != null ? _level.getScoreboard().getPlayerTeam("team_name").isAllowFriendlyFire() : false) {
			{
				Entity _entityTeam = entity;
				PlayerTeam _pt = _entityTeam.level().getScoreboard()
						.getPlayerTeam((entity instanceof LivingEntity _teamEnt && _teamEnt.level().getScoreboard().getPlayersTeam(_teamEnt instanceof Player _pl ? _pl.getGameProfile().getName() : _teamEnt.getStringUUID()) != null
								? _teamEnt.level().getScoreboard().getPlayersTeam(_teamEnt instanceof Player _pl ? _pl.getGameProfile().getName() : _teamEnt.getStringUUID()).getName()
								: ""));
				if (_pt != null) {
					if (_entityTeam instanceof Player _player)
						_entityTeam.level().getScoreboard().addPlayerToTeam(_player.getGameProfile().getName(), _pt);
					else
						_entityTeam.level().getScoreboard().addPlayerToTeam(_entityTeam.getStringUUID(), _pt);
				}
			}
			if (world instanceof Level _level) {
				PlayerTeam _pt = _level.getScoreboard().getPlayerTeam("abc");
				if (_pt != null)
					_level.getScoreboard().removePlayerTeam(_pt);
			}
			if (world instanceof Level _level)
				_level.getScoreboard().addPlayerTeam("bestteam");
			{
				Entity _entityTeam = entity;
				PlayerTeam _pt = _entityTeam.level().getScoreboard().getPlayerTeam("team_name");
				if (_pt != null)
					_entityTeam.level().getScoreboard().removePlayerFromTeam(_entityTeam.getStringUUID(), _pt);
			}
			if (world instanceof Level _level) {
				PlayerTeam _pt = _level.getScoreboard().getPlayerTeam("anotherteam");
				if (_pt != null)
					_pt.setAllowFriendlyFire(false);
			}
		}
	}
}
