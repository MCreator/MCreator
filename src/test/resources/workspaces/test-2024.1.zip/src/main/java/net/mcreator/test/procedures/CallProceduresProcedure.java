package net.mcreator.test.procedures;

import net.neoforged.neoforge.event.entity.player.EntityItemPickupEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.test.TestMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class CallProceduresProcedure {
	@SubscribeEvent
	public static void onPickup(EntityItemPickupEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		TestMod.LOGGER.info(NumberProcedureProcedure.execute(entity));
		TestMod.LOGGER.info(EntityProviderProcedure.execute(entity));
		TestWorldProcedureBlocksProcedure.execute(world, x, y, z);
		TestBlockProcedureBlocksProcedure.execute(world, x, y, z);
		if (event != null && event.hasResult()) {
			event.setResult(Event.Result.ALLOW);
		}
		if (event instanceof ICancellableEvent _cancellable) {
			_cancellable.setCanceled(true);
		}
	}
}
