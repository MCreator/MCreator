package net.mcreator.test.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.SimpleContainer;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.Minecraft;

import net.mcreator.test.init.TestModEnchantments;

import java.util.Map;

public class TestItemProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		Entity fakePlayer = null;
		itemstack.grow(0);
		itemstack.setCount(itemstack.getCount());
		itemstack.shrink(0);
		{
			ItemStack _ist = itemstack;
			if (_ist.hurt(0, RandomSource.create(), null)) {
				_ist.shrink(1);
				_ist.setDamageValue(0);
			}
		}
		itemstack.setDamageValue(itemstack.getDamageValue());
		itemstack.enchant(TestModEnchantments.TEST_ENCHANTMENT.get(), (int) Mth.nextDouble(RandomSource.create(), 1, 20));
		{
			Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
			if (_enchantments.containsKey(Enchantments.VANISHING_CURSE)) {
				_enchantments.remove(Enchantments.VANISHING_CURSE);
				EnchantmentHelper.setEnchantments(_enchantments, itemstack);
			}
		}
		if (world.getServer() != null) {
			fakePlayer = null;
			if (fakePlayer instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack.getItem(), Mth.nextInt(RandomSource.create(), 10, 200));
		}
		{
			CompoundTag _nbtTag = (itemstack.copy()).getTag();
			if (_nbtTag != null)
				itemstack.setTag(_nbtTag.copy());
		}
		itemstack.getOrCreateTag().putBoolean("logic",
				(((itemstack.getItem().isEdible() && world instanceof Level _level29
						&& _level29.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(itemstack), _level29).isPresent()) != (itemstack.getRarity() == Rarity.EPIC)) == (itemstack.isEnchanted() ^ itemstack.isEnchantable()
								|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0)
						|| (itemstack
								.getItem() == (world instanceof Level _lvlSmeltResult
										? _lvlSmeltResult.getRecipeManager()
												.getRecipeFor(RecipeType.SMELTING,
														new SimpleContainer((new ItemStack((BuiltInRegistries.BLOCK.getOrCreateTag(BlockTags.create(new ResourceLocation("minecraft:copper_ores"))).getRandomElement(RandomSource.create())
																.orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value())))),
														_lvlSmeltResult)
												.map(recipe -> recipe.value().getResultItem(_lvlSmeltResult.registryAccess()).copy()).orElse(ItemStack.EMPTY)
										: ItemStack.EMPTY).getItem()
								&& itemstack.getItem() instanceof PickaxeItem) != (itemstack.getOrCreateTag().getBoolean("logic") ^ (BuiltInRegistries.ITEM.getOrCreateTag(ItemTags.create(new ResourceLocation("minecraft:mineable/pickaxe")))
										.getRandomElement(RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value())
										.isCorrectToolForDrops((BuiltInRegistries.BLOCK.getOrCreateTag(BlockTags.create(new ResourceLocation("minecraft:diamond_ores"))).getRandomElement(RandomSource.create())
												.orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR)).value()).defaultBlockState()))));
		itemstack.getOrCreateTag().putDouble("number", ((itemstack.getBurnTime(null) / itemstack.getEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY) + itemstack.getBurnTime(null) % itemstack.getEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY))
				* (itemstack.getOrCreateTag().getDouble("number") - Math.pow(itemstack.getMaxDamage(), itemstack.getEnchantmentLevel(Enchantments.MENDING)))));
		itemstack.getOrCreateTag().putString("string", (itemstack.getOrCreateTag().getString("string")));
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation((EnchantmentHelper.enchantItem(RandomSource.create(),
					((BuiltInRegistries.BLOCK.getOrCreateTag(BlockTags.create(new ResourceLocation("minecraft:walls"))).getRandomElement(RandomSource.create()).orElseGet(() -> BuiltInRegistries.BLOCK.wrapAsHolder(Blocks.AIR))
							.value()) instanceof LiquidBlock _liquid ? new ItemStack(_liquid.getFluid().getBucket()) : ItemStack.EMPTY),
					(int) (Math.round(Math.random()) == 1
							? (itemstack.getItem().isEdible() ? itemstack.getItem().getFoodProperties().getNutrition() : 0)
							: (itemstack.getItem().isEdible() ? itemstack.getItem().getFoodProperties().getSaturationModifier() : 0)),
					(itemstack.is(ItemTags.create(new ResourceLocation("test:test")))))));
		if (itemstack.getCapability(Capabilities.ItemHandler.ITEM, null) instanceof IItemHandlerModifiable _modHandlerItemSetSlot) {
			ItemStack _setstack = ((new Object() {
				public ItemStack getItemStack(int sltid, ItemStack _isc) {
					IItemHandler _itemHandler = _isc.getCapability(Capabilities.ItemHandler.ITEM, null);
					if (_itemHandler != null)
						return _itemHandler.getStackInSlot(sltid).copy();
					return ItemStack.EMPTY;
				}
			}.getItemStack(0, itemstack)).copy()).copy();
			_setstack.setCount((new Object() {
				public ItemStack getItemStack(int sltid, ItemStack _isc) {
					IItemHandler _itemHandler = _isc.getCapability(Capabilities.ItemHandler.ITEM, null);
					if (_itemHandler != null)
						return _itemHandler.getStackInSlot(sltid).copy();
					return ItemStack.EMPTY;
				}
			}.getItemStack(0, itemstack)).getCount());
			_modHandlerItemSetSlot.setStackInSlot(0, _setstack);
		}
		itemstack.setHoverName(Component.literal((itemstack.getDisplayName().getString())));
	}
}
