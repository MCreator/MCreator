
package net.mcreator.test.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.InstantenousMobEffect;

import net.mcreator.test.procedures.TestProcedureProcedure;

public class TestPotionMobEffect extends InstantenousMobEffect {
	public TestPotionMobEffect() {
		super(MobEffectCategory.HARMFUL, -1);
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		TestProcedureProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		TestProcedureProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
	}
}
