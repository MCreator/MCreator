
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.TestMod;

public class TestModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(Registries.PAINTING_VARIANT, TestMod.MODID);
	public static final DeferredHolder<PaintingVariant, PaintingVariant> TEST_PAINTING = REGISTRY.register("test_painting", () -> new PaintingVariant(16, 16));
}
