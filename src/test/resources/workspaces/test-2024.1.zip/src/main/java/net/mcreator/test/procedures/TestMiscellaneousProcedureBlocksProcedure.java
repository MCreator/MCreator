package net.mcreator.test.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.InteractionResult;
import net.minecraft.util.RandomSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.Advancement;

import net.mcreator.test.TestMod;

import java.util.ArrayList;

public class TestMiscellaneousProcedureBlocksProcedure {
	public static InteractionResult execute(LevelAccessor world, double x, double y, double z, Advancement advancement, BlockState blockstate, ResourceKey<Level> dimension, Direction direction, Entity entity, Entity immediatesourceentity,
			Entity sourceentity, ItemStack itemstack) {
		if (advancement == null || dimension == null || direction == null || entity == null || immediatesourceentity == null || sourceentity == null)
			return InteractionResult.PASS;
		world.setBlock(BlockPos.containing(x, y, z), Blocks.CHEST.defaultBlockState(), 3);
		if (new Object() {
			public int getAmount(LevelAccessor world, BlockPos pos, int slotid) {
				if (world instanceof ILevelExtension _ext) {
					IItemHandler _itemHandler = _ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
					if (_itemHandler != null)
						return _itemHandler.getStackInSlot(slotid).getCount();
				}
				return 0;
			}
		}.getAmount(world, BlockPos.containing(x, y, z), 0) == 0) {
			if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
				ItemStack _setstack = new ItemStack(Items.APPLE).copy();
				_setstack.setCount(1);
				_itemHandlerModifiable.setStackInSlot(0, _setstack);
			}
		}
		if (((world instanceof Level _lvl3 && _lvl3.getServer() != null
				&& _lvl3.getServer().getAdvancements().get(new ResourceLocation("test:test_advancement")).value().equals(advancement)) != (dimension == ResourceKey.create(Registries.DIMENSION, new ResourceLocation("test:test_dimension")))) == (entity
						.getDisplayName().getString()).equals(entity.getPersistentData().getString("name"))) {
			entity.clearFire();
		}
		if (false ^ entity instanceof AgeableMob) {
			sourceentity.startRiding(entity);
			if (!immediatesourceentity.level().isClientSide())
				immediatesourceentity.discard();
			if (entity.isVehicle()) {
				for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
					if (!(entityiterator == sourceentity)) {
						entityiterator.clearFire();
					}
				}
			}
		} else {
			if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandler) {
				for (int _idx = 0; _idx < _modHandler.getSlots(); _idx++) {
					ItemStack itemstackiterator = _modHandler.getStackInSlot(_idx).copy();
					if (itemstackiterator.getItem() == ItemStack.EMPTY.getItem()) {
						continue;
					} else if (itemstackiterator.getItem() == itemstack.getItem()) {
						while (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(itemstackiterator) : false) {
							if (entity instanceof Player _player) {
								ItemStack _stktoremove = itemstackiterator;
								_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
							}
						}
					} else {
						{
							ItemStack _ist = itemstack;
							if (_ist.hurt(1, RandomSource.create(), null)) {
								_ist.shrink(1);
								_ist.setDamageValue(0);
							}
						}
					}
				}
			}
		}
		if (direction.getAxis() == Direction.Axis.Y) {
			for (Direction directioniterator : Direction.values()) {
				for (int index1 = 0; index1 < 1; index1++) {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate == Blocks.PISTON.defaultBlockState()) {
						{
							Direction _dir = (directioniterator.getClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x + direction.getStepX(), y + direction.getStepY(), z + direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
							if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else {
								_property = _bs.getBlock().getStateDefinition().getProperty("axis");
								if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
									world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				}
			}
			for (Direction directioniterator : Direction.Plane.HORIZONTAL) {
				TestMod.queueServerWork(20, () -> {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate.getBlock() == Blocks.OBSIDIAN) {
						{
							Direction _dir = (directioniterator.getCounterClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x - direction.getStepX(), y - direction.getStepY(), z - direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
							if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else {
								_property = _bs.getBlock().getStateDefinition().getProperty("axis");
								if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
									world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				});
			}
		}
		return (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.CHEST ? InteractionResult.SUCCESS : InteractionResult.PASS;
	}
}
