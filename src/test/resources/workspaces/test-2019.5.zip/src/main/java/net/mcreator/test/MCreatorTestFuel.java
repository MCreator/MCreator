package net.mcreator.test;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.item.ItemStack;
import net.minecraft.block.Blocks;

@Elementstest.ModElement.Tag
public class MCreatorTestFuel extends Elementstest.ModElement {
	public MCreatorTestFuel(Elementstest instance) {
		super(instance, 11);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@SubscribeEvent
	public void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == new ItemStack(Blocks.REDSTONE_BLOCK, (int) (1)).getItem())
			event.setBurnTime(1600);
	}
}
