package net.mcreator.test;

import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.advancements.criterion.CriterionInstance;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.CriteriaTriggers;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;

import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializationContext;
import com.google.common.collect.Sets;

@Elementstest.ModElement.Tag
public class MCreatorTestAdvancement extends Elementstest.ModElement {
	public static final CustomAdvancementTrigger trigger = new CustomAdvancementTrigger();

	public MCreatorTestAdvancement(Elementstest instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		CriteriaTriggers.register(trigger);
	}

	public static class CustomAdvancementTrigger implements ICriterionTrigger {
		private final Map<PlayerAdvancements, CustomAdvancementTrigger.Listeners> listeners = new HashMap<>();

		@Override
		public void addListener(PlayerAdvancements playerAdvancementsIn, ICriterionTrigger.Listener listener) {
			CustomAdvancementTrigger.Listeners listeners = this.listeners.get(playerAdvancementsIn);
			if (listeners == null) {
				listeners = new CustomAdvancementTrigger.Listeners(playerAdvancementsIn);
				this.listeners.put(playerAdvancementsIn, listeners);
			}
			listeners.add(listener);
		}

		@Override
		public void removeListener(PlayerAdvancements playerAdvancementsIn, ICriterionTrigger.Listener listener) {
			CustomAdvancementTrigger.Listeners listeners = this.listeners.get(playerAdvancementsIn);
			if (listeners != null) {
				listeners.remove(listener);
				if (listeners.listeners.isEmpty())
					this.listeners.remove(playerAdvancementsIn);
			}
		}

		@Override
		public void removeAllListeners(PlayerAdvancements playerAdvancementsIn) {
			this.listeners.remove(playerAdvancementsIn);
		}

		@Override
		public ResourceLocation getId() {
			return new ResourceLocation("testadvancement");
		}

		@Override
		public CustomAdvancementTrigger.Instance deserializeInstance(JsonObject json, JsonDeserializationContext context) {
			return new CustomAdvancementTrigger.Instance(this.getId());
		}

		public void triggerAdvancement(ServerPlayerEntity player) {
			CustomAdvancementTrigger.Listeners listeners = this.listeners.get(player.getAdvancements());
			if (listeners != null)
				listeners.triggerAdvancement(player);
		}

		public static class Instance extends CriterionInstance {
			public Instance(ResourceLocation triggerID) {
				super(triggerID);
			}
		}

		static class Listeners {
			PlayerAdvancements playerAdvancements;
			Set<ICriterionTrigger.Listener> listeners = Sets.newHashSet();

			public Listeners(PlayerAdvancements playerAdvancementsIn) {
				this.playerAdvancements = playerAdvancementsIn;
			}

			void triggerAdvancement(ServerPlayerEntity player) {
				for (ICriterionTrigger.Listener listener1 : listeners)
					listener1.grantCriterion(playerAdvancements);
			}

			public void add(ICriterionTrigger.Listener listener) {
				this.listeners.add(listener);
			}

			public void remove(ICriterionTrigger.Listener listener) {
				this.listeners.remove(listener);
			}
		}
	}
}
