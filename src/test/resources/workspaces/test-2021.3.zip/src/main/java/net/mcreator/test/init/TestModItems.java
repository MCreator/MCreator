
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.test.item.TestToolItem;
import net.mcreator.test.item.TestTool4Item;
import net.mcreator.test.item.TestTool3Item;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestRangedItemItem;
import net.mcreator.test.item.TestMusicDiscItem;
import net.mcreator.test.item.TestItemItem;
import net.mcreator.test.item.TestFoodItem;
import net.mcreator.test.item.TestFluidItem;
import net.mcreator.test.item.TestDimensionItem;
import net.mcreator.test.item.TestArmorItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item TEST_ARMOR_HELMET = register(new TestArmorItem.Helmet());
	public static final Item TEST_ARMOR_CHESTPLATE = register(new TestArmorItem.Chestplate());
	public static final Item TEST_ARMOR_LEGGINGS = register(new TestArmorItem.Leggings());
	public static final Item TEST_ARMOR_BOOTS = register(new TestArmorItem.Boots());
	public static final Item TEST_BLOCK = register(TestModBlocks.TEST_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item TEST_DIMENSION = register(new TestDimensionItem());
	public static final Item TEST_FLUID_BUCKET = register(new TestFluidItem());
	public static final Item TEST_FOOD = register(new TestFoodItem());
	public static final Item TEST_ITEM = register(new TestItemItem());
	public static final Item TEST_LIVING_ENTITY = register(
			new SpawnEggItem(TestModEntities.TEST_LIVING_ENTITY, -13369396, -52378, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("test_living_entity_spawn_egg"));
	public static final Item TEST_PLANT = register(TestModBlocks.TEST_PLANT, CreativeModeTab.TAB_DECORATIONS);
	public static final Item TEST_RANGED_ITEM = register(new TestRangedItemItem());
	public static final Item TEST_TOOL = register(new TestToolItem());
	public static final Item TEST_TOOL_2 = register(new TestTool2Item());
	public static final Item TEST_TOOL_3 = register(new TestTool3Item());
	public static final Item TEST_TOOL_4 = register(new TestTool4Item());
	public static final Item TEST_MUSIC_DISC = register(new TestMusicDiscItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
