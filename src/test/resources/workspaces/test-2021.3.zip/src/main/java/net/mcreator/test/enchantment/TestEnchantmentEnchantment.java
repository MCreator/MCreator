
package net.mcreator.test.enchantment;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.test.init.TestModItems;
import net.mcreator.test.init.TestModBlocks;

public class TestEnchantmentEnchantment extends Enchantment {
	public TestEnchantmentEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public int getMinLevel() {
		return 3;
	}

	@Override
	public int getMaxLevel() {
		return 3;
	}

	@Override
	public int getDamageProtection(int level, DamageSource source) {
		return level * 2;
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		if (ench == Enchantments.FIRE_PROTECTION)
			return true;
		if (ench == Enchantments.FALL_PROTECTION)
			return true;
		if (ench == Enchantments.BLAST_PROTECTION)
			return true;
		if (ench == Enchantments.PROJECTILE_PROTECTION)
			return true;
		if (ench == Enchantments.RESPIRATION)
			return true;
		return false;
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack stack) {
		if (stack.getItem() == TestModItems.TEST_ARMOR_HELMET)
			return true;
		if (stack.getItem() == TestModItems.TEST_ARMOR_CHESTPLATE)
			return true;
		if (stack.getItem() == TestModItems.TEST_ARMOR_LEGGINGS)
			return true;
		if (stack.getItem() == TestModItems.TEST_ARMOR_BOOTS)
			return true;
		if (stack.getItem() == TestModBlocks.TEST_BLOCK.asItem())
			return true;
		if (stack.getItem() == TestModItems.TEST_DIMENSION)
			return true;
		if (stack.getItem() == TestModBlocks.TEST_FLUID.asItem())
			return true;
		if (stack.getItem() == TestModItems.TEST_FOOD)
			return true;
		if (stack.getItem() == TestModItems.TEST_ITEM)
			return true;
		if (stack.getItem() == TestModBlocks.TEST_PLANT.asItem())
			return true;
		if (stack.getItem() == TestModItems.TEST_RANGED_ITEM)
			return true;
		if (stack.getItem() == TestModItems.TEST_TOOL)
			return true;
		if (stack.getItem() == TestModItems.TEST_TOOL_2)
			return true;
		if (stack.getItem() == TestModItems.TEST_TOOL_3)
			return true;
		if (stack.getItem() == TestModItems.TEST_TOOL_4)
			return true;
		if (stack.getItem() == TestModItems.TEST_MUSIC_DISC)
			return true;
		if (stack.getItem() == Blocks.AIR.asItem())
			return true;
		if (stack.getItem() == Blocks.VOID_AIR.asItem())
			return true;
		if (stack.getItem() == Blocks.CAVE_AIR.asItem())
			return true;
		if (stack.getItem() == Blocks.STONE.asItem())
			return true;
		if (stack.getItem() == Blocks.STONE_STAIRS.asItem())
			return true;
		if (stack.getItem() == Blocks.STONE_SLAB.asItem())
			return true;
		if (stack.getItem() == Blocks.GRANITE.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_GRANITE.asItem())
			return true;
		if (stack.getItem() == Blocks.GRANITE_STAIRS.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_GRANITE_STAIRS.asItem())
			return true;
		if (stack.getItem() == Blocks.GRANITE_SLAB.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_GRANITE_SLAB.asItem())
			return true;
		if (stack.getItem() == Blocks.GRANITE_WALL.asItem())
			return true;
		if (stack.getItem() == Blocks.DIORITE.asItem())
			return true;
		if (stack.getItem() == Blocks.DIORITE_STAIRS.asItem())
			return true;
		if (stack.getItem() == Blocks.DIORITE_SLAB.asItem())
			return true;
		if (stack.getItem() == Blocks.DIORITE_WALL.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_DIORITE.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_DIORITE_SLAB.asItem())
			return true;
		if (stack.getItem() == Blocks.POLISHED_DIORITE_STAIRS.asItem())
			return true;
		return false;
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}

	@Override
	public boolean isCurse() {
		return true;
	}
}
