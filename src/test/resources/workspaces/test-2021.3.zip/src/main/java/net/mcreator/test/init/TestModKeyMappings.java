
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fmlclient.registry.ClientRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.test.network.TestKeyBindingMessage;
import net.mcreator.test.TestMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class TestModKeyMappings {
	public static final KeyMapping TEST_KEY_BINDING = new KeyMapping("key.test.test_key_binding", GLFW.GLFW_KEY_O, "key.categories.misc");
	private static long TEST_KEY_BINDING_LASTPRESS = 0;

	@SubscribeEvent
	public static void registerKeyBindings(FMLClientSetupEvent event) {
		ClientRegistry.registerKeyBinding(TEST_KEY_BINDING);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onKeyInput(InputEvent.KeyInputEvent event) {
			if (Minecraft.getInstance().screen == null) {
				if (event.getKey() == TEST_KEY_BINDING.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						TestMod.PACKET_HANDLER.sendToServer(new TestKeyBindingMessage(0, 0));
						TestKeyBindingMessage.pressAction(Minecraft.getInstance().player, 0, 0);
						TEST_KEY_BINDING_LASTPRESS = System.currentTimeMillis();
					} else if (event.getAction() == GLFW.GLFW_RELEASE) {
						int dt = (int) (System.currentTimeMillis() - TEST_KEY_BINDING_LASTPRESS);
						TestMod.PACKET_HANDLER.sendToServer(new TestKeyBindingMessage(1, dt));
						TestKeyBindingMessage.pressAction(Minecraft.getInstance().player, 1, dt);
					}
				}
			}
		}
	}
}
