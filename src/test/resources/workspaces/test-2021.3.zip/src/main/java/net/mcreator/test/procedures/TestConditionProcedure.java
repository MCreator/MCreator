package net.mcreator.test.procedures;

public class TestConditionProcedure {
	public static boolean execute() {
		return true;
	}
}
