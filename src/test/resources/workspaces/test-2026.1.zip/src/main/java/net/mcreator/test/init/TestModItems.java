/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.neoforge.client.event.RegisterConditionalItemModelPropertyEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.client.multiplayer.ClientLevel;

import net.mcreator.test.item.inventory.TestMusicDiscInventoryCapability;
import net.mcreator.test.item.inventory.TestItemInventoryCapability;
import net.mcreator.test.item.*;
import net.mcreator.test.block.TestBlockBlock;
import net.mcreator.test.TestMod;

import javax.annotation.Nullable;

import java.util.function.Function;

import com.mojang.serialization.MapCodec;

@EventBusSubscriber
public class TestModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TestMod.MODID);
	public static final DeferredItem<Item> TEST_ARMOR_HELMET;
	public static final DeferredItem<Item> TEST_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> TEST_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> TEST_ARMOR_BOOTS;
	public static final DeferredItem<Item> TEST_BLOCK;
	public static final DeferredItem<Item> TEST_DIMENSION;
	public static final DeferredItem<Item> TEST_FOOD;
	public static final DeferredItem<Item> TEST_FLUID_BUCKET;
	public static final DeferredItem<Item> TEST_ITEM;
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_SPAWN_EGG;
	public static final DeferredItem<Item> TEST_PLANT;
	public static final DeferredItem<Item> TEST_TOOL;
	public static final DeferredItem<Item> TEST_TOOL_2;
	public static final DeferredItem<Item> TEST_TOOL_3;
	public static final DeferredItem<Item> TEST_TOOL_4;
	public static final DeferredItem<Item> TEST_PLANT_2;
	public static final DeferredItem<Item> NO_GEN_BLOCK;
	public static final DeferredItem<Item> ORE_BLOCK_2;
	public static final DeferredItem<Item> ORE_BLOCK_3;
	public static final DeferredItem<Item> TEST_RANGED_ITEM;
	public static final DeferredItem<Item> TEST_TOOL_SHIELD;
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_2_SPAWN_EGG;
	public static final DeferredItem<Item> TEST_RANGED_ITEM_2;
	public static final DeferredItem<Item> TEST_ITEM_STATES;
	public static final DeferredItem<Item> TEST_MUSIC_DISC;
	public static final DeferredItem<Item> TEST_ENTITY_2_SPAWN_EGG;
	public static final DeferredItem<Item> TEST_PLANT_4;
	public static final DeferredItem<Item> ANIMATED_BLOCK;
	public static final DeferredItem<Item> BOAT_ONE;
	public static final DeferredItem<Item> BOAT_TWO;
	public static final DeferredItem<Item> NORMAL_SIGN;
	public static final DeferredItem<Item> CUSTOM_HANGING_SIGN;
	public static final DeferredItem<Item> LEAVES_BLOCK;
	static {
		TEST_ARMOR_HELMET = register("test_armor_helmet", TestArmorItem.Helmet::new);
		TEST_ARMOR_CHESTPLATE = register("test_armor_chestplate", TestArmorItem.Chestplate::new);
		TEST_ARMOR_LEGGINGS = register("test_armor_leggings", TestArmorItem.Leggings::new);
		TEST_ARMOR_BOOTS = register("test_armor_boots", TestArmorItem.Boots::new);
		TEST_BLOCK = register("test_block", properties -> new TestBlockBlock.Item(properties.fireResistant()));
		TEST_DIMENSION = register("test_dimension", TestDimensionItem::new);
		TEST_FOOD = register("test_food", TestFoodItem::new);
		TEST_FLUID_BUCKET = register("test_fluid_bucket", TestFluidItem::new);
		TEST_ITEM = register("test_item", TestItemItem::new);
		TEST_LIVING_ENTITY_SPAWN_EGG = register("test_living_entity_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_LIVING_ENTITY.get(), properties));
		TEST_PLANT = block(TestModBlocks.TEST_PLANT);
		TEST_TOOL = register("test_tool", TestToolItem::new);
		TEST_TOOL_2 = register("test_tool_2", TestTool2Item::new);
		TEST_TOOL_3 = register("test_tool_3", TestTool3Item::new);
		TEST_TOOL_4 = register("test_tool_4", TestTool4Item::new);
		TEST_PLANT_2 = block(TestModBlocks.TEST_PLANT_2, new Item.Properties().stacksTo(98).rarity(Rarity.RARE).fireResistant());
		NO_GEN_BLOCK = block(TestModBlocks.NO_GEN_BLOCK);
		ORE_BLOCK_2 = block(TestModBlocks.ORE_BLOCK_2);
		ORE_BLOCK_3 = block(TestModBlocks.ORE_BLOCK_3);
		TEST_RANGED_ITEM = register("test_ranged_item", TestRangedItemItem::new);
		TEST_TOOL_SHIELD = register("test_tool_shield", TestToolShieldItem::new);
		TEST_LIVING_ENTITY_2_SPAWN_EGG = register("test_living_entity_2_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_LIVING_ENTITY_2.get(), properties));
		TEST_RANGED_ITEM_2 = register("test_ranged_item_2", TestRangedItem2Item::new);
		TEST_ITEM_STATES = register("test_item_states", TestItemStatesItem::new);
		TEST_MUSIC_DISC = register("test_music_disc", TestMusicDiscItem::new);
		TEST_ENTITY_2_SPAWN_EGG = register("test_entity_2_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_ENTITY_2.get(), properties));
		TEST_PLANT_4 = block(TestModBlocks.TEST_PLANT_4);
		ANIMATED_BLOCK = block(TestModBlocks.ANIMATED_BLOCK);
		BOAT_ONE = register("boat_one", properties -> new BoatItem(TestModEntities.BOAT_ONE.get(), properties.stacksTo(1)));
		BOAT_TWO = register("boat_two", properties -> new BoatItem(TestModEntities.BOAT_TWO.get(), properties.stacksTo(1)));
		NORMAL_SIGN = signBlock(TestModBlocks.NORMAL_SIGN, TestModBlocks.NORMAL_WALL_SIGN, new Item.Properties().stacksTo(16));
		CUSTOM_HANGING_SIGN = hangingSignBlock(TestModBlocks.CUSTOM_HANGING_SIGN, TestModBlocks.CUSTOM_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		LEAVES_BLOCK = block(TestModBlocks.LEAVES_BLOCK);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return signBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new SignItem(block.get(), wallBlock.get(), prop), properties);
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return hangingSignBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new HangingSignItem(block.get(), wallBlock.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new TestItemInventoryCapability(stack), TEST_ITEM.get());
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new TestMusicDiscInventoryCapability(stack), TEST_MUSIC_DISC.get());
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), TEST_FLUID_BUCKET.get());
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		public static void registerItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("test:test_ranged_item/property1"), TestRangedItemItem.Property1Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item/property2"), TestRangedItemItem.Property2Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item_2/property1"), TestRangedItem2Item.Property1Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item_2/property2"), TestRangedItem2Item.Property2Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_item_states/test"), TestItemStatesItem.TestProperty.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_item_states/test2"), TestItemStatesItem.Test2Property.MAP_CODEC);
		}

		@SubscribeEvent
		public static void registerItemModelProperties(RegisterConditionalItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("test:lefthanded"), LegacyLeftHandedProperty.MAP_CODEC);
		}

		public record LegacyLeftHandedProperty() implements ConditionalItemModelProperty {
			public static final MapCodec<LegacyLeftHandedProperty> MAP_CODEC = MapCodec.unit(new LegacyLeftHandedProperty());

			@Override
			public boolean get(ItemStack itemStackToRender, @Nullable ClientLevel clientWorld, @Nullable LivingEntity entity, int seed, ItemDisplayContext displayContext) {
				return entity != null && entity.getMainArm() == HumanoidArm.LEFT;
			}

			@Override
			public MapCodec<LegacyLeftHandedProperty> type() {
				return MAP_CODEC;
			}
		}
	}
}