/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.TestMod;

@EventBusSubscriber
public class TestModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TestMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TEST_TAB_2 = REGISTRY.register("test_tab_2",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.test.test_tab_2")).icon(() -> new ItemStack(Blocks.RAW_GOLD_BLOCK)).displayItems((parameters, tabData) -> {
				tabData.accept(TestModItems.TEST_FOOD.get());
				tabData.accept(TestModItems.TEST_TOOL_SHIELD.get());
			}).withSearchBar().build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TEST_TAB = REGISTRY.register("test_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.test.test_tab")).icon(() -> new ItemStack(TestModBlocks.TEST_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TestModItems.TEST_ARMOR_HELMET.get());
				tabData.accept(TestModItems.TEST_ARMOR_CHESTPLATE.get());
				tabData.accept(TestModItems.TEST_ARMOR_LEGGINGS.get());
				tabData.accept(TestModItems.TEST_ARMOR_BOOTS.get());
				tabData.accept(TestModBlocks.TEST_BLOCK.get().asItem());
				tabData.accept(TestModBlocks.NO_GEN_BLOCK.get().asItem());
				tabData.accept(TestModBlocks.ORE_BLOCK_2.get().asItem());
				tabData.accept(TestModBlocks.ORE_BLOCK_3.get().asItem());
				tabData.accept(TestModItems.TEST_FOOD.get());
				tabData.accept(TestModItems.TEST_TOOL_SHIELD.get());
			}).withSearchBar().withTabsBefore(TEST_TAB_2.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(TestModItems.TEST_ARMOR_HELMET.get());
			tabData.accept(TestModItems.TEST_ARMOR_CHESTPLATE.get());
			tabData.accept(TestModItems.TEST_ARMOR_LEGGINGS.get());
			tabData.accept(TestModItems.TEST_ARMOR_BOOTS.get());
			tabData.accept(TestModItems.TEST_FLUID_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(TestModBlocks.TEST_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(TestModBlocks.TEST_BLOCK.get().asItem());
			tabData.accept(TestModBlocks.TEST_PLANT_2.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(TestModItems.TEST_DIMENSION.get());
			tabData.accept(TestModItems.TEST_TOOL.get());
			tabData.accept(TestModItems.TEST_TOOL_2.get());
			tabData.accept(TestModItems.TEST_TOOL_3.get());
			tabData.accept(TestModItems.TEST_TOOL_4.get());
			tabData.accept(TestModItems.TEST_TOOL_SHIELD.get());
			tabData.accept(TestModItems.TEST_RANGED_ITEM_2.get());
			tabData.accept(TestModItems.BOAT_ONE.get());
			tabData.accept(TestModItems.BOAT_TWO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(TestModItems.TEST_FOOD.get());
			tabData.accept(TestModItems.BOAT_ONE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(TestModItems.TEST_ITEM.get());
			tabData.accept(TestModItems.TEST_LIVING_ENTITY_SPAWN_EGG.get());
			tabData.accept(TestModItems.TEST_LIVING_ENTITY_2_SPAWN_EGG.get());
			tabData.accept(TestModItems.TEST_ITEM_STATES.get());
			tabData.accept(TestModItems.TEST_MUSIC_DISC.get());
			tabData.accept(TestModItems.TEST_ENTITY_2_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(TestModBlocks.TEST_PLANT.get().asItem());
			tabData.accept(TestModBlocks.TEST_PLANT_2.get().asItem());
			tabData.accept(TestModBlocks.TEST_PLANT_4.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.OP_BLOCKS) {
			if (tabData.hasPermissions()) {
				tabData.accept(TestModBlocks.ORE_BLOCK_3.get().asItem());
			}
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(TestModItems.TEST_RANGED_ITEM.get());
			tabData.accept(TestModItems.TEST_RANGED_ITEM_2.get());
		}
	}
}