/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.dispenser.BoatDispenseItemBehavior;
import net.minecraft.core.dispenser.BlockSource;

import net.mcreator.test.procedures.TestProcedureProcedure;

@EventBusSubscriber
public class TestModDispenseBehaviors {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DispenserBlock.registerBehavior(Blocks.REDSTONE_BLOCK.asItem(), new DefaultDispenseItemBehavior() {
				public ItemStack execute(BlockSource blockSource, ItemStack itemstack) {
					TestProcedureProcedure.execute(blockSource.level(), blockSource.pos().getX(), blockSource.pos().getY(), blockSource.pos().getZ());
					itemstack.shrink(1);
					return itemstack;
				}
			});
			DispenserBlock.registerBehavior(TestModItems.BOAT_ONE.get(), new BoatDispenseItemBehavior(TestModEntities.BOAT_ONE.get()));
			DispenserBlock.registerBehavior(TestModItems.BOAT_TWO.get(), new BoatDispenseItemBehavior(TestModEntities.BOAT_TWO.get()));
		});
	}
}