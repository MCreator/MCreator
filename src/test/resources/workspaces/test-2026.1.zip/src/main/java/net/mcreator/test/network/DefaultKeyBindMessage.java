package net.mcreator.test.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.SectionPos;

import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.TestMod;

@EventBusSubscriber
public record DefaultKeyBindMessage(int eventType, int pressedms) implements CustomPacketPayload {
	public static final Type<DefaultKeyBindMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(TestMod.MODID, "key_default_key_bind"));
	public static final StreamCodec<RegistryFriendlyByteBuf, DefaultKeyBindMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, DefaultKeyBindMessage message) -> {
		buffer.writeInt(message.eventType);
		buffer.writeInt(message.pressedms);
	}, (RegistryFriendlyByteBuf buffer) -> new DefaultKeyBindMessage(buffer.readInt(), buffer.readInt()));

	@Override
	public Type<DefaultKeyBindMessage> type() {
		return TYPE;
	}

	public static void handleData(final DefaultKeyBindMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				pressAction(context.player(), message.eventType, message.pressedms);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void pressAction(Player entity, int type, int pressedms) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		// security measure to prevent arbitrary chunk generation
		if (!world.getChunkSource().hasChunk(SectionPos.blockToSectionCoord(x), SectionPos.blockToSectionCoord(z)))
			return;
		if (type == 1) {

			TestProcedureProcedure.execute(world, x, y, z);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		TestMod.addNetworkMessage(DefaultKeyBindMessage.TYPE, DefaultKeyBindMessage.STREAM_CODEC, DefaultKeyBindMessage::handleData);
	}
}