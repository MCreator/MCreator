package net.mcreator.test.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import net.mcreator.test.init.TestModWoodTypes;
import net.mcreator.test.init.TestModBlocks;

public class NormalWallSignBlock extends WallSignBlock {
	public NormalWallSignBlock(BlockBehaviour.Properties properties) {
		super(TestModWoodTypes.NORMAL_SIGN_WOOD_TYPE, properties.sound(SoundType.GRAVEL).strength(1f, 10f).noCollission().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn().overrideLootTable(TestModBlocks.NORMAL_SIGN.get().getLootTable())
				.overrideDescription(TestModBlocks.NORMAL_SIGN.get().getDescriptionId()));
	}
}