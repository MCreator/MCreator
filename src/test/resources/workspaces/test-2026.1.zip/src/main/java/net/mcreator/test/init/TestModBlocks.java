/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.event.BlockEntityTypeAddBlocksEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.client.renderer.Sheets;

import net.mcreator.test.block.*;
import net.mcreator.test.TestMod;

import java.util.function.Function;

@EventBusSubscriber
public class TestModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(TestMod.MODID);
	public static final DeferredBlock<Block> TEST_BLOCK;
	public static final DeferredBlock<Block> TEST_DIMENSION_PORTAL;
	public static final DeferredBlock<Block> TEST_FLUID;
	public static final DeferredBlock<Block> TEST_PLANT;
	public static final DeferredBlock<Block> TEST_PLANT_2;
	public static final DeferredBlock<Block> TEST_PLANT_3;
	public static final DeferredBlock<Block> NO_GEN_BLOCK;
	public static final DeferredBlock<Block> ORE_BLOCK_2;
	public static final DeferredBlock<Block> ORE_BLOCK_3;
	public static final DeferredBlock<Block> TEST_PLANT_4;
	public static final DeferredBlock<Block> ANIMATED_BLOCK;
	public static final DeferredBlock<Block> INVENTORY_BLOCK;
	public static final DeferredBlock<Block> CUSTOM_FLOWER_POT;
	public static final DeferredBlock<Block> NORMAL_SIGN;
	public static final DeferredBlock<Block> NORMAL_WALL_SIGN;
	public static final DeferredBlock<Block> CUSTOM_HANGING_SIGN;
	public static final DeferredBlock<Block> CUSTOM_WALL_HANGING_SIGN;
	public static final DeferredBlock<Block> LEAVES_BLOCK;
	static {
		TEST_BLOCK = register("test_block", TestBlockBlock::new);
		TEST_DIMENSION_PORTAL = register("test_dimension_portal", TestDimensionPortalBlock::new);
		TEST_FLUID = register("test_fluid", TestFluidBlock::new);
		TEST_PLANT = register("test_plant", TestPlantBlock::new);
		TEST_PLANT_2 = register("test_plant_2", TestPlant2Block::new);
		TEST_PLANT_3 = register("test_plant_3", TestPlant3Block::new);
		NO_GEN_BLOCK = register("no_gen_block", NoGenBlockBlock::new);
		ORE_BLOCK_2 = register("ore_block_2", OreBlock2Block::new);
		ORE_BLOCK_3 = register("ore_block_3", OreBlock3Block::new);
		TEST_PLANT_4 = register("test_plant_4", TestPlant4Block::new);
		ANIMATED_BLOCK = register("animated_block", AnimatedBlockBlock::new);
		INVENTORY_BLOCK = register("inventory_block", InventoryBlockBlock::new);
		CUSTOM_FLOWER_POT = register("custom_flower_pot", CustomFlowerPotBlock::new);
		NORMAL_SIGN = register("normal_sign", NormalSignBlock::new);
		NORMAL_WALL_SIGN = register("normal_wall_sign", NormalWallSignBlock::new);
		CUSTOM_HANGING_SIGN = register("custom_hanging_sign", CustomHangingSignBlock::new);
		CUSTOM_WALL_HANGING_SIGN = register("custom_wall_hanging_sign", CustomWallHangingSignBlock::new);
		LEAVES_BLOCK = register("leaves_block", LeavesBlockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			TestPlant3Block.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			Sheets.addWoodType(TestModWoodTypes.NORMAL_SIGN_WOOD_TYPE);
			Sheets.addWoodType(TestModWoodTypes.CUSTOM_HANGING_SIGN_WOOD_TYPE);
		}
	}

	@SubscribeEvent
	public static void registerSigns(BlockEntityTypeAddBlocksEvent event) {
		event.modify(BlockEntityType.SIGN, NORMAL_SIGN.get(), NORMAL_WALL_SIGN.get());
		event.modify(BlockEntityType.HANGING_SIGN, CUSTOM_HANGING_SIGN.get(), CUSTOM_WALL_HANGING_SIGN.get());
	}
}