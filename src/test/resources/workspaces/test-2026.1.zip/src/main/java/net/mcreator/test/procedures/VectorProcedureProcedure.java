package net.mcreator.test.procedures;

import net.minecraft.world.phys.Vec3;

public class VectorProcedureProcedure {
	public static Vec3 execute(double x, double y, double z) {
		return (new Vec3(x, y, z)).normalize();
	}
}