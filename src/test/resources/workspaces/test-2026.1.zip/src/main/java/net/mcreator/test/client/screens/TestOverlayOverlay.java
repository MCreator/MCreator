package net.mcreator.test.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.test.procedures.TextProcedureProcedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.procedures.EntityProviderProcedure;

@EventBusSubscriber(Dist.CLIENT)
public class TestOverlayOverlay {
	private static final ResourceLocation IMAGE_0 = ResourceLocation.parse("test:textures/screens/block.png");

	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getGuiGraphics().guiWidth();
		int h = event.getGuiGraphics().guiHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (true) {
			if (LogicProcedureProcedure.execute()) {
				event.getGuiGraphics().blit(RenderPipelines.GUI_TEXTURED, IMAGE_0, w - 268, 173, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_label_text"), 31, 22, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					TextProcedureProcedure.execute(), w / 2 + -34, h / 2 + -97, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_empty"), w / 2 + -5, 54, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.test.test_overlay.label_bottom_corner"), w - 90, h - 25, -1, false);
			if (LogicProcedureProcedure.execute())
				event.getGuiGraphics().drawString(Minecraft.getInstance().font,

						TextProcedureProcedure.execute(), 30, h / 2 + -7, -16738048, false);
			if (EntityProviderProcedure.execute(entity) instanceof LivingEntity livingEntity) {
				if (LogicProcedureProcedure.execute())
					InventoryScreen.renderEntityInInventoryFollowsAngle(event.getGuiGraphics(), w - 1056, -960, w - -944, 1040, 30, -livingEntity.getBbHeight() / (2.0f * livingEntity.getScale()), 0f, 0, livingEntity);
			}
		}
	}
}