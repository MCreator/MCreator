/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.BoatModel;

import net.mcreator.test.client.model.ModelKreper117;

@EventBusSubscriber(Dist.CLIENT)
public class TestModModels {
	public static final ModelLayerLocation BOAT_ONE_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("test:boat/boat_one"), "main");
	public static final ModelLayerLocation BOAT_TWO_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("test:boat/boat_two"), "main");

	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelKreper117.LAYER_LOCATION, ModelKreper117::createBodyLayer);
		event.registerLayerDefinition(BOAT_ONE_LAYER_LOCATION, BoatModel::createBoatModel);
		event.registerLayerDefinition(BOAT_TWO_LAYER_LOCATION, BoatModel::createBoatModel);
	}
}