/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.potion.TestPotionMobEffect;
import net.mcreator.test.potion.TestEffectMobEffect;
import net.mcreator.test.TestMod;

@EventBusSubscriber
public class TestModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, TestMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> TEST_POTION = REGISTRY.register("test_potion", () -> new TestPotionMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> TEST_EFFECT = REGISTRY.register("test_effect", () -> new TestEffectMobEffect());

	@SubscribeEvent
	public static void onEffectRemoved(MobEffectEvent.Remove event) {
		MobEffectInstance effectInstance = event.getEffectInstance();
		if (effectInstance != null) {
			expireEffects(event.getEntity(), effectInstance);
		}
	}

	@SubscribeEvent
	public static void onEffectExpired(MobEffectEvent.Expired event) {
		MobEffectInstance effectInstance = event.getEffectInstance();
		if (effectInstance != null) {
			expireEffects(event.getEntity(), effectInstance);
		}
	}

	private static void expireEffects(Entity entity, MobEffectInstance effectInstance) {
		if (effectInstance.getEffect().is(TEST_POTION)) {
			TestProcedureProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
		}
	}
}