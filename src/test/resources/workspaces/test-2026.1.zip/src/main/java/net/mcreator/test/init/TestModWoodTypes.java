/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.state.properties.BlockSetType;

public class TestModWoodTypes {
	public static final WoodType NORMAL_SIGN_WOOD_TYPE = WoodType.register(new WoodType("test:normal_sign", BlockSetType.OAK));
	public static final WoodType CUSTOM_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("test:custom_hanging_sign", BlockSetType.OAK));
}