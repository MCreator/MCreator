/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.test.client.particle.TestParticleParticle;
import net.mcreator.test.client.particle.TestParticle2Particle;

@EventBusSubscriber(Dist.CLIENT)
public class TestModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(TestModParticleTypes.TEST_PARTICLE.get(), TestParticleParticle::provider);
		event.registerSpriteSet(TestModParticleTypes.TEST_PARTICLE_2.get(), TestParticle2Particle::provider);
	}
}