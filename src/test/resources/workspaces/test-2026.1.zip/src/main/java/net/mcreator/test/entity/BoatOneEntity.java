package net.mcreator.test.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.EntityType;

import net.mcreator.test.init.TestModItems;

public class BoatOneEntity extends Boat {
	public BoatOneEntity(EntityType<BoatOneEntity> type, Level world) {
		super(type, world, TestModItems.BOAT_ONE);
	}
}