/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.entity.*;
import net.mcreator.test.TestMod;

@EventBusSubscriber
public class TestModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, TestMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<TestLivingEntityEntity>> TEST_LIVING_ENTITY = register("test_living_entity",
			EntityType.Builder.<TestLivingEntityEntity>of(TestLivingEntityEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().ridingOffset(-0.6f).sized(0.6f, 2f));
	public static final DeferredHolder<EntityType<?>, EntityType<TestLivingEntityEntityProjectile>> TEST_LIVING_ENTITY_PROJECTILE = register("projectile_test_living_entity",
			EntityType.Builder.<TestLivingEntityEntityProjectile>of(TestLivingEntityEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<TestRangedItemProjectileEntity>> TEST_RANGED_ITEM_PROJECTILE = register("test_ranged_item_projectile",
			EntityType.Builder.<TestRangedItemProjectileEntity>of(TestRangedItemProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.8f, 1.4f));
	public static final DeferredHolder<EntityType<?>, EntityType<TestLivingEntity2Entity>> TEST_LIVING_ENTITY_2 = register("test_living_entity_2",
			EntityType.Builder.<TestLivingEntity2Entity>of(TestLivingEntity2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<TestEntity2Entity>> TEST_ENTITY_2 = register("test_entity_2",
			EntityType.Builder.<TestEntity2Entity>of(TestEntity2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<ProjectileTwoEntity>> PROJECTILE_TWO = register("projectile_two",
			EntityType.Builder.<ProjectileTwoEntity>of(ProjectileTwoEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<BoatOneEntity>> BOAT_ONE = register("boat_one",
			EntityType.Builder.<BoatOneEntity>of(BoatOneEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));
	public static final DeferredHolder<EntityType<?>, EntityType<BoatTwoEntity>> BOAT_TWO = register("boat_two",
			EntityType.Builder.<BoatTwoEntity>of(BoatTwoEntity::new, MobCategory.MISC).noLootTable().sized(1.375F, 0.5625F).eyeHeight(0.5625F).clientTrackingRange(10));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(TestMod.MODID, registryname))));
	}

	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerEntity(Capabilities.ItemHandler.ENTITY, TEST_LIVING_ENTITY.get(), (living, context) -> living.getCombinedInventory());
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		TestLivingEntityEntity.init(event);
		TestLivingEntity2Entity.init(event);
		TestEntity2Entity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(TEST_LIVING_ENTITY.get(), TestLivingEntityEntity.createAttributes().build());
		event.put(TEST_LIVING_ENTITY_2.get(), TestLivingEntity2Entity.createAttributes().build());
		event.put(TEST_ENTITY_2.get(), TestEntity2Entity.createAttributes().build());
	}
}