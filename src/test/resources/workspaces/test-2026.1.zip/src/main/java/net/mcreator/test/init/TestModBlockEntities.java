/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.test.block.entity.*;
import net.mcreator.test.TestMod;

@EventBusSubscriber
public class TestModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, TestMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TestBlockBlockEntity>> TEST_BLOCK = register("test_block", TestModBlocks.TEST_BLOCK, TestBlockBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TestPlant2BlockEntity>> TEST_PLANT_2 = register("test_plant_2", TestModBlocks.TEST_PLANT_2, TestPlant2BlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TestPlant3BlockEntity>> TEST_PLANT_3 = register("test_plant_3", TestModBlocks.TEST_PLANT_3, TestPlant3BlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<OreBlock3BlockEntity>> ORE_BLOCK_3 = register("ore_block_3", TestModBlocks.ORE_BLOCK_3, OreBlock3BlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnimatedBlockBlockEntity>> ANIMATED_BLOCK = register("animated_block", TestModBlocks.ANIMATED_BLOCK, AnimatedBlockBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<InventoryBlockBlockEntity>> INVENTORY_BLOCK = register("inventory_block", TestModBlocks.INVENTORY_BLOCK, InventoryBlockBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CustomFlowerPotBlockEntity>> CUSTOM_FLOWER_POT = register("custom_flower_pot", TestModBlocks.CUSTOM_FLOWER_POT, CustomFlowerPotBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> new BlockEntityType(supplier, block.get()));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, TEST_BLOCK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, TEST_BLOCK.get(), (blockEntity, side) -> blockEntity.getEnergyStorage());
		event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, TEST_BLOCK.get(), (blockEntity, side) -> blockEntity.getFluidTank());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ORE_BLOCK_3.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ANIMATED_BLOCK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, INVENTORY_BLOCK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CUSTOM_FLOWER_POT.get(), SidedInvWrapper::new);
	}
}