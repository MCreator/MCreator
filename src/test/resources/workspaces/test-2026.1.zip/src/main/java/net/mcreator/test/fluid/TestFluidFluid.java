package net.mcreator.test.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.init.TestModItems;
import net.mcreator.test.init.TestModFluids;
import net.mcreator.test.init.TestModFluidTypes;
import net.mcreator.test.init.TestModBlocks;

public abstract class TestFluidFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TestModFluidTypes.TEST_FLUID_TYPE.get(), () -> TestModFluids.TEST_FLUID.get(), () -> TestModFluids.FLOWING_TEST_FLUID.get())
			.explosionResistance(100f).bucket(() -> TestModItems.TEST_FLUID_BUCKET.get()).block(() -> (LiquidBlock) TestModBlocks.TEST_FLUID.get());

	private TestFluidFluid() {
		super(PROPERTIES);
	}

	@Override
	protected void beforeDestroyingBlock(LevelAccessor world, BlockPos pos, BlockState blockstate) {
		TestProcedureProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	public static class Source extends TestFluidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends TestFluidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}