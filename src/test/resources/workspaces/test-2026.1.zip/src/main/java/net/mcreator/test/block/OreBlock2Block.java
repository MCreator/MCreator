package net.mcreator.test.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.test.procedures.NumberProvider2Procedure;

import java.util.function.Function;

public class OreBlock2Block extends Block {
	public static final BooleanProperty DEMO = BooleanProperty.create("demo");
	public static final IntegerProperty EHRL = IntegerProperty.create("ehrl", 0, 6);
	public static final BooleanProperty INVERTED = BlockStateProperties.INVERTED;
	public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.AXIS;
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public OreBlock2Block(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(1f, 10f).lightLevel(blockstate -> (int) NumberProvider2Procedure.execute()).instrument(NoteBlockInstrument.BASEDRUM));
		this.registerDefaultState(this.stateDefinition.any().setValue(DEMO, true).setValue(EHRL, 0).setValue(INVERTED, false).setValue(AXIS, AXIS.getValue("y").get()));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			if (state.getValue(DEMO) == true && state.getValue(EHRL) == 0) {
				return Shapes.or(box(0, 3, 0, 16, 5, 16), box(0, 0, 0, 5, 16, 16));
			}
			return box(0, 0, 0, 16, 16, 16);
		}, INVERTED, AXIS);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(DEMO, EHRL, INVERTED, AXIS);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(DEMO, true).setValue(EHRL, 0).setValue(INVERTED, false).setValue(AXIS, AXIS.getValue("y").get());
	}
}