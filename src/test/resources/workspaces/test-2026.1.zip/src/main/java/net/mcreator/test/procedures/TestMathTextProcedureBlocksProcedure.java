package net.mcreator.test.procedures;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.event.entity.player.BonemealEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.mcreator.test.TestMod;

import javax.annotation.Nullable;

import java.util.Calendar;

@EventBusSubscriber
public class TestMathTextProcedureBlocksProcedure {
	@SubscribeEvent
	public static void onBonemeal(BonemealEvent event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getPlayer());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		String dateTime = "";
		/* test procedure entry point */
		dateTime = Calendar.getInstance().get(Calendar.YEAR) + "." + (Calendar.getInstance().get(Calendar.MONTH) + 1) + "." + Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + " (" + Calendar.getInstance().get(Calendar.WEEK_OF_YEAR) + "-"
				+ Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + "), " + Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + ":" + Calendar.getInstance().get(Calendar.MINUTE) + ":" + Calendar.getInstance().get(Calendar.SECOND);
		TestMod.LOGGER.info(Calendar.getInstance().getTime().toString());
		TestMod.LOGGER.info(dateTime);
		if (!(dateTime).equals(null) && (dateTime).isEmpty() && (dateTime).length() != 0) {
			if ((dateTime).equals(new java.text.SimpleDateFormat("yyyy.MM.dd (ww-E), HH:mm:SS").format(Calendar.getInstance().getTime()))) {
				TestMod.LOGGER.info("Checksum: " + (Math.round(Math.random()) == 0 ? Mth.nextInt(RandomSource.create(), 0, 9) : Mth.nextDouble(RandomSource.create(), 0, 9) + 1));
			}
			if (dateTime.contains(" ") || dateTime.startsWith(" ") || dateTime.endsWith(" ")) {
				TestMod.LOGGER.info((dateTime.replace(" ", "")).substring((dateTime).length() - 8, (dateTime).length() - 3));
			}
			if (((dateTime).toUpperCase()).equals((dateTime).toLowerCase())) {
				TestMod.LOGGER.info(parseDouble((new java.text.DecimalFormat("####").format(Calendar.getInstance().get(Calendar.SECOND))).strip()));
			}
		}
		TestMod.LOGGER.debug((Component.translatable("key.mcreator.testkeybinding").getString()));
		if (entity instanceof Player) {
			TestProcedureProcedure.execute(world, x, y, z);
			if (event instanceof BonemealEvent _event)
				_event.setCanceled(false);
		} else if (!(entity == null)) {
			TestProcedureProcedure.execute(world, x, y, z);
			if (event instanceof ICancellableEvent _cancellable) {
				_cancellable.setCanceled(true);
			}
		}
	}

	private static double parseDouble(String s) {
		try {
			return Double.parseDouble(s.trim());
		} catch (Exception e) {
			return 0;
		}
	}
}