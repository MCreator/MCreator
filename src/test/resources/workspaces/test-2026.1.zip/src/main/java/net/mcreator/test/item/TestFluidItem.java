package net.mcreator.test.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.test.init.TestModFluids;

public class TestFluidItem extends BucketItem {
	public TestFluidItem(Item.Properties properties) {
		super(TestModFluids.TEST_FLUID.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}