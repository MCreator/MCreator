import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";


const ItemScript = {
	onHitEntity(event) {

		const entity = event.hitEntity;
		let _stack0 = new ItemStack("minecraft:mud_bricks");
		_stack0.amount = 1;
		entity.getComponent("minecraft:inventory")?.container?.addItem(_stack0);
	}
};

system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
	itemComponentRegistry.registerCustomComponent("testbe:item_script", ItemScript);
});