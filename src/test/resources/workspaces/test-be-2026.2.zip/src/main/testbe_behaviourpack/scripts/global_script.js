import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";


world.afterEvents.playerInteractWithEntity.subscribe((event) => {

	const entity = event.target;
	const sourceentity = event.player;
	const x = event.target.location.x;
	const y = event.target.location.y;
	const z = event.target.location.z;
	const dimension = event.target.dimension;
	dimension.getBlock({ x: x, y: y, z: z })?.setPermutation(BlockPermutation.resolve("testbe:example_block_2"));
	dimension.getBlock({ x: x, y: y, z: z })?.setPermutation(((dimension.getBlock({ x: (entity.location.x), y: (entity.location.y), z: (sourceentity
			.location.z) })?.permutation) ?? BlockPermutation.resolve("minecraft:air")));
	if (true) {
		let _stack6 = new ItemStack("testbe:example_item");
		_stack6.amount = 1;
		entity.getComponent("minecraft:inventory")?.container?.addItem(_stack6);
		dimension.runCommand("time set day");
		dimension.createExplosion({ x: x, y: y, z: z }, 4, {
			breaksBlocks: true,
			causesFire: false,
			allowUnderwater: true
		});
		dimension.runCommand(`structure load testbe:green_house ${x} ${y} ${z} 0_degrees none`);
		dimension.spawnEntity("llama_spit", { x: x, y: y, z: z });
		system.runTimeout(() => {
			dimension.spawnEntity("testbe:example_entity_2", { x: x, y: y, z: z });
			world.getDimension("overworld").runCommand("time set day");
			world.sendMessage("Message");
		}, 20);
		console.log("text");
	}
});