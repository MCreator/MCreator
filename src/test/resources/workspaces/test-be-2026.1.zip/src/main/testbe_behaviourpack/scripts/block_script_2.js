import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";


const BlockScript2 = {
	beforeOnPlayerPlace(event) {
		const x = event.block.location.x;
		const y = event.block.location.y;
		const z = event.block.location.z;
		const dimension = event.dimension;
		dimension.createExplosion({ x: x, y: y, z: z }, 4, {
			breaksBlocks: true,
			causesFire: false,
			allowUnderwater: false
		});
	}
};

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
	blockComponentRegistry.registerCustomComponent("testbe:block_script_2", BlockScript2);
});