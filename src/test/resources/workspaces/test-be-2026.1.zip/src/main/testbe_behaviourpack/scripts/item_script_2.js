import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";


const ItemScript2 = {
	onUse(event) {
		const x = event.source.location.x;
		const y = event.source.location.y;
		const z = event.source.location.z;
		const dimension = event.source.dimension;
		dimension.spawnEntity("testbe:example_entity_2", { x: x, y: y, z: z });
	}
};

system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
	itemComponentRegistry.registerCustomComponent("testbe:item_script_2", ItemScript2);
});