import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";


const BlockScript = {
	onRandomTick(event) {
		const dimension = event.dimension;
		dimension.runCommand("time set day");
	}
};

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
	blockComponentRegistry.registerCustomComponent("testbe:block_script", BlockScript);
});