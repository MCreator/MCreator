package net.mcreator.test.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;

import java.util.HashMap;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;

public class TestCommandProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, CommandContext<CommandSourceStack> arguments, HashMap cmdparams) {
		if (cmdparams == null)
			return;
		if (!((commandParameterEntity(arguments, "entity")) == null)) {
			(commandParameterEntity(arguments, "entity")).setCustomName(Component.literal((cmdparams.containsKey("2") ? cmdparams.get("2").toString() : "")));
			if ((commandParameterEntity(arguments, "entity")) instanceof ServerPlayer _serverPlayer)
				_serverPlayer.setRespawnPosition(_serverPlayer.level().dimension(),
						new BlockPos(commandParameterBlockPos(arguments, "blockpos").getX(), commandParameterBlockPos(arguments, "blockpos").getY(), commandParameterBlockPos(arguments, "blockpos").getZ()), _serverPlayer.getYRot(), true, false);
		} else {
			world.setBlock(new BlockPos(commandParameterBlockPos(arguments, "blockpos").getX(), commandParameterBlockPos(arguments, "blockpos").getY(), commandParameterBlockPos(arguments, "blockpos").getZ()),
					(BlockStateArgument.getBlock(arguments, "blockstate").getState()), 3);
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, (commandParameterBlockPos(arguments, "blockpos").getX()), (commandParameterBlockPos(arguments, "blockpos").getY()), (commandParameterBlockPos(arguments, "blockpos").getZ()),
						(ItemArgument.getItem(arguments, "itemstack").getItem().getDefaultInstance()));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
			try {
				for (Entity entityiterator : EntityArgument.getEntities(arguments, "entities")) {
					entityiterator.getPersistentData().putBoolean("logic", (BoolArgumentType.getBool(arguments, "logic")));
					entityiterator.getPersistentData().putDouble("number", (DoubleArgumentType.getDouble(arguments, "number")));
					entityiterator.getPersistentData().putString("string", (StringArgumentType.getString(arguments, "string")));
				}
			} catch (CommandSyntaxException e) {
				e.printStackTrace();
			}
			if (!world.isClientSide() && world.getServer() != null)
				world.getServer().getPlayerList().broadcastSystemMessage(Component.literal((commandParameterMessage(arguments, "message"))), false);
		}
	}

	private static Entity commandParameterEntity(CommandContext<CommandSourceStack> arguments, String parameter) {
		try {
			return EntityArgument.getEntity(arguments, parameter);
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
			return null;
		}
	}

	private static BlockPos commandParameterBlockPos(CommandContext<CommandSourceStack> arguments, String parameter) {
		try {
			return BlockPosArgument.getLoadedBlockPos(arguments, parameter);
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
			return new BlockPos(0, 0, 0);
		}
	}

	private static String commandParameterMessage(CommandContext<CommandSourceStack> arguments, String parameter) {
		try {
			return MessageArgument.getMessage(arguments, parameter).getString();
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
			return "";
		}
	}
}