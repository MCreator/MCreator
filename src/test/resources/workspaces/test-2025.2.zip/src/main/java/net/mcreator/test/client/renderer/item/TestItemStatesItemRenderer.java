package net.mcreator.test.client.renderer.item;

import net.neoforged.neoforge.client.event.RegisterSpecialModelRendererEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.renderer.special.NoDataSpecialModelRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.Model;
import net.minecraft.client.Minecraft;

import net.mcreator.test.client.model.ModelKreper117;

import java.util.function.Function;
import java.util.Optional;
import java.util.Map;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.MapCodec;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TestItemStatesItemRenderer implements NoDataSpecialModelRenderer {
	@SubscribeEvent
	@OnlyIn(Dist.CLIENT)
	public static void registerItemRenderers(RegisterSpecialModelRendererEvent event) {
		event.register(ResourceLocation.parse("test:test_item_states"), TestItemStatesItemRenderer.Unbaked.MAP_CODEC);
	}

	private static final Map<Integer, Function<EntityModelSet, TestItemStatesItemRenderer>> MODELS = Map
			.ofEntries(Map.entry(2, modelSet -> new TestItemStatesItemRenderer(new ModelKreper117(modelSet.bakeLayer(ModelKreper117.LAYER_LOCATION)), ResourceLocation.parse("minecraft:textures/item/clock_56.png"))));
	private final Model model;
	private final ResourceLocation texture;
	private final ModelResourceLocation transformSource;

	private TestItemStatesItemRenderer(Model model, ResourceLocation texture) {
		this.model = model;
		this.texture = texture;
		this.transformSource = new ModelResourceLocation(ResourceLocation.parse("test:item/test_item_states"), "normal");
	}

	@Override
	public void render(ItemDisplayContext displayContext, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay, boolean glint) {
		poseStack.pushPose();
		Minecraft.getInstance().getModelManager().getModel(this.transformSource).applyTransform(displayContext, poseStack, isLeftHand(displayContext));
		poseStack.translate(0.5, isInventory(displayContext) ? 1.5 : 2, 0.5);
		poseStack.scale(1, -1, displayContext == ItemDisplayContext.GUI ? -1 : 1);
		VertexConsumer vertexConsumer = ItemRenderer.getFoilBuffer(bufferSource, model.renderType(texture), false, glint);
		model.renderToBuffer(poseStack, vertexConsumer, packedLight, packedOverlay);
		poseStack.popPose();
	}

	private static boolean isLeftHand(ItemDisplayContext type) {
		return type == ItemDisplayContext.FIRST_PERSON_LEFT_HAND || type == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
	}

	private static boolean isInventory(ItemDisplayContext type) {
		return type == ItemDisplayContext.GUI || type == ItemDisplayContext.FIXED;
	}

	@OnlyIn(Dist.CLIENT)
	public record Unbaked(int index) implements SpecialModelRenderer.Unbaked {
		public static final MapCodec<TestItemStatesItemRenderer.Unbaked> MAP_CODEC = RecordCodecBuilder
				.mapCodec(instance -> instance.group(ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("index").xmap(opt -> opt.orElse(-1), i -> i == -1 ? Optional.empty() : Optional.of(i)).forGetter(TestItemStatesItemRenderer.Unbaked::index))
						.apply(instance, TestItemStatesItemRenderer.Unbaked::new));

		@Override
		public MapCodec<TestItemStatesItemRenderer.Unbaked> type() {
			return MAP_CODEC;
		}

		@Override
		public SpecialModelRenderer<?> bake(EntityModelSet modelSet) {
			return TestItemStatesItemRenderer.MODELS.get(index).apply(modelSet);
		}
	}
}