package net.mcreator.test.world.features;

import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.WorldGenLevel;

import net.mcreator.test.world.features.configurations.StructureFeatureConfiguration;
import net.mcreator.test.procedures.LogicProcedureProcedure;

public class TestStructureFeatureFeature extends StructureFeature {
	public TestStructureFeatureFeature() {
		super(StructureFeatureConfiguration.CODEC);
	}

	public boolean place(FeaturePlaceContext<StructureFeatureConfiguration> context) {
		WorldGenLevel world = context.level();
		int x = context.origin().getX();
		int y = context.origin().getY();
		int z = context.origin().getZ();
		if (!LogicProcedureProcedure.execute())
			return false;
		return super.place(context);
	}
}