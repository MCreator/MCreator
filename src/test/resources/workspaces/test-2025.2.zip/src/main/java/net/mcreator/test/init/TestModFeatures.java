/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.world.features.TestStructureFeatureFeature;
import net.mcreator.test.world.features.TestPlant3FeatureFeature;
import net.mcreator.test.world.features.TestPlant2FeatureFeature;
import net.mcreator.test.world.features.TestFluidFeatureFeature;
import net.mcreator.test.world.features.TestFeatureFeature;
import net.mcreator.test.world.features.OreBlock3FeatureFeature;
import net.mcreator.test.world.features.OreBlock2FeatureFeature;
import net.mcreator.test.world.features.ComplexTreeFeatureFeature;
import net.mcreator.test.world.features.AnotherStructureFeatureFeature;
import net.mcreator.test.world.features.AllPlacementsFeature;
import net.mcreator.test.TestMod;

public class TestModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(Registries.FEATURE, TestMod.MODID);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEST_FLUID_FEATURE = REGISTRY.register("test_fluid_feature", TestFluidFeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> ALL_PLACEMENTS = REGISTRY.register("all_placements", AllPlacementsFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEST_FEATURE = REGISTRY.register("test_feature", TestFeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEST_STRUCTURE_FEATURE = REGISTRY.register("test_structure_feature", TestStructureFeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEST_PLANT_2_FEATURE = REGISTRY.register("test_plant_2_feature", TestPlant2FeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TEST_PLANT_3_FEATURE = REGISTRY.register("test_plant_3_feature", TestPlant3FeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> ORE_BLOCK_2_FEATURE = REGISTRY.register("ore_block_2_feature", OreBlock2FeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> ORE_BLOCK_3_FEATURE = REGISTRY.register("ore_block_3_feature", OreBlock3FeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> ANOTHER_STRUCTURE_FEATURE = REGISTRY.register("another_structure_feature", AnotherStructureFeatureFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> COMPLEX_TREE_FEATURE = REGISTRY.register("complex_tree_feature", ComplexTreeFeatureFeature::new);
}