package net.mcreator.test.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.scores.Team;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LlamaSpit;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.InteractionResult;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.advancements.Advancement;

import net.mcreator.test.init.TestModPotions;
import net.mcreator.test.TestMod;

import java.util.ArrayList;

public class TestMiscellaneousProcedureBlocksProcedure {
	public static InteractionResult execute(LevelAccessor world, double x, double y, double z, Advancement advancement, BlockState blockstate, ResourceKey<Level> dimension, Direction direction, Entity entity, Entity immediatesourceentity,
			Entity sourceentity, ItemStack itemstack) {
		world.setBlock(BlockPos.containing(x, y, z), Blocks.CHEST.defaultBlockState(), 3);
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() == 0) {
			if (world.hasChunkAt(BlockPos.containing(x, y, z))) {
				if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
					ItemStack _setstack = new ItemStack(Items.APPLE).copy();
					_setstack.setCount(1);
					_itemHandlerModifiable.setStackInSlot(0, _setstack);
				}
			}
		}
		if (((world instanceof Level _lvl4 && _lvl4.getServer() != null && _lvl4.getServer().getAdvancements().get(ResourceLocation.parse("test:test_advancement")).value().equals(advancement)) != (dimension == ResourceKey.create(Registries.DIMENSION,
				ResourceLocation.parse("test:test_dimension")))) == (entity.getDisplayName().getString()).equals(entity.getPersistentData().getString("name"))) {
			entity.clearFire();
		}
		if (false ^ entity instanceof AgeableMob) {
			sourceentity.startRiding(entity);
			if (!immediatesourceentity.level().isClientSide())
				immediatesourceentity.discard();
			if (entity.isVehicle()) {
				for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
					if (!(entityiterator == sourceentity)) {
						entityiterator.clearFire();
					}
				}
			}
		} else {
			if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandlerIter) {
				for (int _idx = 0; _idx < _modHandlerIter.getSlots(); _idx++) {
					ItemStack itemstackiterator = _modHandlerIter.getStackInSlot(_idx).copy();
					if (itemstackiterator.getItem() == ItemStack.EMPTY.getItem()) {
						continue;
					} else if (itemstackiterator.getItem() == itemstack.getItem()) {
						while (hasEntityInInventory(entity, itemstackiterator)) {
							if (entity instanceof Player _player) {
								ItemStack _stktoremove = itemstackiterator;
								_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
							}
						}
					} else {
						if (world instanceof ServerLevel _level) {
							itemstack.hurtAndBreak(1, _level, null, _stkprov -> {
							});
						}
						if (world instanceof ServerLevel _level) {
							(PotionContents.createItemStack(Items.POTION, TestModPotions.TEST_POTION_ITEM)).hurtAndBreak(1, _level, null, _stkprov -> {
							});
						}
						if (world instanceof ServerLevel _level) {
							(PotionContents.createItemStack(Items.POTION, Potions.LONG_SLOW_FALLING)).hurtAndBreak(1, _level, null, _stkprov -> {
							});
						}
					}
				}
			}
		}
		if (direction.getAxis() == Direction.Axis.Y) {
			for (Direction directioniterator : Direction.values()) {
				for (int index1 = 0; index1 < 1; index1++) {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate == Blocks.PISTON.defaultBlockState()) {
						{
							Direction _dir = (directioniterator.getClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x + direction.getStepX(), y + direction.getStepY(), z + direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
								world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				}
			}
			for (Direction directioniterator : Direction.Plane.HORIZONTAL) {
				TestMod.queueServerWork(20, () -> {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(RandomSource.create()) == Direction.DOWN) && blockstate.getBlock() == Blocks.OBSIDIAN) {
						{
							Direction _dir = (directioniterator.getCounterClockWise(Direction.Axis.Y));
							BlockPos _pos = BlockPos.containing(x - direction.getStepX(), y - direction.getStepY(), z - direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
								world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				});
			}
			if ((world instanceof Level _level && _level.getScoreboard().getPlayerTeam("team_name") != null
					? _level.getScoreboard().getPlayerTeam("team_name").getDeathMessageVisibility() == Team.Visibility.ALWAYS
					: false) == (world instanceof Level _level && _level.getScoreboard().getPlayerTeam("team_name") != null ? _level.getScoreboard().getPlayerTeam("team_name").getNameTagVisibility() == Team.Visibility.ALWAYS : false)) {
				if (world instanceof Level _level) {
					PlayerTeam _pt = _level.getScoreboard().getPlayerTeam("team_name");
					if (_pt != null)
						_pt.setNameTagVisibility(Team.Visibility.ALWAYS);
				}
				if (world instanceof Level _level) {
					PlayerTeam _pt = _level.getScoreboard().getPlayerTeam("team_name");
					if (_pt != null)
						_pt.setDeathMessageVisibility(Team.Visibility.ALWAYS);
				}
			}
		}
		{
			Entity _shootFrom = entity;
			Level projectileLevel = _shootFrom.level();
			if (!projectileLevel.isClientSide()) {
				Projectile _entityToSpawn = createPotionProjectile(projectileLevel, PotionContents.createItemStack(Items.SPLASH_POTION, Potions.REGENERATION), null, new Vec3(0, 0, 0));
				_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
				_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		}
		{
			Entity _shootFrom = entity;
			Level projectileLevel = _shootFrom.level();
			if (!projectileLevel.isClientSide()) {
				Projectile _entityToSpawn = createPotionProjectile(projectileLevel, PotionContents.createItemStack(Items.LINGERING_POTION, TestModPotions.TEST_POTION_ITEM), null, new Vec3(0, 0, 0));
				_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
				_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		}
		if (world instanceof ServerLevel projectileLevel) {
			Projectile _entityToSpawn = new LlamaSpit(EntityType.LLAMA_SPIT, projectileLevel);
			_entityToSpawn.setPos(x, y, z);
			_entityToSpawn.shoot(1, 1, 1, 1, 0);
			projectileLevel.addFreshEntity(_entityToSpawn);
		}
		if ("team_name".contains("team_name".replaceAll("team_name", "team_name"))) {
			TestMod.LOGGER.info((executeCommandGetResult(world, new Vec3(x, y, z), "clear") + "" + executeCommandGetResult(entity, "\n")));
		}
		TestMod.LOGGER.info("fgdjfdg".replaceAll("clear", "fdgjfgd"));
		return (world.getBlockState(BlockPos.containing(x, (executeCommandGetResult(entity, "clear")).indexOf("team_name", 0), z))).getBlock() == Blocks.CHEST ? InteractionResult.SUCCESS : InteractionResult.PASS;
	}

	private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
		if (world instanceof ILevelExtension ext) {
			IItemHandler itemHandler = ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
			if (itemHandler != null)
				return itemHandler.getStackInSlot(slot);
		}
		return ItemStack.EMPTY;
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}

	private static Projectile createPotionProjectile(Level level, ItemStack contents, Entity shooter, Vec3 acceleration) {
		ThrownPotion entityToSpawn = new ThrownPotion(EntityType.POTION, level);
		entityToSpawn.setItem(contents);
		return initProjectileProperties(entityToSpawn, shooter, acceleration);
	}

	private static String executeCommandGetResult(LevelAccessor world, Vec3 pos, String command) {
		StringBuilder result = new StringBuilder();
		if (world instanceof ServerLevel level) {
			CommandSource dataConsumer = new CommandSource() {
				@Override
				public void sendSystemMessage(Component message) {
					result.append(message.getString());
				}

				@Override
				public boolean acceptsSuccess() {
					return true;
				}

				@Override
				public boolean acceptsFailure() {
					return true;
				}

				@Override
				public boolean shouldInformAdmins() {
					return false;
				}
			};
			level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(dataConsumer, pos, Vec2.ZERO, level, 4, "", Component.literal(""), level.getServer(), null), command);
		}
		return result.toString();
	}

	private static String executeCommandGetResult(Entity entity, String command) {
		StringBuilder result = new StringBuilder();
		if (!entity.level().isClientSide() && entity.getServer() != null) {
			CommandSource dataConsumer = new CommandSource() {
				@Override
				public void sendSystemMessage(Component message) {
					result.append(message.getString());
				}

				@Override
				public boolean acceptsSuccess() {
					return true;
				}

				@Override
				public boolean acceptsFailure() {
					return true;
				}

				@Override
				public boolean shouldInformAdmins() {
					return false;
				}
			};
			entity.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(dataConsumer, entity.position(), entity.getRotationVector(), entity.level() instanceof ServerLevel ? (ServerLevel) entity.level() : null, 4,
					entity.getName().getString(), entity.getDisplayName(), entity.level().getServer(), entity), command);
		}
		return result.toString();
	}

	private static Projectile initProjectileProperties(Projectile entityToSpawn, Entity shooter, Vec3 acceleration) {
		entityToSpawn.setOwner(shooter);
		if (!Vec3.ZERO.equals(acceleration)) {
			entityToSpawn.setDeltaMovement(acceleration);
			entityToSpawn.hasImpulse = true;
		}
		return entityToSpawn;
	}
}