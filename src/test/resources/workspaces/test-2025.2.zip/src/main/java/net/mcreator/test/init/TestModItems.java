/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.neoforge.client.event.RegisterConditionalItemModelPropertyEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.client.multiplayer.ClientLevel;

import net.mcreator.test.item.inventory.TestMusicDiscInventoryCapability;
import net.mcreator.test.item.TestToolShieldItem;
import net.mcreator.test.item.TestToolItem;
import net.mcreator.test.item.TestTool4Item;
import net.mcreator.test.item.TestTool3Item;
import net.mcreator.test.item.TestTool2Item;
import net.mcreator.test.item.TestRangedItemItem;
import net.mcreator.test.item.TestRangedItem2Item;
import net.mcreator.test.item.TestMusicDiscItem;
import net.mcreator.test.item.TestItemStatesItem;
import net.mcreator.test.item.TestItemItem;
import net.mcreator.test.item.TestFoodItem;
import net.mcreator.test.item.TestFluidItem;
import net.mcreator.test.item.TestDimensionItem;
import net.mcreator.test.item.TestArmorItem;
import net.mcreator.test.TestMod;

import javax.annotation.Nullable;

import java.util.function.Function;

import com.mojang.serialization.MapCodec;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TestModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TestMod.MODID);
	public static final DeferredItem<Item> TEST_ARMOR_HELMET = register("test_armor_helmet", TestArmorItem.Helmet::new);
	public static final DeferredItem<Item> TEST_ARMOR_CHESTPLATE = register("test_armor_chestplate", TestArmorItem.Chestplate::new);
	public static final DeferredItem<Item> TEST_ARMOR_LEGGINGS = register("test_armor_leggings", TestArmorItem.Leggings::new);
	public static final DeferredItem<Item> TEST_ARMOR_BOOTS = register("test_armor_boots", TestArmorItem.Boots::new);
	public static final DeferredItem<Item> TEST_BLOCK = block(TestModBlocks.TEST_BLOCK, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> TEST_DIMENSION = register("test_dimension", TestDimensionItem::new);
	public static final DeferredItem<Item> TEST_FOOD = register("test_food", TestFoodItem::new);
	public static final DeferredItem<Item> TEST_FLUID_BUCKET = register("test_fluid_bucket", TestFluidItem::new);
	public static final DeferredItem<Item> TEST_ITEM = register("test_item", TestItemItem::new);
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_SPAWN_EGG = register("test_living_entity_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_LIVING_ENTITY.get(), properties));
	public static final DeferredItem<Item> TEST_PLANT = block(TestModBlocks.TEST_PLANT);
	public static final DeferredItem<Item> TEST_TOOL = register("test_tool", TestToolItem::new);
	public static final DeferredItem<Item> TEST_TOOL_2 = register("test_tool_2", TestTool2Item::new);
	public static final DeferredItem<Item> TEST_TOOL_3 = register("test_tool_3", TestTool3Item::new);
	public static final DeferredItem<Item> TEST_TOOL_4 = register("test_tool_4", TestTool4Item::new);
	public static final DeferredItem<Item> TEST_PLANT_2 = block(TestModBlocks.TEST_PLANT_2, new Item.Properties().stacksTo(98).rarity(Rarity.RARE).fireResistant());
	public static final DeferredItem<Item> NO_GEN_BLOCK = block(TestModBlocks.NO_GEN_BLOCK);
	public static final DeferredItem<Item> ORE_BLOCK_2 = block(TestModBlocks.ORE_BLOCK_2);
	public static final DeferredItem<Item> ORE_BLOCK_3 = block(TestModBlocks.ORE_BLOCK_3);
	public static final DeferredItem<Item> TEST_RANGED_ITEM = register("test_ranged_item", TestRangedItemItem::new);
	public static final DeferredItem<Item> TEST_TOOL_SHIELD = register("test_tool_shield", TestToolShieldItem::new);
	public static final DeferredItem<Item> TEST_LIVING_ENTITY_2_SPAWN_EGG = register("test_living_entity_2_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_LIVING_ENTITY_2.get(), properties));
	public static final DeferredItem<Item> TEST_RANGED_ITEM_2 = register("test_ranged_item_2", TestRangedItem2Item::new);
	public static final DeferredItem<Item> TEST_ITEM_STATES = register("test_item_states", TestItemStatesItem::new);
	public static final DeferredItem<Item> TEST_MUSIC_DISC = register("test_music_disc", TestMusicDiscItem::new);
	public static final DeferredItem<Item> TEST_ENTITY_2_SPAWN_EGG = register("test_entity_2_spawn_egg", properties -> new SpawnEggItem(TestModEntities.TEST_ENTITY_2.get(), properties));
	public static final DeferredItem<Item> TEST_PLANT_4 = block(TestModBlocks.TEST_PLANT_4);
	public static final DeferredItem<Item> ANIMATED_BLOCK = block(TestModBlocks.ANIMATED_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new TestMusicDiscInventoryCapability(stack), TEST_MUSIC_DISC.get());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void registerItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("test:test_ranged_item/property1"), TestRangedItemItem.Property1Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item/property2"), TestRangedItemItem.Property2Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item_2/property1"), TestRangedItem2Item.Property1Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_ranged_item_2/property2"), TestRangedItem2Item.Property2Property.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_item_states/test"), TestItemStatesItem.TestProperty.MAP_CODEC);
			event.register(ResourceLocation.parse("test:test_item_states/test2"), TestItemStatesItem.Test2Property.MAP_CODEC);
		}

		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void registerItemModelProperties(RegisterConditionalItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("test:lefthanded"), LegacyLeftHandedProperty.MAP_CODEC);
		}

		public record LegacyLeftHandedProperty() implements ConditionalItemModelProperty {
			public static final MapCodec<LegacyLeftHandedProperty> MAP_CODEC = MapCodec.unit(new LegacyLeftHandedProperty());

			@Override
			public boolean get(ItemStack itemStackToRender, @Nullable ClientLevel clientWorld, @Nullable LivingEntity entity, int seed, ItemDisplayContext displayContext) {
				return entity != null && entity.getMainArm() == HumanoidArm.LEFT;
			}

			@Override
			public MapCodec<LegacyLeftHandedProperty> type() {
				return MAP_CODEC;
			}
		}
	}
}