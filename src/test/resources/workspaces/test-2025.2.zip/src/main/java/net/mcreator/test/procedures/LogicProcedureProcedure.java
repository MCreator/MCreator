package net.mcreator.test.procedures;

public class LogicProcedureProcedure {
	public static boolean execute() {
		return true;
	}
}