package net.mcreator.test.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.test.init.TestModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements TestModBiomes.TestModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> test_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.test_dimensionTypeReference != null) {
			retval = TestModBiomes.adaptSurfaceRule(retval, this.test_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void settestDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.test_dimensionTypeReference = dimensionType;
	}
}