package net.mcreator.test.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class TestTool2Item extends ShearsItem {
	public TestTool2Item(Item.Properties properties) {
		super(properties.durability(100).enchantable(2));
	}

	@Override
	public float getDestroySpeed(ItemStack stack, BlockState blockstate) {
		return 4f;
	}
}