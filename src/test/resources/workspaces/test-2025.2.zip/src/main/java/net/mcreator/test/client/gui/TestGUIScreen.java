package net.mcreator.test.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.test.world.inventory.TestGUIMenu;
import net.mcreator.test.procedures.TextProcedureProcedure;
import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.procedures.EntityProviderProcedure;
import net.mcreator.test.network.TestGUIButtonMessage;
import net.mcreator.test.init.TestModScreens;

import java.util.stream.Collectors;
import java.util.Arrays;

import com.mojang.blaze3d.systems.RenderSystem;

public class TestGUIScreen extends AbstractContainerScreen<TestGUIMenu> implements TestModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	EditBox testTextField;
	Checkbox testCheckBox;
	Button button_testbutton;
	ImageButton imagebutton_block;

	public TestGUIScreen(TestGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 263;
		this.imageHeight = 166;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 0 && elementState instanceof String stringState) {
			if (name.equals("testTextField"))
				testTextField.setValue(stringState);
		}
		menuStateUpdateActive = false;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("test:textures/screens/test_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		testTextField.render(guiGraphics, mouseX, mouseY, partialTicks);
		if (EntityProviderProcedure.execute(entity) instanceof LivingEntity livingEntity) {
			if (LogicProcedureProcedure.execute())
				TestModScreens.renderEntityInInventoryFollowsAngle(guiGraphics, this.leftPos + 23, this.topPos + 95, 30, 0.1f + (float) Math.atan((this.leftPos + 23 - mouseX) / 40.0), (float) Math.atan((this.topPos + 46 - mouseY) / 40.0),
						livingEntity);
		}
		boolean customTooltipShown = false;
		if (LogicProcedureProcedure.execute())
			if (mouseX > leftPos + 206 && mouseX < leftPos + 230 && mouseY > topPos + 69 && mouseY < topPos + 93) {
				guiGraphics.renderTooltip(font, Component.translatable("gui.test.test_gui.tooltip_empty"), mouseX, mouseY);
				customTooltipShown = true;
			}
		if (mouseX > leftPos + 207 && mouseX < leftPos + 231 && mouseY > topPos + 98 && mouseY < topPos + 122) {
			String hoverText = TextProcedureProcedure.execute();
			if (hoverText != null) {
				guiGraphics.renderComponentTooltip(font, Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()), mouseX, mouseY);
			}
			customTooltipShown = true;
		}
		if (!customTooltipShown)
			this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("test:textures/screens/block.png"), this.leftPos + 233, this.topPos + 20, 0, 0, 16, 8, 16, 16);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (testTextField.isFocused())
			return testTextField.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String testTextFieldValue = testTextField.getValue();
		super.resize(minecraft, width, height);
		testTextField.setValue(testTextFieldValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.test.test_gui.label_label_text"), 31, 31, -1, false);
	}

	@Override
	public void init() {
		super.init();
		testTextField = new EditBox(this.font, this.leftPos + 32, this.topPos + 46, 118, 18, Component.translatable("gui.test.test_gui.testTextField"));
		testTextField.setMaxLength(8192);
		testTextField.setResponder(content -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 0, "testTextField", content, false);
		});
		testTextField.setHint(Component.translatable("gui.test.test_gui.testTextField"));
		this.addWidget(this.testTextField);
		button_testbutton = Button.builder(Component.translatable("gui.test.test_gui.button_testbutton"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new TestGUIButtonMessage(0, x, y, z));
				TestGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 31, this.topPos + 5, 100, 20).build();
		this.addRenderableWidget(button_testbutton);
		imagebutton_block = new ImageButton(this.leftPos + 12, this.topPos + 117, 16, 16, new WidgetSprites(ResourceLocation.parse("test:textures/screens/block.png"), ResourceLocation.parse("test:textures/screens/block.png")), e -> {
			if (LogicProcedureProcedure.execute()) {
				PacketDistributor.sendToServer(new TestGUIButtonMessage(1, x, y, z));
				TestGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (LogicProcedureProcedure.execute())
					guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		this.addRenderableWidget(imagebutton_block);
		testCheckBox = Checkbox.builder(Component.translatable("gui.test.test_gui.testCheckBox"), this.font).pos(this.leftPos + 156, this.topPos + 45).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "testCheckBox", value, false);
		}).build();
		this.addRenderableWidget(testCheckBox);
	}
}