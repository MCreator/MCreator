
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.enchantment.TestEnchantmentEnchantment;
import net.mcreator.test.TestMod;

public class TestModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(Registries.ENCHANTMENT, TestMod.MODID);
	public static final DeferredHolder<Enchantment, Enchantment> TEST_ENCHANTMENT = REGISTRY.register("test_enchantment", () -> new TestEnchantmentEnchantment());
}
