
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TestModGameRules {
	public static GameRules.Key<GameRules.IntegerValue> TEST_RULE;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		TEST_RULE = GameRules.register("testRule", GameRules.Category.MISC, GameRules.IntegerValue.create(0));
	}
}
