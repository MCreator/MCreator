
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.test.block.TestPlantBlock;
import net.mcreator.test.block.TestPlant3Block;
import net.mcreator.test.block.TestPlant2Block;
import net.mcreator.test.block.TestFluidBlock;
import net.mcreator.test.block.TestDimensionPortalBlock;
import net.mcreator.test.block.TestBlockBlock;
import net.mcreator.test.block.OreBlock3Block;
import net.mcreator.test.block.OreBlock2Block;
import net.mcreator.test.block.NoGenBlockBlock;
import net.mcreator.test.TestMod;

public class TestModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(TestMod.MODID);
	public static final DeferredBlock<Block> TEST_BLOCK = REGISTRY.register("test_block", TestBlockBlock::new);
	public static final DeferredBlock<Block> TEST_DIMENSION_PORTAL = REGISTRY.register("test_dimension_portal", TestDimensionPortalBlock::new);
	public static final DeferredBlock<Block> TEST_FLUID = REGISTRY.register("test_fluid", TestFluidBlock::new);
	public static final DeferredBlock<Block> TEST_PLANT = REGISTRY.register("test_plant", TestPlantBlock::new);
	public static final DeferredBlock<Block> TEST_PLANT_2 = REGISTRY.register("test_plant_2", TestPlant2Block::new);
	public static final DeferredBlock<Block> TEST_PLANT_3 = REGISTRY.register("test_plant_3", TestPlant3Block::new);
	public static final DeferredBlock<Block> NO_GEN_BLOCK = REGISTRY.register("no_gen_block", NoGenBlockBlock::new);
	public static final DeferredBlock<Block> ORE_BLOCK_2 = REGISTRY.register("ore_block_2", OreBlock2Block::new);
	public static final DeferredBlock<Block> ORE_BLOCK_3 = REGISTRY.register("ore_block_3", OreBlock3Block::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			TestPlant3Block.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			TestPlant3Block.itemColorLoad(event);
		}
	}
}
