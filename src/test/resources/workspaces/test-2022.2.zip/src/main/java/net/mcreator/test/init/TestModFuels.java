
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;

import net.mcreator.test.procedures.TestConditionProcedure;

@Mod.EventBusSubscriber
public class TestModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == Blocks.DARK_OAK_WOOD.asItem() && TestConditionProcedure.execute())
			event.setBurnTime(1600);
		else if (itemstack.getItem() == Blocks.SMOOTH_QUARTZ_SLAB.asItem() && TestConditionProcedure.execute())
			event.setBurnTime(1600);
	}
}
