package net.mcreator.test.procedures;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.InteractionResult;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.Advancement;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Random;
import java.util.ArrayList;

public class TestMiscellaneousProcedureBlocksProcedure {
	public static InteractionResult execute(LevelAccessor world, double x, double y, double z, Advancement advancement, BlockState blockstate,
			ResourceKey<Level> dimension, Direction direction, Entity entity, Entity immediatesourceentity, Entity sourceentity,
			ItemStack itemstack) {
		if (advancement == null || dimension == null || direction == null || entity == null || immediatesourceentity == null || sourceentity == null)
			return InteractionResult.PASS;
		world.setBlock(new BlockPos(x, y, z), Blocks.CHEST.defaultBlockState(), 3);
		if (new Object() {
			public int getAmount(LevelAccessor world, BlockPos pos, int slotid) {
				AtomicInteger _retval = new AtomicInteger(0);
				BlockEntity _ent = world.getBlockEntity(pos);
				if (_ent != null)
					_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null)
							.ifPresent(capability -> _retval.set(capability.getStackInSlot(slotid).getCount()));
				return _retval.get();
			}
		}.getAmount(world, new BlockPos(x, y, z), 0) == 0) {
			{
				BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
				if (_ent != null) {
					final int _slotid = 0;
					final ItemStack _setstack = new ItemStack(Items.APPLE);
					_setstack.setCount(1);
					_ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						if (capability instanceof IItemHandlerModifiable)
							((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
					});
				}
			}
		}
		if (((world instanceof Level _lvl && _lvl.getServer() != null
				? _lvl.getServer().getAdvancements().getAdvancement(new ResourceLocation("test:test_advancement")).equals(advancement)
				: false) != ((dimension) == (ResourceKey.create(Registry.DIMENSION_REGISTRY,
						new ResourceLocation("test:test_dimension"))))) == (entity.getDisplayName().getString())
								.equals(entity.getPersistentData().getString("name"))) {
			entity.clearFire();
		}
		if (false ^ entity instanceof AgeableMob) {
			sourceentity.startRiding(entity);
			if (!immediatesourceentity.level.isClientSide())
				immediatesourceentity.discard();
			if (entity.isVehicle()) {
				for (Entity entityiterator : new ArrayList<>(entity.getPassengers())) {
					if (!(entityiterator == sourceentity)) {
						entityiterator.clearFire();
					}
				}
			}
		} else {
			{
				AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
				entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> _iitemhandlerref.set(capability));
				if (_iitemhandlerref.get() != null) {
					for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
						ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
						if (itemstackiterator.getItem() == (ItemStack.EMPTY).getItem()) {
							continue;
						} else if (itemstackiterator.getItem() == itemstack.getItem()) {
							while (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(itemstackiterator) : false) {
								if (entity instanceof Player _player) {
									ItemStack _stktoremove = itemstackiterator;
									_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1,
											_player.inventoryMenu.getCraftSlots());
								}
							}
						} else {
							{
								ItemStack _ist = itemstack;
								if (_ist.hurt(1, new Random(), null)) {
									_ist.shrink(1);
									_ist.setDamageValue(0);
								}
							}
						}
					}
				}
			}
		}
		if (direction.getAxis() == Direction.Axis.Y) {
			for (Direction directioniterator : Direction.values()) {
				for (int index1 = 0; index1 < (int) (1); index1++) {
					if (((directioniterator.getOpposite()) == direction || Direction.getRandom(new Random()) == Direction.DOWN)
							&& blockstate == Blocks.PISTON.defaultBlockState()) {
						{
							Direction _dir = (directioniterator.getClockWise(Direction.Axis.Y));
							BlockPos _pos = new BlockPos(x + direction.getStepX(), y + direction.getStepY(), z + direction.getStepZ());
							BlockState _bs = world.getBlockState(_pos);
							Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
							if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
								world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
							} else {
								_property = _bs.getBlock().getStateDefinition().getProperty("axis");
								if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
									world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
							}
						}
					}
				}
			}
			for (Direction directioniterator : Direction.Plane.HORIZONTAL) {
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private LevelAccessor world;

					public void start(LevelAccessor world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						if (((directioniterator.getOpposite()) == direction || Direction.getRandom(new Random()) == Direction.DOWN)
								&& blockstate.getBlock() == Blocks.OBSIDIAN) {
							{
								Direction _dir = (directioniterator.getCounterClockWise(Direction.Axis.Y));
								BlockPos _pos = new BlockPos(x - direction.getStepX(), y - direction.getStepY(), z - direction.getStepZ());
								BlockState _bs = world.getBlockState(_pos);
								Property<?> _property = _bs.getBlock().getStateDefinition().getProperty("facing");
								if (_property instanceof DirectionProperty _dp && _dp.getPossibleValues().contains(_dir)) {
									world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
								} else {
									_property = _bs.getBlock().getStateDefinition().getProperty("axis");
									if (_property instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis()))
										world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
								}
							}
						}
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, 20);
			}
		}
		return (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.CHEST ? InteractionResult.SUCCESS : InteractionResult.PASS;
	}
}
