
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.test.entity.TestRangedItemEntity;
import net.mcreator.test.entity.TestLivingEntityEntityProjectile;
import net.mcreator.test.entity.TestLivingEntityEntity;
import net.mcreator.test.TestMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, TestMod.MODID);
	public static final RegistryObject<EntityType<TestLivingEntityEntity>> TEST_LIVING_ENTITY = register("test_living_entity",
			EntityType.Builder.<TestLivingEntityEntity>of(TestLivingEntityEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TestLivingEntityEntity::new).fireImmune().sized(0.6f, 2f));
	public static final RegistryObject<EntityType<TestLivingEntityEntityProjectile>> TEST_LIVING_ENTITY_PROJECTILE = register(
			"projectile_test_living_entity",
			EntityType.Builder.<TestLivingEntityEntityProjectile>of(TestLivingEntityEntityProjectile::new, MobCategory.MISC)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1)
					.setCustomClientFactory(TestLivingEntityEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TestRangedItemEntity>> TEST_RANGED_ITEM = register("projectile_test_ranged_item",
			EntityType.Builder.<TestRangedItemEntity>of(TestRangedItemEntity::new, MobCategory.MISC).setCustomClientFactory(TestRangedItemEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			TestLivingEntityEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(TEST_LIVING_ENTITY.get(), TestLivingEntityEntity.createAttributes().build());
	}
}
