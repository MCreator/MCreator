
package net.mcreator.test.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.fluids.FluidAttributes;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.test.procedures.TestProcedureProcedure;
import net.mcreator.test.init.TestModItems;
import net.mcreator.test.init.TestModFluids;
import net.mcreator.test.init.TestModBlocks;

public abstract class TestFluidFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(TestModFluids.TEST_FLUID,
			TestModFluids.FLOWING_TEST_FLUID,
			FluidAttributes.builder(new ResourceLocation("test:blocks/block"), new ResourceLocation("test:blocks/block")).luminosity(3).density(998)
					.viscosity(1003)

					.gaseous()

	).explosionResistance(100f)

			.bucket(TestModItems.TEST_FLUID_BUCKET).block(() -> (LiquidBlock) TestModBlocks.TEST_FLUID.get());

	private TestFluidFluid() {
		super(PROPERTIES);
	}

	@Override
	protected void beforeDestroyingBlock(LevelAccessor world, BlockPos pos, BlockState blockstate) {
		TestProcedureProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	public static class Source extends TestFluidFluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends TestFluidFluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
