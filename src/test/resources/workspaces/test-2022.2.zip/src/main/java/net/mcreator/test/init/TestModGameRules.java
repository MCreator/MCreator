
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TestModGameRules {
	public static final GameRules.Key<GameRules.IntegerValue> TESTGAMERULE = GameRules.register("testGameRule", GameRules.Category.CHAT,
			GameRules.IntegerValue.create(5));
}
