package net.mcreator.test.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.common.ForgeHooks;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.SimpleContainer;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.client.Minecraft;

import net.mcreator.test.init.TestModEnchantments;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Random;
import java.util.Map;

public class TestItemProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		Entity fakePlayer = null;
		(itemstack).grow(0);
		(itemstack).setCount((itemstack).getCount());
		(itemstack).shrink(0);
		{
			ItemStack _ist = itemstack;
			if (_ist.hurt(0, new Random(), null)) {
				_ist.shrink(1);
				_ist.setDamageValue(0);
			}
		}
		(itemstack).setDamageValue((itemstack).getDamageValue());
		(itemstack).enchant(TestModEnchantments.TEST_ENCHANTMENT.get(), (int) Mth.nextDouble(new Random(), 1, 20));
		{
			Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
			if (_enchantments.containsKey(Enchantments.VANISHING_CURSE)) {
				_enchantments.remove(Enchantments.VANISHING_CURSE);
				EnchantmentHelper.setEnchantments(_enchantments, itemstack);
			}
		}
		if (world.getServer() != null) {
			fakePlayer = FakePlayerFactory.get(world.getServer().overworld(), Minecraft.getInstance().getUser().getGameProfile());
			if (fakePlayer instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack.getItem(), Mth.nextInt(new Random(), 10, 200));
		}
		{
			CompoundTag _nbtTag = (itemstack.copy()).getTag();
			if (_nbtTag != null)
				itemstack.setTag(_nbtTag.copy());
		}
		itemstack.getOrCreateTag().putBoolean("logic",
				(((itemstack.getItem().isEdible() && (world instanceof Level _lvlCanSmelt
						? _lvlCanSmelt.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(itemstack), _lvlCanSmelt).isPresent()
						: false)) != (itemstack.getRarity() == Rarity.EPIC)) == ((itemstack).isEnchanted() ^ (itemstack).isEnchantable()
								|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0)
						|| (itemstack
								.getItem() == ((world instanceof Level _lvlSmeltResult && _lvlSmeltResult.getRecipeManager()
										.getRecipeFor(RecipeType.SMELTING,
												new SimpleContainer((new ItemStack((ForgeRegistries.BLOCKS.tags()
														.getTag(BlockTags.create(new ResourceLocation("minecraft:copper_ores")))
														.getRandomElement(new Random()).orElseGet(() -> Blocks.AIR))))),
												_lvlSmeltResult)
										.isPresent())
												? _lvlSmeltResult.getRecipeManager()
														.getRecipeFor(RecipeType.SMELTING,
																new SimpleContainer((new ItemStack((ForgeRegistries.BLOCKS.tags()
																		.getTag(BlockTags.create(new ResourceLocation("minecraft:copper_ores")))
																		.getRandomElement(new Random()).orElseGet(() -> Blocks.AIR))))),
																_lvlSmeltResult)
														.get().getResultItem().copy()
												: ItemStack.EMPTY)
										.getItem()
								&& itemstack.getItem() instanceof PickaxeItem) != (itemstack.getOrCreateTag().getBoolean("logic")
										^ (ForgeRegistries.ITEMS.tags().getTag(ItemTags.create(new ResourceLocation("minecraft:mineable/pickaxe")))
												.getRandomElement(new Random()).orElseGet(() -> Items.AIR))
												.isCorrectToolForDrops((ForgeRegistries.BLOCKS.tags()
														.getTag(BlockTags.create(new ResourceLocation("minecraft:diamond_ores")))
														.getRandomElement(new Random()).orElseGet(() -> Blocks.AIR)).defaultBlockState()))));
		itemstack.getOrCreateTag().putDouble("number",
				((ForgeHooks.getBurnTime(itemstack, null) / EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, itemstack)
						+ ForgeHooks.getBurnTime(itemstack, null)
								% EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, itemstack))
						* (itemstack.getOrCreateTag().getDouble("number")
								- Math.pow((itemstack).getMaxDamage(), EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MENDING, itemstack)))));
		itemstack.getOrCreateTag().putString("string", (itemstack.getOrCreateTag().getString("string")));
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation((EnchantmentHelper.enchantItem(new Random(),
					((ForgeRegistries.BLOCKS.tags().getTag(BlockTags.create(new ResourceLocation("minecraft:walls"))).getRandomElement(new Random())
							.orElseGet(() -> Blocks.AIR)) instanceof LiquidBlock _liquid
									? new ItemStack(_liquid.getFluid().getBucket())
									: ItemStack.EMPTY),
					(int) (Math.round(Math.random()) == 1
							? (itemstack.getItem().isEdible() ? itemstack.getItem().getFoodProperties().getNutrition() : 0)
							: (itemstack.getItem().isEdible() ? itemstack.getItem().getFoodProperties().getSaturationModifier() : 0)),
					(itemstack.is(ItemTags.create(new ResourceLocation("test:test")))))));
		{
			ItemStack _isc = itemstack;
			final ItemStack _setstack = ((new Object() {
				public ItemStack getItemStack(int sltid, ItemStack _isc) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					_isc.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack(0, itemstack)).copy());
			final int _sltid = 0;
			_setstack.setCount(((new Object() {
				public ItemStack getItemStack(int sltid, ItemStack _isc) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					_isc.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack(0, itemstack))).getCount());
			_isc.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
				if (capability instanceof IItemHandlerModifiable) {
					((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
				}
			});
		}
		(itemstack).setHoverName(new TextComponent((itemstack.getDisplayName().getString())));
	}
}
