
package net.mcreator.test.enchantment;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.test.init.TestModItems;
import net.mcreator.test.init.TestModBlocks;

public class TestEnchantmentEnchantment extends Enchantment {
	public TestEnchantmentEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public int getMinLevel() {
		return 3;
	}

	@Override
	public int getMaxLevel() {
		return 3;
	}

	@Override
	public int getDamageProtection(int level, DamageSource source) {
		return level * 2;
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		return ench == Enchantments.FIRE_PROTECTION || ench == Enchantments.FALL_PROTECTION || ench == Enchantments.BLAST_PROTECTION
				|| ench == Enchantments.PROJECTILE_PROTECTION || ench == Enchantments.RESPIRATION;
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack stack) {
		Item item = stack.getItem();
		return item == TestModItems.TEST_ARMOR_HELMET.get() || item == TestModItems.TEST_ARMOR_CHESTPLATE.get()
				|| item == TestModItems.TEST_ARMOR_LEGGINGS.get() || item == TestModItems.TEST_ARMOR_BOOTS.get()
				|| item == TestModBlocks.TEST_BLOCK.get().asItem() || item == TestModItems.TEST_DIMENSION.get()
				|| item == TestModBlocks.TEST_FLUID.get().asItem() || item == TestModItems.TEST_FOOD.get() || item == TestModItems.TEST_ITEM.get()
				|| item == TestModBlocks.TEST_PLANT.get().asItem() || item == TestModItems.TEST_RANGED_ITEM.get()
				|| item == TestModItems.TEST_TOOL.get() || item == TestModItems.TEST_TOOL_2.get() || item == TestModItems.TEST_TOOL_3.get()
				|| item == TestModItems.TEST_TOOL_4.get() || item == TestModItems.TEST_MUSIC_DISC.get() || item == Blocks.AIR.asItem()
				|| item == Blocks.VOID_AIR.asItem() || item == Blocks.CAVE_AIR.asItem() || item == Blocks.STONE.asItem()
				|| item == Blocks.STONE_STAIRS.asItem() || item == Blocks.STONE_SLAB.asItem() || item == Blocks.GRANITE.asItem()
				|| item == Blocks.POLISHED_GRANITE.asItem() || item == Blocks.GRANITE_STAIRS.asItem()
				|| item == Blocks.POLISHED_GRANITE_STAIRS.asItem() || item == Blocks.GRANITE_SLAB.asItem()
				|| item == Blocks.POLISHED_GRANITE_SLAB.asItem() || item == Blocks.GRANITE_WALL.asItem() || item == Blocks.DIORITE.asItem()
				|| item == Blocks.DIORITE_STAIRS.asItem() || item == Blocks.DIORITE_SLAB.asItem() || item == Blocks.DIORITE_WALL.asItem()
				|| item == Blocks.POLISHED_DIORITE.asItem() || item == Blocks.POLISHED_DIORITE_SLAB.asItem()
				|| item == Blocks.POLISHED_DIORITE_STAIRS.asItem();
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}

	@Override
	public boolean isCurse() {
		return true;
	}
}
