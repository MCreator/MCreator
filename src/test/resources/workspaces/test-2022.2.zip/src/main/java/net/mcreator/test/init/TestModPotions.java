
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.test.TestMod;

public class TestModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, TestMod.MODID);
	public static final RegistryObject<Potion> TEST_POTION_ITEM = REGISTRY.register("test_potion_item",
			() -> new Potion(new MobEffectInstance(TestModMobEffects.TEST_POTION.get(), 3600, 0, false, true)));
}
