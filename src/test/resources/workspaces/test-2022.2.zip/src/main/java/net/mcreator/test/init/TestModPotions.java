
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.test.TestMod;

public class TestModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, TestMod.MODID);
	public static final RegistryObject<Potion> TEST_POTION_POTION_ITEM = REGISTRY.register("test_potion_potion_item",
			() -> new Potion(new MobEffectInstance(TestModMobEffects.TEST_POTION_POTION_ITEM.get(), 3600, 0, false, true),
					new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3600, 0, true, true),
					new MobEffectInstance(MobEffects.DIG_SPEED, 500, 2, false, false)));
}
