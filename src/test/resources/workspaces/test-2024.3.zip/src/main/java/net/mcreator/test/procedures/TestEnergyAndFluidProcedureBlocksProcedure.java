package net.mcreator.test.procedures;

import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.test.init.TestModFluids;

public class TestEnergyAndFluidProcedureBlocksProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (new Object() {
			public int getMaxEnergyStored(LevelAccessor level, BlockPos pos) {
				if (level instanceof ILevelExtension _ext) {
					IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
					if (_entityStorage != null)
						return _entityStorage.getMaxEnergyStored();
				}
				return 0;
			}
		}.getMaxEnergyStored(world, BlockPos.containing(x, y, z)) > 0 && new Object() {
			public int getEnergyStored(LevelAccessor level, BlockPos pos) {
				if (level instanceof ILevelExtension _ext) {
					IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
					if (_entityStorage != null)
						return _entityStorage.getEnergyStored();
				}
				return 0;
			}
		}.getEnergyStored(world, BlockPos.containing(x, y, z)) > 0) {
			if (new Object() {
				public boolean canReceiveEnergy(LevelAccessor level, BlockPos pos) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
						if (_entityStorage != null)
							return _entityStorage.canReceive();
					}
					return false;
				}
			}.canReceiveEnergy(world, BlockPos.containing(x, y, z)) && new Object() {
				public int receiveEnergySimulate(LevelAccessor level, BlockPos pos, int _amount) {
					if (level instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
						if (_entityStorage != null)
							return _entityStorage.receiveEnergy(_amount, true);
					}
					return 0;
				}
			}.receiveEnergySimulate(world, BlockPos.containing(x, y, z), 100) > 0) {
				if (world instanceof ILevelExtension _ext) {
					IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
					if (_entityStorage != null)
						_entityStorage.receiveEnergy(100, false);
				}
				if (new Object() {
					public boolean canExtractEnergy(LevelAccessor level, BlockPos pos) {
						if (level instanceof ILevelExtension _ext) {
							IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
							if (_entityStorage != null)
								return _entityStorage.canExtract();
						}
						return false;
					}
				}.canExtractEnergy(world, BlockPos.containing(x, y, z)) && new Object() {
					public int extractEnergySimulate(LevelAccessor level, BlockPos pos, int _amount) {
						if (level instanceof ILevelExtension _ext) {
							IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, pos, null);
							if (_entityStorage != null)
								return _entityStorage.extractEnergy(_amount, true);
						}
						return 0;
					}
				}.extractEnergySimulate(world, BlockPos.containing(x, y, z), 100) > 0) {
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
						if (_entityStorage != null)
							_entityStorage.extractEnergy(100, false);
					}
				}
			}
		} else if (new Object() {
			public int getBlockTanks(LevelAccessor level, BlockPos pos) {
				if (level instanceof ILevelExtension _ext) {
					IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, pos, null);
					if (_fluidHandler != null)
						return _fluidHandler.getTanks();
				}
				return 0;
			}
		}.getBlockTanks(world, BlockPos.containing(x, y, z)) >= 1 && new Object() {
			public int getFluidTankCapacity(LevelAccessor level, BlockPos pos, int tank) {
				if (level instanceof ILevelExtension _ext) {
					IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, pos, null);
					if (_fluidHandler != null)
						return _fluidHandler.getTankCapacity(tank);
				}
				return 0;
			}
		}.getFluidTankCapacity(world, BlockPos.containing(x, y, z), 1) > 0 && new Object() {
			public int getFluidTankLevel(LevelAccessor level, BlockPos pos, int tank) {
				if (level instanceof ILevelExtension _ext) {
					IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, pos, null);
					if (_fluidHandler != null)
						return _fluidHandler.getFluidInTank(tank).getAmount();
				}
				return 0;
			}
		}.getFluidTankLevel(world, BlockPos.containing(x, y, z), 1) > 0) {
			if (new Object() {
				public int fillTankSimulate(LevelAccessor level, BlockPos pos, int amount) {
					if (level instanceof ILevelExtension _ext) {
						IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, pos, null);
						if (_fluidHandler != null)
							return _fluidHandler.fill(new FluidStack(TestModFluids.TEST_FLUID.get(), amount), IFluidHandler.FluidAction.SIMULATE);
					}
					return 0;
				}
			}.fillTankSimulate(world, BlockPos.containing(x, y, z), 100) > 0) {
				if (world instanceof ILevelExtension _ext) {
					IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, BlockPos.containing(x, y, z), null);
					if (_fluidHandler != null)
						_fluidHandler.fill(new FluidStack(TestModFluids.FLOWING_TEST_FLUID.get(), 100), IFluidHandler.FluidAction.EXECUTE);
				}
				if (new Object() {
					public int drainTankSimulate(LevelAccessor level, BlockPos pos, int amount) {
						if (level instanceof ILevelExtension _ext) {
							IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, pos, null);
							if (_fluidHandler != null)
								return _fluidHandler.drain(amount, IFluidHandler.FluidAction.SIMULATE).getAmount();
						}
						return 0;
					}
				}.drainTankSimulate(world, BlockPos.containing(x, y, z), 100) > 0) {
					if (world instanceof ILevelExtension _ext) {
						IFluidHandler _fluidHandler = _ext.getCapability(Capabilities.FluidHandler.BLOCK, BlockPos.containing(x, y, z), null);
						if (_fluidHandler != null)
							_fluidHandler.drain(100, IFluidHandler.FluidAction.EXECUTE);
					}
				}
			}
		}
	}
}
