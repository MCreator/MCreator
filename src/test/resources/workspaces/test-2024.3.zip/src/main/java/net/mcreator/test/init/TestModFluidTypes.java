
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.test.fluid.types.TestFluidFluidType;
import net.mcreator.test.TestMod;

public class TestModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, TestMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> TEST_FLUID_TYPE = REGISTRY.register("test_fluid", () -> new TestFluidFluidType());
}
