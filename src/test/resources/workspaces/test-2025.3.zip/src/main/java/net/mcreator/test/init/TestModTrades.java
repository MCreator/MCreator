/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.test.init;

import net.neoforged.neoforge.event.village.WandererTradesEvent;
import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

@EventBusSubscriber
public class TestModTrades {
	@SubscribeEvent
	public static void registerWanderingTrades(WandererTradesEvent event) {
		event.getGenericTrades().add(new BasicItemListing(new ItemStack(TestModItems.TEST_MUSIC_DISC.get(), 4), new ItemStack(Items.HEART_OF_THE_SEA), 10, 5, 0.05f));
	}

	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.CARTOGRAPHER) {
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(TestModItems.TEST_ITEM.get(), 8), new ItemStack(Items.FILLED_MAP, 3), 10, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.LIBRARIAN) {
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(TestModItems.TEST_DIMENSION.get()), new ItemStack(Items.MOJANG_BANNER_PATTERN), new ItemStack(Items.KNOWLEDGE_BOOK), 10, 5, 0.05f));
		}
		if (event.getType() == ResourceKey.create(Registries.VILLAGER_PROFESSION, ResourceLocation.parse("test:test_proffesion"))) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.WAXED_CUT_COPPER_SLAB), new ItemStack(TestModItems.TEST_LIVING_ENTITY_SPAWN_EGG.get()), new ItemStack(TestModItems.TEST_ARMOR_BOOTS.get()), 10, 5, 0.05f));
		}
	}
}