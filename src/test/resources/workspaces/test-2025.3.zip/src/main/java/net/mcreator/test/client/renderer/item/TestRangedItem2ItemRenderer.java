package net.mcreator.test.client.renderer.item;

import org.joml.Vector3f;

import org.checkerframework.checker.units.qual.s;

import net.neoforged.neoforge.client.event.RegisterSpecialModelRendererEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.animation.KeyframeAnimation;

import net.mcreator.test.procedures.LogicProcedureProcedure;
import net.mcreator.test.client.model.animations.MonsterAnimation;
import net.mcreator.test.client.model.ModelKreper117;

import java.util.stream.IntStream;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.WeakHashMap;
import java.util.Set;
import java.util.Optional;
import java.util.Map;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.MapCodec;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@EventBusSubscriber(Dist.CLIENT)
public class TestRangedItem2ItemRenderer implements SpecialModelRenderer<ItemStack> {
	@SubscribeEvent
	public static void registerItemRenderers(RegisterSpecialModelRendererEvent event) {
		event.register(ResourceLocation.parse("test:test_ranged_item_2"), TestRangedItem2ItemRenderer.Unbaked.MAP_CODEC);
	}

	private static final Map<Integer, Function<EntityModelSet, TestRangedItem2ItemRenderer>> MODELS = Map
			.ofEntries(Map.entry(-1, modelSet -> new TestRangedItem2ItemRenderer(new AnimatedModel(modelSet.bakeLayer(ModelKreper117.LAYER_LOCATION)), ResourceLocation.parse("test:textures/item/item.png"))));
	private final EntityModel<LivingEntityRenderState> model;
	private final ResourceLocation texture;
	private final LivingEntityRenderState renderState;
	private final long start;

	private TestRangedItem2ItemRenderer(EntityModel<LivingEntityRenderState> model, ResourceLocation texture) {
		this.model = model;
		this.texture = texture;
		this.renderState = new LivingEntityRenderState();
		this.start = System.currentTimeMillis();
	}

	@Override
	public void render(ItemStack itemstack, ItemDisplayContext displayContext, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay, boolean glint) {
		updateRenderState(itemstack);
		poseStack.pushPose();
		poseStack.translate(0.5, isInventory(displayContext) ? 1.5 : 2, 0.5);
		poseStack.scale(1, -1, displayContext == ItemDisplayContext.GUI ? -1 : 1);
		VertexConsumer vertexConsumer = ItemRenderer.getFoilBuffer(bufferSource, model.renderType(texture), false, glint);
		renderState.ageInTicks = (System.currentTimeMillis() - start) / 50.0f;
		if (model instanceof AnimatedModel animatedModel)
			animatedModel.setupItemStackAnim(this, itemstack, renderState);
		else
			model.setupAnim(renderState);
		model.renderToBuffer(poseStack, vertexConsumer, packedLight, packedOverlay);
		poseStack.popPose();
	}

	@Override
	public ItemStack extractArgument(ItemStack itemstack) {
		return itemstack;
	}

	@Override
	public void getExtents(Set<Vector3f> extentsSet) {
		PoseStack posestack = new PoseStack();
		this.model.root().getExtentsForGui(posestack, extentsSet);
	}

	private static boolean isInventory(ItemDisplayContext type) {
		return type == ItemDisplayContext.GUI || type == ItemDisplayContext.FIXED;
	}

	public record Unbaked(int index) implements SpecialModelRenderer.Unbaked {
		public static final MapCodec<TestRangedItem2ItemRenderer.Unbaked> MAP_CODEC = RecordCodecBuilder
				.mapCodec(instance -> instance.group(ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("index").xmap(opt -> opt.orElse(-1), i -> i == -1 ? Optional.empty() : Optional.of(i)).forGetter(TestRangedItem2ItemRenderer.Unbaked::index))
						.apply(instance, TestRangedItem2ItemRenderer.Unbaked::new));

		@Override
		public MapCodec<TestRangedItem2ItemRenderer.Unbaked> type() {
			return MAP_CODEC;
		}

		@Override
		public SpecialModelRenderer<?> bake(EntityModelSet modelSet) {
			return TestRangedItem2ItemRenderer.MODELS.get(index).apply(modelSet);
		}
	}

	private final Map<ItemStack, Map<Integer, AnimationState>> CACHE = new WeakHashMap<>();

	private Map<Integer, AnimationState> getAnimationState(ItemStack stack) {
		return CACHE.computeIfAbsent(stack, s -> IntStream.range(0, 2).boxed().collect(Collectors.toMap(i -> i, i -> new AnimationState(), (a, b) -> b)));
	}

	private void updateRenderState(ItemStack itemstack) {
		int tickCount = (int) (System.currentTimeMillis() - start) / 50;
		getAnimationState(itemstack).get(0).animateWhen(true, tickCount);
		getAnimationState(itemstack).get(1).animateWhen(LogicProcedureProcedure.execute(), tickCount);
	}

	private static final class AnimatedModel extends ModelKreper117 {
		private final KeyframeAnimation keyframeAnimation0;
		private final KeyframeAnimation keyframeAnimation1;

		public AnimatedModel(ModelPart root) {
			super(root);
			this.keyframeAnimation0 = MonsterAnimation.MONSTER_IDLE.bake(root);
			this.keyframeAnimation1 = MonsterAnimation.MONSTER_ATTACK1.bake(root);
		}

		public void setupItemStackAnim(TestRangedItem2ItemRenderer renderer, ItemStack itemstack, LivingEntityRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.keyframeAnimation0.apply(renderer.getAnimationState(itemstack).get(0), state.ageInTicks, 1f);
			this.keyframeAnimation1.apply(renderer.getAnimationState(itemstack).get(1), state.ageInTicks, 1.4f);
			super.setupAnim(state);
		}
	}
}