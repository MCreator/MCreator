package net.mcreator.test.procedures;

import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;

public class CustomDepsProcedure {
	public static void execute(LevelAccessor world) {
		TestItemProcedureBlocksProcedure.execute(world, Blocks.AIR instanceof LiquidBlock _liquid ? new ItemStack(_liquid.fluid.getBucket()) : ItemStack.EMPTY);
	}
}