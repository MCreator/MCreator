package net.mcreator.test.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.test.init.TestModMenus;

public class TestGUIProcedureBlocksProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && _player.containerMenu instanceof TestModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 0, "testTextField", ((entity instanceof Player _entity0 && _entity0.containerMenu instanceof TestModMenus.MenuAccessor _menu0) ? _menu0.getMenuState(0, "testTextField", "") : ""), true);
		if (entity instanceof Player _player && _player.level() instanceof ServerLevel _serverLevel && _player.containerMenu instanceof TestModMenus.MenuAccessor _menu) {
			ItemStack stack = _menu.getSlots().get((int) ((entity instanceof Player _entity2 && _entity2.containerMenu instanceof TestModMenus.MenuAccessor _menu2) ? _menu2.getMenuState(2, "sliderName2", 0.0) : 0.0)).getItem();
			if (stack != null) {
				stack.hurtAndBreak((int) ((entity instanceof Player _entity3 && _entity3.containerMenu instanceof TestModMenus.MenuAccessor _menu3) && _menu3.getMenuState(1, "testCheckBox", false)
						? Mth.nextInt(RandomSource.create(), 3, 7)
						: Mth.nextDouble(RandomSource.create(), 8, 12)), _serverLevel, null, _stkprov -> {
						});
				_player.containerMenu.broadcastChanges();
			}
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof TestModMenus.MenuAccessor _menu) {
			_menu.getSlots().get(0).remove(0);
			ItemStack _setstack10 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof TestModMenus.MenuAccessor _menu9 ? _menu9.getSlots().get(0).getItem() : ItemStack.EMPTY).copy();
			_setstack10.setCount(getAmountInGUISlot(entity, 0));
			_menu.getSlots().get(0).set(_setstack10);
			_menu.getSlots().get(0).set(ItemStack.EMPTY);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof TestModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 2, "sliderName", 1, true);
		if (entity instanceof Player _player && _player.containerMenu instanceof TestModMenus.MenuAccessor _menu)
			_menu.sendMenuStateUpdate(_player, 1, "checkBoxName", ((entity instanceof Player _entity13 && _entity13.containerMenu instanceof TestModMenus.MenuAccessor _menu13) && _menu13.getMenuState(1, "checkBoxName2", false)), true);
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof TestModMenus.MenuAccessor menuAccessor) {
			ItemStack stack = menuAccessor.getSlots().get(sltid).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}