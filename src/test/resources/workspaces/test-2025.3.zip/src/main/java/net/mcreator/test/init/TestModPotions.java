/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.test.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.test.TestMod;

public class TestModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, TestMod.MODID);
	public static final DeferredHolder<Potion, Potion> TEST_POTION_ITEM = REGISTRY.register("test_potion_item", () -> new Potion("test_potion_item", new MobEffectInstance(TestModMobEffects.TEST_POTION, 3600, 0, false, true)));
}