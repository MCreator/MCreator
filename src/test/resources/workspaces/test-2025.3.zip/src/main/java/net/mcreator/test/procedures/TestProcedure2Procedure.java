package net.mcreator.test.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

public class TestProcedure2Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.swinging) {
			world.gameEvent((world instanceof ServerLevel _level1 ? EntityType.ALLAY.spawn(_level1, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED) : null), GameEvent.BLOCK_DETACH, new Vec3(x, y, z));
		}
	}
}