package net.mcreator.test;

public class CustomClass {
}