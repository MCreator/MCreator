package net.mcreator.test.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.test.network.TestModVariables;

public class TestVariableProcedureBlocksProcedure {
	public static void execute(LevelAccessor world) {
		boolean local = false;
		double local2 = 0;
		String local3 = "";
		local = local;
		local2 = local2;
		local3 = local3;
		TestModVariables.MapVariables.get(world).test = TestModVariables.MapVariables.get(world).test;
		TestModVariables.MapVariables.get(world).test4 = TestModVariables.MapVariables.get(world).test4;
		TestModVariables.MapVariables.get(world).test7 = TestModVariables.MapVariables.get(world).test7;
		TestModVariables.MapVariables.get(world).markSyncDirty();
		TestModVariables.WorldVariables.get(world).test2 = TestModVariables.WorldVariables.get(world).test2;
		TestModVariables.WorldVariables.get(world).test5 = TestModVariables.WorldVariables.get(world).test5;
		TestModVariables.WorldVariables.get(world).test8 = TestModVariables.WorldVariables.get(world).test8;
		TestModVariables.WorldVariables.get(world).markSyncDirty();
		TestModVariables.test3 = TestModVariables.test3;
		TestModVariables.test6 = TestModVariables.test6;
		TestModVariables.test9 = TestModVariables.test9;
	}
}